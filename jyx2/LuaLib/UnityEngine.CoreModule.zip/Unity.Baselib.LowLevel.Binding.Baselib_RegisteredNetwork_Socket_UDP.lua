---@class Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_Socket_UDP : System.ValueType
---@field public handle System.IntPtr
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_Socket_UDP = m
return m
