---@class UnityEngine.EnumDataUtility.__c__DisplayClass7_0 : System.ValueType
---@field public nicifyName fun(arg:string):
---@field public field System.Reflection.FieldInfo
local m = {}

UnityEngine.EnumDataUtility.__c__DisplayClass7_0 = m
return m
