---@class UnityEngine.DiagnosticSwitch.Flags : System.Enum
---@field public None UnityEngine.DiagnosticSwitch.Flags @static
---@field public CanChangeAfterEngineStart UnityEngine.DiagnosticSwitch.Flags @static
---@field public value__ number
local m = {}

UnityEngine.DiagnosticSwitch.Flags = m
return m
