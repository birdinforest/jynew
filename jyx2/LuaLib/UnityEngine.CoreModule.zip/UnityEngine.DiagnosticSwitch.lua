---@class UnityEngine.DiagnosticSwitch : System.Object
---@field public name string
---@field public description string
---@field public owningModule string
---@field public flags UnityEngine.DiagnosticSwitch.Flags
---@field public value any
---@field public defaultValue any
---@field public minValue any
---@field public maxValue any
---@field public persistentValue any
---@field public enumInfo UnityEngine.EnumInfo
---@field public isSetToDefault boolean
---@field public needsRestart boolean
local m = {}

UnityEngine.DiagnosticSwitch = m
return m
