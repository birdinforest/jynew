---@class UnityEngine.UnityException : System.SystemException
local m = {}

UnityEngine.UnityException = m
return m
