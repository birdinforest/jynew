---@class UnityEngine.DelayedAttribute : UnityEngine.PropertyAttribute
local m = {}

UnityEngine.DelayedAttribute = m
return m
