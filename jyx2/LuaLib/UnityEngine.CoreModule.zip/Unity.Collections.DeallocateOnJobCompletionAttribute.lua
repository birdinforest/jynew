---@class Unity.Collections.DeallocateOnJobCompletionAttribute : System.Attribute
local m = {}

Unity.Collections.DeallocateOnJobCompletionAttribute = m
return m
