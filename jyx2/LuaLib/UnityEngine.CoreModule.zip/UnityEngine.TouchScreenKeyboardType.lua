---@class UnityEngine.TouchScreenKeyboardType : System.Enum
---@field public Default UnityEngine.TouchScreenKeyboardType @static
---@field public ASCIICapable UnityEngine.TouchScreenKeyboardType @static
---@field public NumbersAndPunctuation UnityEngine.TouchScreenKeyboardType @static
---@field public URL UnityEngine.TouchScreenKeyboardType @static
---@field public NumberPad UnityEngine.TouchScreenKeyboardType @static
---@field public PhonePad UnityEngine.TouchScreenKeyboardType @static
---@field public NamePhonePad UnityEngine.TouchScreenKeyboardType @static
---@field public EmailAddress UnityEngine.TouchScreenKeyboardType @static
---@field public NintendoNetworkAccount UnityEngine.TouchScreenKeyboardType @static
---@field public Social UnityEngine.TouchScreenKeyboardType @static
---@field public Search UnityEngine.TouchScreenKeyboardType @static
---@field public DecimalPad UnityEngine.TouchScreenKeyboardType @static
---@field public OneTimeCode UnityEngine.TouchScreenKeyboardType @static
---@field public value__ number
local m = {}

UnityEngine.TouchScreenKeyboardType = m
return m
