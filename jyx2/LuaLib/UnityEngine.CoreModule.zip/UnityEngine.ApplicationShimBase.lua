---@class UnityEngine.ApplicationShimBase : System.Object
---@field public absoluteURL string
---@field public backgroundLoadingPriority UnityEngine.ThreadPriority
---@field public buildGUID string
---@field public cloudProjectId string
---@field public companyName string
---@field public consoleLogPath string
---@field public dataPath string
---@field public genuine boolean
---@field public genuineCheckAvailable boolean
---@field public identifier string
---@field public installerName string
---@field public installMode UnityEngine.ApplicationInstallMode
---@field public internetReachability UnityEngine.NetworkReachability
---@field public isBatchMode boolean
---@field public isConsolePlatform boolean
---@field public isEditor boolean
---@field public isFocused boolean
---@field public isMobilePlatform boolean
---@field public isPlaying boolean
---@field public persistentDataPath string
---@field public platform UnityEngine.RuntimePlatform
---@field public productName string
---@field public runInBackground boolean
---@field public sandboxType UnityEngine.ApplicationSandboxType
---@field public streamingAssetsPath string
---@field public systemLanguage UnityEngine.SystemLanguage
---@field public targetFrameRate number
---@field public temporaryCachePath string
---@field public unityVersion string
---@field public version string
local m = {}

---@virtual
function m:Dispose() end

---@return boolean
function m:IsActive() end

---@virtual
---@param value fun(obj:string)
function m:add_deepLinkActivated(value) end

---@virtual
---@param value fun(obj:string)
function m:remove_deepLinkActivated(value) end

---@virtual
---@param value fun(obj:boolean)
function m:add_focusChanged(value) end

---@virtual
---@param value fun(obj:boolean)
function m:remove_focusChanged(value) end

---@virtual
---@param value fun(condition:string, stackTrace:string, type:UnityEngine.LogType)
function m:add_logMessageReceived(value) end

---@virtual
---@param value fun(condition:string, stackTrace:string, type:UnityEngine.LogType)
function m:remove_logMessageReceived(value) end

---@virtual
---@param value fun(condition:string, stackTrace:string, type:UnityEngine.LogType)
function m:add_logMessageReceivedThreaded(value) end

---@virtual
---@param value fun(condition:string, stackTrace:string, type:UnityEngine.LogType)
function m:remove_logMessageReceivedThreaded(value) end

---@virtual
---@param value fun()
function m:add_lowMemory(value) end

---@virtual
---@param value fun()
function m:remove_lowMemory(value) end

---@virtual
---@param value fun()
function m:add_onBeforeRender(value) end

---@virtual
---@param value fun()
function m:remove_onBeforeRender(value) end

---@virtual
---@param value fun()
function m:add_quitting(value) end

---@virtual
---@param value fun()
function m:remove_quitting(value) end

---@virtual
---@param value fun():
function m:add_wantsToQuit(value) end

---@virtual
---@param value fun():
function m:remove_wantsToQuit(value) end

---@virtual
---@param value fun()
function m:add_unloading(value) end

---@virtual
---@param value fun()
function m:remove_unloading(value) end

---@overload fun(levelName:string): @virtual
---@virtual
---@param levelIndex number
---@return boolean
function m:CanStreamedLevelBeLoaded(levelIndex) end

---@virtual
---@return string[]
function m:GetBuildTags() end

---@virtual
---@param logType UnityEngine.LogType
---@return UnityEngine.StackTraceLogType
function m:GetStackTraceLogType(logType) end

---@virtual
---@return boolean
function m:HasProLicense() end

---@virtual
---@param mode UnityEngine.UserAuthorization
---@return boolean
function m:HasUserAuthorization(mode) end

---@virtual
---@param obj UnityEngine.Object
---@return boolean
function m:IsPlaying(obj) end

---@virtual
---@param url string
function m:OpenURL(url) end

---@overload fun(exitCode:number) @virtual
---@virtual
function m:Quit() end

---@virtual
---@param delegateMethod fun(advertisingId:string, trackingEnabled:boolean, errorMsg:string)
---@return boolean
function m:RequestAdvertisingIdentifierAsync(delegateMethod) end

---@virtual
---@param mode UnityEngine.UserAuthorization
---@return UnityEngine.AsyncOperation
function m:RequestUserAuthorization(mode) end

---@virtual
---@param buildTags string[]
function m:SetBuildTags(buildTags) end

---@virtual
---@param logType UnityEngine.LogType
---@param stackTraceType UnityEngine.StackTraceLogType
function m:SetStackTraceLogType(logType, stackTraceType) end

---@virtual
function m:Unload() end

UnityEngine.ApplicationShimBase = m
return m
