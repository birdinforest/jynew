---@class Unity.Profiling.ProfilerRecorder.CountOptions : System.Enum
---@field public Count Unity.Profiling.ProfilerRecorder.CountOptions @static
---@field public MaxCount Unity.Profiling.ProfilerRecorder.CountOptions @static
---@field public value__ number
local m = {}

Unity.Profiling.ProfilerRecorder.CountOptions = m
return m
