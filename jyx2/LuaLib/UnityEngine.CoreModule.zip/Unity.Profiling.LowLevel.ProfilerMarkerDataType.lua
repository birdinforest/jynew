---@class Unity.Profiling.LowLevel.ProfilerMarkerDataType : System.Enum
---@field public Int32 Unity.Profiling.LowLevel.ProfilerMarkerDataType @static
---@field public UInt32 Unity.Profiling.LowLevel.ProfilerMarkerDataType @static
---@field public Int64 Unity.Profiling.LowLevel.ProfilerMarkerDataType @static
---@field public UInt64 Unity.Profiling.LowLevel.ProfilerMarkerDataType @static
---@field public Float Unity.Profiling.LowLevel.ProfilerMarkerDataType @static
---@field public Double Unity.Profiling.LowLevel.ProfilerMarkerDataType @static
---@field public String16 Unity.Profiling.LowLevel.ProfilerMarkerDataType @static
---@field public Blob8 Unity.Profiling.LowLevel.ProfilerMarkerDataType @static
---@field public value__ number
local m = {}

Unity.Profiling.LowLevel.ProfilerMarkerDataType = m
return m
