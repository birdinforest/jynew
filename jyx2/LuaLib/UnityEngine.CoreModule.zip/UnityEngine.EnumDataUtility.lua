---@class UnityEngine.EnumDataUtility : System.Object
local m = {}

UnityEngine.EnumDataUtility = m
return m
