---@class UnityEngine.SerializeField : System.Attribute
local m = {}

UnityEngine.SerializeField = m
return m
