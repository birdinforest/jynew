---@class UnityEngineInternal.TypeInferenceRules : System.Enum
---@field public TypeReferencedByFirstArgument UnityEngineInternal.TypeInferenceRules @static
---@field public TypeReferencedBySecondArgument UnityEngineInternal.TypeInferenceRules @static
---@field public ArrayOfTypeReferencedByFirstArgument UnityEngineInternal.TypeInferenceRules @static
---@field public TypeOfFirstArgument UnityEngineInternal.TypeInferenceRules @static
---@field public value__ number
local m = {}

UnityEngineInternal.TypeInferenceRules = m
return m
