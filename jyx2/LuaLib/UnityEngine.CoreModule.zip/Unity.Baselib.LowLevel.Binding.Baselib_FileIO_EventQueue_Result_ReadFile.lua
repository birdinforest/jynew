---@class Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_Result_ReadFile : System.ValueType
---@field public bytesTransferred number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_Result_ReadFile = m
return m
