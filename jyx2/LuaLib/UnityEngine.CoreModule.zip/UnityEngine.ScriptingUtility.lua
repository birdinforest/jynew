---@class UnityEngine.ScriptingUtility : System.Object
local m = {}

UnityEngine.ScriptingUtility = m
return m
