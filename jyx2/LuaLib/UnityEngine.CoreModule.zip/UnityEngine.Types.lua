---@class UnityEngine.Types : System.Object
local m = {}

---@static
---@param typeName string
---@param assemblyName string
---@return System.Type
function m.GetType(typeName, assemblyName) end

UnityEngine.Types = m
return m
