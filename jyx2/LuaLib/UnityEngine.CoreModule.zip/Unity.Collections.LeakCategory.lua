---@class Unity.Collections.LeakCategory : System.Enum
---@field public Invalid Unity.Collections.LeakCategory @static
---@field public Malloc Unity.Collections.LeakCategory @static
---@field public TempJob Unity.Collections.LeakCategory @static
---@field public Persistent Unity.Collections.LeakCategory @static
---@field public LightProbesQuery Unity.Collections.LeakCategory @static
---@field public NativeTest Unity.Collections.LeakCategory @static
---@field public MeshDataArray Unity.Collections.LeakCategory @static
---@field public TransformAccessArray Unity.Collections.LeakCategory @static
---@field public NavMeshQuery Unity.Collections.LeakCategory @static
---@field public value__ number
local m = {}

Unity.Collections.LeakCategory = m
return m
