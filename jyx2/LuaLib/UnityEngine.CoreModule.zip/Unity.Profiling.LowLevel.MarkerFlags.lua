---@class Unity.Profiling.LowLevel.MarkerFlags : System.Enum
---@field public Default Unity.Profiling.LowLevel.MarkerFlags @static
---@field public Script Unity.Profiling.LowLevel.MarkerFlags @static
---@field public ScriptInvoke Unity.Profiling.LowLevel.MarkerFlags @static
---@field public ScriptDeepProfiler Unity.Profiling.LowLevel.MarkerFlags @static
---@field public AvailabilityEditor Unity.Profiling.LowLevel.MarkerFlags @static
---@field public AvailabilityNonDevelopment Unity.Profiling.LowLevel.MarkerFlags @static
---@field public Warning Unity.Profiling.LowLevel.MarkerFlags @static
---@field public Counter Unity.Profiling.LowLevel.MarkerFlags @static
---@field public SampleGPU Unity.Profiling.LowLevel.MarkerFlags @static
---@field public value__ number
local m = {}

Unity.Profiling.LowLevel.MarkerFlags = m
return m
