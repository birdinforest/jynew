---@class UnityEngine.PlayerConnectionInternal.MulticastFlags : System.Enum
---@field public kRequestImmediateConnect UnityEngine.PlayerConnectionInternal.MulticastFlags @static
---@field public kSupportsProfile UnityEngine.PlayerConnectionInternal.MulticastFlags @static
---@field public kCustomMessage UnityEngine.PlayerConnectionInternal.MulticastFlags @static
---@field public kUseAlternateIP UnityEngine.PlayerConnectionInternal.MulticastFlags @static
---@field public value__ number
local m = {}

UnityEngine.PlayerConnectionInternal.MulticastFlags = m
return m
