---@class UnityEngine.iPhoneOrientation : System.Enum
---@field public Unknown UnityEngine.iPhoneOrientation @static
---@field public Portrait UnityEngine.iPhoneOrientation @static
---@field public PortraitUpsideDown UnityEngine.iPhoneOrientation @static
---@field public LandscapeLeft UnityEngine.iPhoneOrientation @static
---@field public LandscapeRight UnityEngine.iPhoneOrientation @static
---@field public FaceUp UnityEngine.iPhoneOrientation @static
---@field public FaceDown UnityEngine.iPhoneOrientation @static
---@field public value__ number
local m = {}

UnityEngine.iPhoneOrientation = m
return m
