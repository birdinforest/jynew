---@class Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_Result_Callback : System.ValueType
---@field public callback System.IntPtr
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_Result_Callback = m
return m
