---@class Unity.Rendering.HybridV2.DOTSInstancingCbuffer : System.ValueType
---@field public NameID number
---@field public CbufferIndex number
---@field public SizeBytes number
local m = {}

Unity.Rendering.HybridV2.DOTSInstancingCbuffer = m
return m
