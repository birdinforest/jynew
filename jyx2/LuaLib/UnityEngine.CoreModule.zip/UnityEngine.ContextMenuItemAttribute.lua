---@class UnityEngine.ContextMenuItemAttribute : UnityEngine.PropertyAttribute
---@field public name string
---@field public function string
local m = {}

UnityEngine.ContextMenuItemAttribute = m
return m
