---@class Unity.Collections.NativeLeakDetectionMode : System.Enum
---@field public EnabledWithStackTrace Unity.Collections.NativeLeakDetectionMode @static
---@field public Enabled Unity.Collections.NativeLeakDetectionMode @static
---@field public Disabled Unity.Collections.NativeLeakDetectionMode @static
---@field public value__ number
local m = {}

Unity.Collections.NativeLeakDetectionMode = m
return m
