---@class UnityEngine.iPhoneNetworkReachability : System.Enum
---@field public NotReachable UnityEngine.iPhoneNetworkReachability @static
---@field public ReachableViaCarrierDataNetwork UnityEngine.iPhoneNetworkReachability @static
---@field public ReachableViaWiFiNetwork UnityEngine.iPhoneNetworkReachability @static
---@field public value__ number
local m = {}

UnityEngine.iPhoneNetworkReachability = m
return m
