---@class UnityEngine.SpookyHash : System.Object
local m = {}

---@static
---@param message System.Void*
---@param length number
---@param hash1 System.UInt64*
---@param hash2 System.UInt64*
function m.Hash(message, length, hash1, hash2) end

UnityEngine.SpookyHash = m
return m
