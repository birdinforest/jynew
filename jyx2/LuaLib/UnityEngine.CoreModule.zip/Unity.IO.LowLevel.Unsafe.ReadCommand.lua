---@class Unity.IO.LowLevel.Unsafe.ReadCommand : System.ValueType
---@field public Buffer System.Void*
---@field public Offset number
---@field public Size number
local m = {}

Unity.IO.LowLevel.Unsafe.ReadCommand = m
return m
