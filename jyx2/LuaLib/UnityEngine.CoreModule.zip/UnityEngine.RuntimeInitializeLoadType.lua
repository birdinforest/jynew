---@class UnityEngine.RuntimeInitializeLoadType : System.Enum
---@field public AfterSceneLoad UnityEngine.RuntimeInitializeLoadType @static
---@field public BeforeSceneLoad UnityEngine.RuntimeInitializeLoadType @static
---@field public AfterAssembliesLoaded UnityEngine.RuntimeInitializeLoadType @static
---@field public BeforeSplashScreen UnityEngine.RuntimeInitializeLoadType @static
---@field public SubsystemRegistration UnityEngine.RuntimeInitializeLoadType @static
---@field public value__ number
local m = {}

UnityEngine.RuntimeInitializeLoadType = m
return m
