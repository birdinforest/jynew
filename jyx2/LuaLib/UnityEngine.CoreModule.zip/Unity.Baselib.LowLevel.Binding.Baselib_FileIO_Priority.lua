---@class Unity.Baselib.LowLevel.Binding.Baselib_FileIO_Priority : System.Enum
---@field public Normal Unity.Baselib.LowLevel.Binding.Baselib_FileIO_Priority @static
---@field public High Unity.Baselib.LowLevel.Binding.Baselib_FileIO_Priority @static
---@field public value__ number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_FileIO_Priority = m
return m
