---@class UnityEngine.UnhandledExceptionHandler : System.Object
local m = {}

UnityEngine.UnhandledExceptionHandler = m
return m
