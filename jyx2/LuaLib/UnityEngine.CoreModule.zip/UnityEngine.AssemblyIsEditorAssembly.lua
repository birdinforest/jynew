---@class UnityEngine.AssemblyIsEditorAssembly : System.Attribute
local m = {}

UnityEngine.AssemblyIsEditorAssembly = m
return m
