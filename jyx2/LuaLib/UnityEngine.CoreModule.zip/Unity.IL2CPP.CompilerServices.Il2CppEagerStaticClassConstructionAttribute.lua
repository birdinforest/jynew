---@class Unity.IL2CPP.CompilerServices.Il2CppEagerStaticClassConstructionAttribute : System.Attribute
local m = {}

Unity.IL2CPP.CompilerServices.Il2CppEagerStaticClassConstructionAttribute = m
return m
