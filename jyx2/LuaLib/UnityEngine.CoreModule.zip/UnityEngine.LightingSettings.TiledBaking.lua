---@class UnityEngine.LightingSettings.TiledBaking : System.Enum
---@field public Disabled UnityEngine.LightingSettings.TiledBaking @static
---@field public Auto UnityEngine.LightingSettings.TiledBaking @static
---@field public Quarter UnityEngine.LightingSettings.TiledBaking @static
---@field public Sixtenth UnityEngine.LightingSettings.TiledBaking @static
---@field public SixtyFourth UnityEngine.LightingSettings.TiledBaking @static
---@field public TwoHundredFiftySixth UnityEngine.LightingSettings.TiledBaking @static
---@field public value__ number
local m = {}

UnityEngine.LightingSettings.TiledBaking = m
return m
