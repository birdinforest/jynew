---@class UnityEngine.WaitForEndOfFrame : UnityEngine.YieldInstruction
local m = {}

UnityEngine.WaitForEndOfFrame = m
return m
