---@class UnityEngine.RuntimeUndo : System.Object
local m = {}

UnityEngine.RuntimeUndo = m
return m
