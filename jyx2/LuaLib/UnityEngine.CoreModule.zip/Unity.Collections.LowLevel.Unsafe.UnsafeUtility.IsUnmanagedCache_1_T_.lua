---@class Unity.Collections.LowLevel.Unsafe.UnsafeUtility.IsUnmanagedCache_1_T_ : System.ValueType
local m = {}

Unity.Collections.LowLevel.Unsafe.UnsafeUtility.IsUnmanagedCache_1_T_ = m
return m
