---@class UnityEngine.UnitySynchronizationContext.WorkRequest : System.ValueType
local m = {}

function m:Invoke() end

UnityEngine.UnitySynchronizationContext.WorkRequest = m
return m
