---@class UnityEngine.FindObjectsInactive : System.Enum
---@field public Exclude UnityEngine.FindObjectsInactive @static
---@field public Include UnityEngine.FindObjectsInactive @static
---@field public value__ number
local m = {}

UnityEngine.FindObjectsInactive = m
return m
