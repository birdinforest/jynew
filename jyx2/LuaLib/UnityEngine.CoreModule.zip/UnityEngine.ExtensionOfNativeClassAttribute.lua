---@class UnityEngine.ExtensionOfNativeClassAttribute : System.Attribute
local m = {}

UnityEngine.ExtensionOfNativeClassAttribute = m
return m
