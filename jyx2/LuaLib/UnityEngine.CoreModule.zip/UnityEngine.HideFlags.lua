---@class UnityEngine.HideFlags : System.Enum
---@field public None UnityEngine.HideFlags @static
---@field public HideInHierarchy UnityEngine.HideFlags @static
---@field public HideInInspector UnityEngine.HideFlags @static
---@field public DontSaveInEditor UnityEngine.HideFlags @static
---@field public NotEditable UnityEngine.HideFlags @static
---@field public DontSaveInBuild UnityEngine.HideFlags @static
---@field public DontUnloadUnusedAsset UnityEngine.HideFlags @static
---@field public DontSave UnityEngine.HideFlags @static
---@field public HideAndDontSave UnityEngine.HideFlags @static
---@field public value__ number
local m = {}

UnityEngine.HideFlags = m
return m
