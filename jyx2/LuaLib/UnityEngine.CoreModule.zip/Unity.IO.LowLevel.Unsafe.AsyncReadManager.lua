---@class Unity.IO.LowLevel.Unsafe.AsyncReadManager : System.Object
local m = {}

---@overload fun(filename:string, readCmds:Unity.IO.LowLevel.Unsafe.ReadCommand*, readCmdCount:number, assetName:string, typeID:number): @static
---@overload fun(filename:string, readCmds:Unity.IO.LowLevel.Unsafe.ReadCommand*, readCmdCount:number, assetName:string): @static
---@overload fun(filename:string, readCmds:Unity.IO.LowLevel.Unsafe.ReadCommand*, readCmdCount:number): @static
---@overload fun(fileHandle:Unity.IO.LowLevel.Unsafe.FileHandle, readCmdArray:Unity.IO.LowLevel.Unsafe.ReadCommandArray):(, Unity.IO.LowLevel.Unsafe.FileHandle) @static
---@static
---@param filename string
---@param readCmds Unity.IO.LowLevel.Unsafe.ReadCommand*
---@param readCmdCount number
---@param assetName string
---@param typeID number
---@param subsystem Unity.IO.LowLevel.Unsafe.AssetLoadingSubsystem
---@return Unity.IO.LowLevel.Unsafe.ReadHandle
function m.Read(filename, readCmds, readCmdCount, assetName, typeID, subsystem) end

---@static
---@param filename string
---@param result Unity.IO.LowLevel.Unsafe.FileInfoResult*
---@return Unity.IO.LowLevel.Unsafe.ReadHandle
function m.GetFileInfo(filename, result) end

---@static
---@param fileHandle Unity.IO.LowLevel.Unsafe.FileHandle
---@param readCmdArray Unity.IO.LowLevel.Unsafe.ReadCommandArray*
---@param dependency Unity.Jobs.JobHandle
---@return Unity.IO.LowLevel.Unsafe.ReadHandle, Unity.IO.LowLevel.Unsafe.FileHandle
function m.ReadDeferred(fileHandle, readCmdArray, dependency) end

---@static
---@param fileName string
---@return Unity.IO.LowLevel.Unsafe.FileHandle
function m.OpenFileAsync(fileName) end

---@overload fun(fileName:string): @static
---@static
---@param fileName string
---@param dependency Unity.Jobs.JobHandle
---@return Unity.Jobs.JobHandle
function m.CloseCachedFileAsync(fileName, dependency) end

Unity.IO.LowLevel.Unsafe.AsyncReadManager = m
return m
