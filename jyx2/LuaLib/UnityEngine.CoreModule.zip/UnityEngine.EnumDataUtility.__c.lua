---@class UnityEngine.EnumDataUtility.__c : System.Object
---@field public <>9 UnityEngine.EnumDataUtility.__c @static
---@field public <>9__2_5 fun(arg:System.Reflection.FieldInfo): @static
---@field public <>9__2_1 fun(arg:System.Reflection.FieldInfo): @static
---@field public <>9__2_2 fun(arg:System.Reflection.FieldInfo): @static
---@field public <>9__2_3 fun(arg:System.Enum): @static
---@field public <>9__2_4 fun(arg:System.Enum): @static
local m = {}

UnityEngine.EnumDataUtility.__c = m
return m
