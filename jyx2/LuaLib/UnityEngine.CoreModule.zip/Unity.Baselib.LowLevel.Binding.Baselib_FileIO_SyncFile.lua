---@class Unity.Baselib.LowLevel.Binding.Baselib_FileIO_SyncFile : System.ValueType
---@field public handle System.IntPtr
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_FileIO_SyncFile = m
return m
