---@class Unity.Profiling.ProfilerMarkerWithStringData : System.ValueType
local m = {}

---@static
---@param name string
---@param parameterName string
---@return Unity.Profiling.ProfilerMarkerWithStringData
function m.Create(name, parameterName) end

---@overload fun(value:string):
---@param enabled boolean
---@param parameterValue fun():
---@return Unity.Profiling.ProfilerMarkerWithStringData.AutoScope
function m:Auto(enabled, parameterValue) end

Unity.Profiling.ProfilerMarkerWithStringData = m
return m
