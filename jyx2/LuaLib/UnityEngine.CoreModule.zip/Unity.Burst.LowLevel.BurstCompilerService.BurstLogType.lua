---@class Unity.Burst.LowLevel.BurstCompilerService.BurstLogType : System.Enum
---@field public Info Unity.Burst.LowLevel.BurstCompilerService.BurstLogType @static
---@field public Warning Unity.Burst.LowLevel.BurstCompilerService.BurstLogType @static
---@field public Error Unity.Burst.LowLevel.BurstCompilerService.BurstLogType @static
---@field public value__ number
local m = {}

Unity.Burst.LowLevel.BurstCompilerService.BurstLogType = m
return m
