---@class UnityEngine.RangeInt : System.ValueType
---@field public start number
---@field public length number
---@field public end number
local m = {}

UnityEngine.RangeInt = m
return m
