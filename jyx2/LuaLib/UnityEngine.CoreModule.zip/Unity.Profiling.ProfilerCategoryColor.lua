---@class Unity.Profiling.ProfilerCategoryColor : System.Enum
---@field public Render Unity.Profiling.ProfilerCategoryColor @static
---@field public Scripts Unity.Profiling.ProfilerCategoryColor @static
---@field public BurstJobs Unity.Profiling.ProfilerCategoryColor @static
---@field public Other Unity.Profiling.ProfilerCategoryColor @static
---@field public Physics Unity.Profiling.ProfilerCategoryColor @static
---@field public Animation Unity.Profiling.ProfilerCategoryColor @static
---@field public Audio Unity.Profiling.ProfilerCategoryColor @static
---@field public AudioJob Unity.Profiling.ProfilerCategoryColor @static
---@field public AudioUpdateJob Unity.Profiling.ProfilerCategoryColor @static
---@field public Lighting Unity.Profiling.ProfilerCategoryColor @static
---@field public GC Unity.Profiling.ProfilerCategoryColor @static
---@field public VSync Unity.Profiling.ProfilerCategoryColor @static
---@field public Memory Unity.Profiling.ProfilerCategoryColor @static
---@field public Internal Unity.Profiling.ProfilerCategoryColor @static
---@field public UI Unity.Profiling.ProfilerCategoryColor @static
---@field public Build Unity.Profiling.ProfilerCategoryColor @static
---@field public Input Unity.Profiling.ProfilerCategoryColor @static
---@field public value__ number
local m = {}

Unity.Profiling.ProfilerCategoryColor = m
return m
