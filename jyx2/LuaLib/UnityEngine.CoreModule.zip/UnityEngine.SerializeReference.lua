---@class UnityEngine.SerializeReference : System.Attribute
local m = {}

UnityEngine.SerializeReference = m
return m
