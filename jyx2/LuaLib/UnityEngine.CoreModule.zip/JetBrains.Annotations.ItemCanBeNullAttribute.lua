---@class JetBrains.Annotations.ItemCanBeNullAttribute : System.Attribute
local m = {}

JetBrains.Annotations.ItemCanBeNullAttribute = m
return m
