---@class UnityEngine.WaitForFixedUpdate : UnityEngine.YieldInstruction
local m = {}

UnityEngine.WaitForFixedUpdate = m
return m
