---@class UnityEngineInternal.GraphicsDeviceDebug : System.Object
local m = {}

UnityEngineInternal.GraphicsDeviceDebug = m
return m
