---@class Unity.Baselib.LowLevel.Binding.Baselib_Socket_Handle : System.ValueType
---@field public handle System.IntPtr
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_Socket_Handle = m
return m
