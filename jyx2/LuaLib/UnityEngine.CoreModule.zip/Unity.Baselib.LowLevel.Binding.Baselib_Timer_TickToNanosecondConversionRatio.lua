---@class Unity.Baselib.LowLevel.Binding.Baselib_Timer_TickToNanosecondConversionRatio : System.ValueType
---@field public ticksToNanosecondsNumerator number
---@field public ticksToNanosecondsDenominator number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_Timer_TickToNanosecondConversionRatio = m
return m
