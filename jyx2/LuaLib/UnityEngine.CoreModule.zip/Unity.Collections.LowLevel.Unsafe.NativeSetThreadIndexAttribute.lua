---@class Unity.Collections.LowLevel.Unsafe.NativeSetThreadIndexAttribute : System.Attribute
local m = {}

Unity.Collections.LowLevel.Unsafe.NativeSetThreadIndexAttribute = m
return m
