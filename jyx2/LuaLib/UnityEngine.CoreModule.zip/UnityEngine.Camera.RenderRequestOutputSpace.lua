---@class UnityEngine.Camera.RenderRequestOutputSpace : System.Enum
---@field public ScreenSpace UnityEngine.Camera.RenderRequestOutputSpace @static
---@field public UV0 UnityEngine.Camera.RenderRequestOutputSpace @static
---@field public UV1 UnityEngine.Camera.RenderRequestOutputSpace @static
---@field public UV2 UnityEngine.Camera.RenderRequestOutputSpace @static
---@field public UV3 UnityEngine.Camera.RenderRequestOutputSpace @static
---@field public UV4 UnityEngine.Camera.RenderRequestOutputSpace @static
---@field public UV5 UnityEngine.Camera.RenderRequestOutputSpace @static
---@field public UV6 UnityEngine.Camera.RenderRequestOutputSpace @static
---@field public UV7 UnityEngine.Camera.RenderRequestOutputSpace @static
---@field public UV8 UnityEngine.Camera.RenderRequestOutputSpace @static
---@field public value__ number
local m = {}

UnityEngine.Camera.RenderRequestOutputSpace = m
return m
