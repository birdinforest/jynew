---@class UnityEngine.MinAttribute : UnityEngine.PropertyAttribute
---@field public min number
local m = {}

UnityEngine.MinAttribute = m
return m
