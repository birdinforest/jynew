---@class UnityEngine.HideInCallstackAttribute : System.Attribute
local m = {}

UnityEngine.HideInCallstackAttribute = m
return m
