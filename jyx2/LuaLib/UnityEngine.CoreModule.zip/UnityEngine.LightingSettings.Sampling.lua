---@class UnityEngine.LightingSettings.Sampling : System.Enum
---@field public Auto UnityEngine.LightingSettings.Sampling @static
---@field public Fixed UnityEngine.LightingSettings.Sampling @static
---@field public value__ number
local m = {}

UnityEngine.LightingSettings.Sampling = m
return m
