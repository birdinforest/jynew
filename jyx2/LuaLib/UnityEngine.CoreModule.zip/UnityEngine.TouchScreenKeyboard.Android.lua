---@class UnityEngine.TouchScreenKeyboard.Android : System.Object
---@field public closeKeyboardOnOutsideTap boolean @static
---@field public consumesOutsideTouches boolean @static
local m = {}

UnityEngine.TouchScreenKeyboard.Android = m
return m
