---@class UnityEngine.ScriptingUtility.TestClass : System.ValueType
---@field public value number
local m = {}

UnityEngine.ScriptingUtility.TestClass = m
return m
