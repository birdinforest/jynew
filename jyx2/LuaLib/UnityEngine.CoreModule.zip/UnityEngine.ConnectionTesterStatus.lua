---@class UnityEngine.ConnectionTesterStatus : System.Enum
---@field public value__ number
local m = {}

UnityEngine.ConnectionTesterStatus = m
return m
