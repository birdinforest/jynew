---@class UnityEngine.OperatingSystemFamily : System.Enum
---@field public Other UnityEngine.OperatingSystemFamily @static
---@field public MacOSX UnityEngine.OperatingSystemFamily @static
---@field public Windows UnityEngine.OperatingSystemFamily @static
---@field public Linux UnityEngine.OperatingSystemFamily @static
---@field public value__ number
local m = {}

UnityEngine.OperatingSystemFamily = m
return m
