---@class UnityEngine.ExposedReference_1_T_ : System.ValueType
---@field public exposedName UnityEngine.PropertyName
---@field public defaultValue UnityEngine.Object
local m = {}

---@param resolver UnityEngine.IExposedPropertyTable
---@return UnityEngine.Object
function m:Resolve(resolver) end

UnityEngine.ExposedReference_1_T_ = m
return m
