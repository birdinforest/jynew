---@class Unity.Profiling.ProfilerCounterOptions : System.Enum
---@field public None Unity.Profiling.ProfilerCounterOptions @static
---@field public FlushOnEndOfFrame Unity.Profiling.ProfilerCounterOptions @static
---@field public ResetToZeroOnFlush Unity.Profiling.ProfilerCounterOptions @static
---@field public value__ number
local m = {}

Unity.Profiling.ProfilerCounterOptions = m
return m
