---@class JetBrains.Annotations.InstantHandleAttribute : System.Attribute
local m = {}

JetBrains.Annotations.InstantHandleAttribute = m
return m
