---@class UnityEngine.PreferBinarySerialization : System.Attribute
local m = {}

UnityEngine.PreferBinarySerialization = m
return m
