---@class Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_Result : System.ValueType
---@field public type Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_ResultType
---@field public userdata number
---@field public errorState Unity.Baselib.LowLevel.Binding.Baselib_ErrorState
---@field public callback Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_Result_Callback
---@field public openFile Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_Result_OpenFile
---@field public readFile Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_Result_ReadFile
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_Result = m
return m
