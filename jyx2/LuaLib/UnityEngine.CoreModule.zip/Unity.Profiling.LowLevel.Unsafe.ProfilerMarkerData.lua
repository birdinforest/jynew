---@class Unity.Profiling.LowLevel.Unsafe.ProfilerMarkerData : System.ValueType
---@field public Type number
---@field public Size number
---@field public Ptr System.Void*
local m = {}

Unity.Profiling.LowLevel.Unsafe.ProfilerMarkerData = m
return m
