---@class JetBrains.Annotations.RegexPatternAttribute : System.Attribute
local m = {}

JetBrains.Annotations.RegexPatternAttribute = m
return m
