---@class UnityEngine.ResourceRequest : UnityEngine.AsyncOperation
---@field public asset UnityEngine.Object
local m = {}

UnityEngine.ResourceRequest = m
return m
