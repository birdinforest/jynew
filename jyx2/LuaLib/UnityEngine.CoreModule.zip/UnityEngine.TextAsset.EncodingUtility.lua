---@class UnityEngine.TextAsset.EncodingUtility : System.Object
local m = {}

UnityEngine.TextAsset.EncodingUtility = m
return m
