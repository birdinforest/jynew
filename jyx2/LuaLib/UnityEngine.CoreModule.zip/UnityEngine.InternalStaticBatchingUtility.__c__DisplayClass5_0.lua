---@class UnityEngine.InternalStaticBatchingUtility.__c__DisplayClass5_0 : System.Object
---@field public sorter UnityEngine.InternalStaticBatchingUtility.StaticBatcherGOSorter
local m = {}

UnityEngine.InternalStaticBatchingUtility.__c__DisplayClass5_0 = m
return m
