---@class UnityEngine.iOSActivityIndicatorStyle : System.Enum
---@field public DontShow UnityEngine.iOSActivityIndicatorStyle @static
---@field public WhiteLarge UnityEngine.iOSActivityIndicatorStyle @static
---@field public White UnityEngine.iOSActivityIndicatorStyle @static
---@field public Gray UnityEngine.iOSActivityIndicatorStyle @static
---@field public value__ number
local m = {}

UnityEngine.iOSActivityIndicatorStyle = m
return m
