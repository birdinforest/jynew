---@class Unity.Profiling.ProfilerMarker.AutoScope : System.ValueType
local m = {}

---@virtual
function m:Dispose() end

Unity.Profiling.ProfilerMarker.AutoScope = m
return m
