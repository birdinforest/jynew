---@class JetBrains.Annotations.ValueProviderAttribute : System.Attribute
---@field public Name string
local m = {}

JetBrains.Annotations.ValueProviderAttribute = m
return m
