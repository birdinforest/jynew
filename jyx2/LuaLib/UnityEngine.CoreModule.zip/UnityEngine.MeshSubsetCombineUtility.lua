---@class UnityEngine.MeshSubsetCombineUtility : System.Object
local m = {}

UnityEngine.MeshSubsetCombineUtility = m
return m
