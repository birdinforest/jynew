---@class Unity.Profiling.ProfilerMarkerDataUnit : System.Enum
---@field public Undefined Unity.Profiling.ProfilerMarkerDataUnit @static
---@field public TimeNanoseconds Unity.Profiling.ProfilerMarkerDataUnit @static
---@field public Bytes Unity.Profiling.ProfilerMarkerDataUnit @static
---@field public Count Unity.Profiling.ProfilerMarkerDataUnit @static
---@field public Percent Unity.Profiling.ProfilerMarkerDataUnit @static
---@field public FrequencyHz Unity.Profiling.ProfilerMarkerDataUnit @static
---@field public value__ number
local m = {}

Unity.Profiling.ProfilerMarkerDataUnit = m
return m
