---@class UnityEngine.EnumDataUtility.__c__DisplayClass2_0 : System.Object
---@field public nicifyName fun(arg:string):
local m = {}

UnityEngine.EnumDataUtility.__c__DisplayClass2_0 = m
return m
