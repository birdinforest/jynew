---@class UnityEngine.ShimManager : System.Object
local m = {}

UnityEngine.ShimManager = m
return m
