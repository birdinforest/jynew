---@class UnityEngine.MissingComponentException : System.SystemException
local m = {}

UnityEngine.MissingComponentException = m
return m
