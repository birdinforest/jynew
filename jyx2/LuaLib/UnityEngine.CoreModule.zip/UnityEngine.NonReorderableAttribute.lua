---@class UnityEngine.NonReorderableAttribute : UnityEngine.PropertyAttribute
local m = {}

UnityEngine.NonReorderableAttribute = m
return m
