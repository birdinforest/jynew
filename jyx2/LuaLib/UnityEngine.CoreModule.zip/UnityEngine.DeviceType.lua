---@class UnityEngine.DeviceType : System.Enum
---@field public Unknown UnityEngine.DeviceType @static
---@field public Handheld UnityEngine.DeviceType @static
---@field public Console UnityEngine.DeviceType @static
---@field public Desktop UnityEngine.DeviceType @static
---@field public value__ number
local m = {}

UnityEngine.DeviceType = m
return m
