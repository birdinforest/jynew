---@class UnityEngine.TooltipAttribute : UnityEngine.PropertyAttribute
---@field public tooltip string
local m = {}

UnityEngine.TooltipAttribute = m
return m
