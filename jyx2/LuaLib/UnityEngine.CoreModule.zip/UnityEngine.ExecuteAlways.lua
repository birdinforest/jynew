---@class UnityEngine.ExecuteAlways : System.Attribute
local m = {}

UnityEngine.ExecuteAlways = m
return m
