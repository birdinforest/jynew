---@class Unity.Baselib.LowLevel.Binding.Baselib_NetworkAddress_Family : System.Enum
---@field public Invalid Unity.Baselib.LowLevel.Binding.Baselib_NetworkAddress_Family @static
---@field public IPv4 Unity.Baselib.LowLevel.Binding.Baselib_NetworkAddress_Family @static
---@field public IPv6 Unity.Baselib.LowLevel.Binding.Baselib_NetworkAddress_Family @static
---@field public value__ number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_NetworkAddress_Family = m
return m
