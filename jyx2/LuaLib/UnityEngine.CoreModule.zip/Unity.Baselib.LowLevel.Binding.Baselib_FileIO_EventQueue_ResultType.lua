---@class Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_ResultType : System.Enum
---@field public Baselib_FileIO_EventQueue_Callback Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_ResultType @static
---@field public Baselib_FileIO_EventQueue_OpenFile Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_ResultType @static
---@field public Baselib_FileIO_EventQueue_ReadFile Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_ResultType @static
---@field public Baselib_FileIO_EventQueue_CloseFile Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_ResultType @static
---@field public value__ number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_ResultType = m
return m
