---@class UnityEngine.HeaderAttribute : UnityEngine.PropertyAttribute
---@field public header string
local m = {}

UnityEngine.HeaderAttribute = m
return m
