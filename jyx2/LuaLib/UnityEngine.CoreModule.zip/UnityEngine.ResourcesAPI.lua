---@class UnityEngine.ResourcesAPI : System.Object
---@field public overrideAPI UnityEngine.ResourcesAPI @static
local m = {}

UnityEngine.ResourcesAPI = m
return m
