---@class Unity.Profiling.ProfilerRecorderSample : System.ValueType
---@field public Value number
---@field public Count number
local m = {}

Unity.Profiling.ProfilerRecorderSample = m
return m
