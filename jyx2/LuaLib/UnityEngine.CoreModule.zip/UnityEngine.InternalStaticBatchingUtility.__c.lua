---@class UnityEngine.InternalStaticBatchingUtility.__c : System.Object
---@field public <>9 UnityEngine.InternalStaticBatchingUtility.__c @static
---@field public <>9__5_0 fun(arg:UnityEngine.GameObject): @static
---@field public <>9__5_3 fun(arg:UnityEngine.GameObject): @static
---@field public <>9__6_0 fun(arg:UnityEngine.Material): @static
local m = {}

UnityEngine.InternalStaticBatchingUtility.__c = m
return m
