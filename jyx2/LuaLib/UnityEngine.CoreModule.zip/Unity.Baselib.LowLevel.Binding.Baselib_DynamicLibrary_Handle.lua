---@class Unity.Baselib.LowLevel.Binding.Baselib_DynamicLibrary_Handle : System.ValueType
---@field public handle System.IntPtr
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_DynamicLibrary_Handle = m
return m
