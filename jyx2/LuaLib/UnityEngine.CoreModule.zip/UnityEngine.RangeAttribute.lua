---@class UnityEngine.RangeAttribute : UnityEngine.PropertyAttribute
---@field public min number
---@field public max number
local m = {}

UnityEngine.RangeAttribute = m
return m
