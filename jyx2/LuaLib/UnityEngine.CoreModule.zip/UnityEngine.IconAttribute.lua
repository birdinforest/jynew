---@class UnityEngine.IconAttribute : System.Attribute
---@field public path string
local m = {}

UnityEngine.IconAttribute = m
return m
