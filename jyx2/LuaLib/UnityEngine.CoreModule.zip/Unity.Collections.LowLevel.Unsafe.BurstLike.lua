---@class Unity.Collections.LowLevel.Unsafe.BurstLike : System.Object
local m = {}

Unity.Collections.LowLevel.Unsafe.BurstLike = m
return m
