---@class UnityEngine.LogOption : System.Enum
---@field public None UnityEngine.LogOption @static
---@field public NoStacktrace UnityEngine.LogOption @static
---@field public value__ number
local m = {}

UnityEngine.LogOption = m
return m
