---@class UnityEngine.InternalStaticBatchingUtility.StaticBatcherGOSorter : System.Object
local m = {}

---@virtual
---@param renderer UnityEngine.Renderer
---@return number
function m:GetMaterialId(renderer) end

---@param renderer UnityEngine.Renderer
---@return number
function m:GetLightmapIndex(renderer) end

---@static
---@param go UnityEngine.GameObject
---@return UnityEngine.Renderer
function m.GetRenderer(go) end

---@static
---@param go UnityEngine.GameObject
---@return UnityEngine.Mesh
function m.GetMesh(go) end

---@virtual
---@param renderer UnityEngine.Renderer
---@return number
function m:GetRendererId(renderer) end

---@static
---@param go UnityEngine.GameObject
---@return boolean
function m.GetScaleFlip(go) end

UnityEngine.InternalStaticBatchingUtility.StaticBatcherGOSorter = m
return m
