---@class UnityEngine.GradientUsageAttribute : UnityEngine.PropertyAttribute
---@field public hdr boolean
---@field public colorSpace UnityEngine.ColorSpace
local m = {}

UnityEngine.GradientUsageAttribute = m
return m
