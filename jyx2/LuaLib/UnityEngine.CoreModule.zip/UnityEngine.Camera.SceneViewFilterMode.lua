---@class UnityEngine.Camera.SceneViewFilterMode : System.Enum
---@field public Off UnityEngine.Camera.SceneViewFilterMode @static
---@field public ShowFiltered UnityEngine.Camera.SceneViewFilterMode @static
---@field public value__ number
local m = {}

UnityEngine.Camera.SceneViewFilterMode = m
return m
