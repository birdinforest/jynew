---@class Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_CompletionQueueStatus : System.Enum
---@field public NoResultsAvailable Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_CompletionQueueStatus @static
---@field public ResultsAvailable Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_CompletionQueueStatus @static
---@field public value__ number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_CompletionQueueStatus = m
return m
