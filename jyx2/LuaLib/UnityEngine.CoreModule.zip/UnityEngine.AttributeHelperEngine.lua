---@class UnityEngine.AttributeHelperEngine : System.Object
local m = {}

UnityEngine.AttributeHelperEngine = m
return m
