---@class UnityEngine.UnassignedReferenceException : System.SystemException
local m = {}

UnityEngine.UnassignedReferenceException = m
return m
