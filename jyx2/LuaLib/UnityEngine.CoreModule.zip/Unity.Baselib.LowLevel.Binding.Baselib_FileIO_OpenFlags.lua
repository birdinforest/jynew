---@class Unity.Baselib.LowLevel.Binding.Baselib_FileIO_OpenFlags : System.Enum
---@field public Read Unity.Baselib.LowLevel.Binding.Baselib_FileIO_OpenFlags @static
---@field public Write Unity.Baselib.LowLevel.Binding.Baselib_FileIO_OpenFlags @static
---@field public OpenAlways Unity.Baselib.LowLevel.Binding.Baselib_FileIO_OpenFlags @static
---@field public CreateAlways Unity.Baselib.LowLevel.Binding.Baselib_FileIO_OpenFlags @static
---@field public value__ number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_FileIO_OpenFlags = m
return m
