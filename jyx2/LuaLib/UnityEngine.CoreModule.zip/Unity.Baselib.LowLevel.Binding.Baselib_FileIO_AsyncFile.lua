---@class Unity.Baselib.LowLevel.Binding.Baselib_FileIO_AsyncFile : System.ValueType
---@field public handle System.IntPtr
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_FileIO_AsyncFile = m
return m
