---@class Unity.Profiling.ProfilerCategoryFlags : System.Enum
---@field public None Unity.Profiling.ProfilerCategoryFlags @static
---@field public Builtin Unity.Profiling.ProfilerCategoryFlags @static
---@field public value__ number
local m = {}

Unity.Profiling.ProfilerCategoryFlags = m
return m
