---@class Unity.Baselib.LowLevel.Binding.EventQueueCallback : System.MulticastDelegate
local m = {}

---@virtual
---@param arg0 number
function m:Invoke(arg0) end

---@virtual
---@param arg0 number
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(arg0, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

Unity.Baselib.LowLevel.Binding.EventQueueCallback = m
return m
