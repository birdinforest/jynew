---@class UnityEngine.BatteryStatus : System.Enum
---@field public Unknown UnityEngine.BatteryStatus @static
---@field public Charging UnityEngine.BatteryStatus @static
---@field public Discharging UnityEngine.BatteryStatus @static
---@field public NotCharging UnityEngine.BatteryStatus @static
---@field public Full UnityEngine.BatteryStatus @static
---@field public value__ number
local m = {}

UnityEngine.BatteryStatus = m
return m
