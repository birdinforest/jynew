---@class UnityEngine.SpaceAttribute : UnityEngine.PropertyAttribute
---@field public height number
local m = {}

UnityEngine.SpaceAttribute = m
return m
