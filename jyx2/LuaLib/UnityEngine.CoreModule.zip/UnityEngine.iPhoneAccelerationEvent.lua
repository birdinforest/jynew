---@class UnityEngine.iPhoneAccelerationEvent : System.ValueType
---@field public timeDelta number
---@field public acceleration UnityEngine.Vector3
---@field public deltaTime number
local m = {}

UnityEngine.iPhoneAccelerationEvent = m
return m
