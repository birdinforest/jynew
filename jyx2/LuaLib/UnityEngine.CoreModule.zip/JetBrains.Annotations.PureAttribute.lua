---@class JetBrains.Annotations.PureAttribute : System.Attribute
local m = {}

JetBrains.Annotations.PureAttribute = m
return m
