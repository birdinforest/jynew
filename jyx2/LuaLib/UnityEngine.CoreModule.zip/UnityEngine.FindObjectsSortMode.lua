---@class UnityEngine.FindObjectsSortMode : System.Enum
---@field public None UnityEngine.FindObjectsSortMode @static
---@field public InstanceID UnityEngine.FindObjectsSortMode @static
---@field public value__ number
local m = {}

UnityEngine.FindObjectsSortMode = m
return m
