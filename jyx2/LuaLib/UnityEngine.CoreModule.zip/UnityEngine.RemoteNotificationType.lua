---@class UnityEngine.RemoteNotificationType : System.Enum
---@field public None UnityEngine.RemoteNotificationType @static
---@field public Badge UnityEngine.RemoteNotificationType @static
---@field public Sound UnityEngine.RemoteNotificationType @static
---@field public Alert UnityEngine.RemoteNotificationType @static
---@field public value__ number
local m = {}

UnityEngine.RemoteNotificationType = m
return m
