---@class UnityEngine.LightingSettings.DenoiserType : System.Enum
---@field public None UnityEngine.LightingSettings.DenoiserType @static
---@field public Optix UnityEngine.LightingSettings.DenoiserType @static
---@field public OpenImage UnityEngine.LightingSettings.DenoiserType @static
---@field public RadeonPro UnityEngine.LightingSettings.DenoiserType @static
---@field public value__ number
local m = {}

UnityEngine.LightingSettings.DenoiserType = m
return m
