---@class UnityEngineInternal.GenericStack : System.Collections.Stack
local m = {}

UnityEngineInternal.GenericStack = m
return m
