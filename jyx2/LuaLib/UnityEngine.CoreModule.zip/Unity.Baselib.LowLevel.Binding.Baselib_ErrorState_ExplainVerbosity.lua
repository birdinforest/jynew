---@class Unity.Baselib.LowLevel.Binding.Baselib_ErrorState_ExplainVerbosity : System.Enum
---@field public ErrorType Unity.Baselib.LowLevel.Binding.Baselib_ErrorState_ExplainVerbosity @static
---@field public ErrorType_SourceLocation_Explanation Unity.Baselib.LowLevel.Binding.Baselib_ErrorState_ExplainVerbosity @static
---@field public value__ number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_ErrorState_ExplainVerbosity = m
return m
