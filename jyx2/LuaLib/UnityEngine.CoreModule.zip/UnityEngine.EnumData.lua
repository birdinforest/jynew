---@class UnityEngine.EnumData : System.ValueType
---@field public values System.Enum[]
---@field public flagValues number[]
---@field public displayNames string[]
---@field public names string[]
---@field public tooltip string[]
---@field public flags boolean
---@field public underlyingType System.Type
---@field public unsigned boolean
---@field public serializable boolean
local m = {}

UnityEngine.EnumData = m
return m
