---@class UnityEngine.TextAsset.CreateOptions : System.Enum
---@field public None UnityEngine.TextAsset.CreateOptions @static
---@field public CreateNativeObject UnityEngine.TextAsset.CreateOptions @static
---@field public value__ number
local m = {}

UnityEngine.TextAsset.CreateOptions = m
return m
