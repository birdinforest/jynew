---@class UnityEngine.MeshSubsetCombineUtility.MeshContainer : System.ValueType
---@field public gameObject UnityEngine.GameObject
---@field public instance UnityEngine.MeshSubsetCombineUtility.MeshInstance
---@field public subMeshInstances UnityEngine.MeshSubsetCombineUtility.SubMeshInstance[]
local m = {}

UnityEngine.MeshSubsetCombineUtility.MeshContainer = m
return m
