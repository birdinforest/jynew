---@class Unity.Profiling.ProfilerMarkerWithStringData.AutoScope : System.ValueType
local m = {}

---@virtual
function m:Dispose() end

Unity.Profiling.ProfilerMarkerWithStringData.AutoScope = m
return m
