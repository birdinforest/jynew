---@class UnityEngine.UnhandledExceptionHandler.__c : System.Object
---@field public <>9 UnityEngine.UnhandledExceptionHandler.__c @static
---@field public <>9__0_0 fun(sender:any, e:System.UnhandledExceptionEventArgs) @static
local m = {}

UnityEngine.UnhandledExceptionHandler.__c = m
return m
