---@class UnityEngine.MeshSubsetCombineUtility.SubMeshInstance : System.ValueType
---@field public meshInstanceID number
---@field public vertexOffset number
---@field public gameObjectInstanceID number
---@field public subMeshIndex number
---@field public transform UnityEngine.Matrix4x4
local m = {}

UnityEngine.MeshSubsetCombineUtility.SubMeshInstance = m
return m
