---@class UnityEngine.TextAsset : UnityEngine.Object
---@field public bytes string
---@field public text string
---@field public dataSize number
local m = {}

---@virtual
---@return string
function m:ToString() end

---@return System.ValueType
function m:GetData() end

UnityEngine.TextAsset = m
return m
