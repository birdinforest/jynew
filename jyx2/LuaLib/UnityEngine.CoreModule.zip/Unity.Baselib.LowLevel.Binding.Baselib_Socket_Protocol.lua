---@class Unity.Baselib.LowLevel.Binding.Baselib_Socket_Protocol : System.Enum
---@field public UDP Unity.Baselib.LowLevel.Binding.Baselib_Socket_Protocol @static
---@field public TCP Unity.Baselib.LowLevel.Binding.Baselib_Socket_Protocol @static
---@field public value__ number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_Socket_Protocol = m
return m
