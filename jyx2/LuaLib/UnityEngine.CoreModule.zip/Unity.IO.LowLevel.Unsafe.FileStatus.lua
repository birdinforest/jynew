---@class Unity.IO.LowLevel.Unsafe.FileStatus : System.Enum
---@field public Closed Unity.IO.LowLevel.Unsafe.FileStatus @static
---@field public Pending Unity.IO.LowLevel.Unsafe.FileStatus @static
---@field public Open Unity.IO.LowLevel.Unsafe.FileStatus @static
---@field public OpenFailed Unity.IO.LowLevel.Unsafe.FileStatus @static
---@field public value__ number
local m = {}

Unity.IO.LowLevel.Unsafe.FileStatus = m
return m
