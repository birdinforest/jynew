---@class UnityEngine.FrustumPlanes : System.ValueType
---@field public left number
---@field public right number
---@field public bottom number
---@field public top number
---@field public zNear number
---@field public zFar number
local m = {}

UnityEngine.FrustumPlanes = m
return m
