---@class UnityEngine.PlayerConnectionInternal : System.Object
local m = {}

UnityEngine.PlayerConnectionInternal = m
return m
