---@class UnityEngine.MethodImplOptionsEx : System.Object
---@field public AggressiveInlining number @static
local m = {}

UnityEngine.MethodImplOptionsEx = m
return m
