---@class UnityEngine.NotificationServices : System.Object
local m = {}

---@static
---@param notificationTypes UnityEngine.RemoteNotificationType
function m.RegisterForRemoteNotificationTypes(notificationTypes) end

UnityEngine.NotificationServices = m
return m
