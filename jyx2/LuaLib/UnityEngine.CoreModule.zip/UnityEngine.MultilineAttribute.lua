---@class UnityEngine.MultilineAttribute : UnityEngine.PropertyAttribute
---@field public lines number
local m = {}

UnityEngine.MultilineAttribute = m
return m
