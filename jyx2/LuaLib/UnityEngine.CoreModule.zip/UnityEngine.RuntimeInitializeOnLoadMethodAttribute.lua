---@class UnityEngine.RuntimeInitializeOnLoadMethodAttribute : UnityEngine.Scripting.PreserveAttribute
---@field public loadType UnityEngine.RuntimeInitializeLoadType
local m = {}

UnityEngine.RuntimeInitializeOnLoadMethodAttribute = m
return m
