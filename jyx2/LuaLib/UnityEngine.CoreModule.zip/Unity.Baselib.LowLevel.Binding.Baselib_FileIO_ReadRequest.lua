---@class Unity.Baselib.LowLevel.Binding.Baselib_FileIO_ReadRequest : System.ValueType
---@field public offset number
---@field public buffer System.IntPtr
---@field public size number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_FileIO_ReadRequest = m
return m
