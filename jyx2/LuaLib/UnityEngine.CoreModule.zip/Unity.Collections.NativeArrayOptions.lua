---@class Unity.Collections.NativeArrayOptions : System.Enum
---@field public UninitializedMemory Unity.Collections.NativeArrayOptions @static
---@field public ClearMemory Unity.Collections.NativeArrayOptions @static
---@field public value__ number
local m = {}

Unity.Collections.NativeArrayOptions = m
return m
