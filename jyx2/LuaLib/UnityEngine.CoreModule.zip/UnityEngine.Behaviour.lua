---@class UnityEngine.Behaviour : UnityEngine.Component
---@field public enabled boolean
---@field public isActiveAndEnabled boolean
local m = {}

UnityEngine.Behaviour = m
return m
