---@class UnityEngine.MissingReferenceException : System.SystemException
local m = {}

UnityEngine.MissingReferenceException = m
return m
