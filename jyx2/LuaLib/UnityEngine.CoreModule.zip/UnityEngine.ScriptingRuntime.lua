---@class UnityEngine.ScriptingRuntime : System.Object
local m = {}

---@static
---@return string[]
function m.GetAllUserAssemblies() end

UnityEngine.ScriptingRuntime = m
return m
