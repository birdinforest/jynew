---@class UnityEngine.EnumInfo : System.Object
---@field public names string[]
---@field public values number[]
---@field public annotations string[]
---@field public isFlags boolean
local m = {}

UnityEngine.EnumInfo = m
return m
