---@class UnityEngine.SelectionBaseAttribute : System.Attribute
local m = {}

UnityEngine.SelectionBaseAttribute = m
return m
