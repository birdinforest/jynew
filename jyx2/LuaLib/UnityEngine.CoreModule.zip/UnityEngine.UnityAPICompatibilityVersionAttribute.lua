---@class UnityEngine.UnityAPICompatibilityVersionAttribute : System.Attribute
---@field public version string
local m = {}

UnityEngine.UnityAPICompatibilityVersionAttribute = m
return m
