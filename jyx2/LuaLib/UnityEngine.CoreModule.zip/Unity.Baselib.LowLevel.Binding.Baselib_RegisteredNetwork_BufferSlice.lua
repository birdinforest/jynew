---@class Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_BufferSlice : System.ValueType
---@field public id System.IntPtr
---@field public data System.IntPtr
---@field public size number
---@field public offset number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_BufferSlice = m
return m
