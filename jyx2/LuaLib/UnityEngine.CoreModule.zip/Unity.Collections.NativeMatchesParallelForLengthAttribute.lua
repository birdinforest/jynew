---@class Unity.Collections.NativeMatchesParallelForLengthAttribute : System.Attribute
local m = {}

Unity.Collections.NativeMatchesParallelForLengthAttribute = m
return m
