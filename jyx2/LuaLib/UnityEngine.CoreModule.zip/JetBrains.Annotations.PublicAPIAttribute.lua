---@class JetBrains.Annotations.PublicAPIAttribute : System.Attribute
---@field public Comment string
local m = {}

JetBrains.Annotations.PublicAPIAttribute = m
return m
