---@class Unity.Burst.BurstAuthorizedExternalMethodAttribute : System.Attribute
local m = {}

Unity.Burst.BurstAuthorizedExternalMethodAttribute = m
return m
