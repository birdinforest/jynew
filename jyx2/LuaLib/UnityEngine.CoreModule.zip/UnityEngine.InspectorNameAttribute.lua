---@class UnityEngine.InspectorNameAttribute : UnityEngine.PropertyAttribute
---@field public displayName string
local m = {}

UnityEngine.InspectorNameAttribute = m
return m
