---@class Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_Result_OpenFile : System.ValueType
---@field public fileSize number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_FileIO_EventQueue_Result_OpenFile = m
return m
