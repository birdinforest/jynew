---@class UnityEngine.TextAreaAttribute : UnityEngine.PropertyAttribute
---@field public minLines number
---@field public maxLines number
local m = {}

UnityEngine.TextAreaAttribute = m
return m
