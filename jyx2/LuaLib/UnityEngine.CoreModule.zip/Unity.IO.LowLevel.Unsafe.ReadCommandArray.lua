---@class Unity.IO.LowLevel.Unsafe.ReadCommandArray : System.ValueType
---@field public ReadCommands Unity.IO.LowLevel.Unsafe.ReadCommand*
---@field public CommandCount number
local m = {}

Unity.IO.LowLevel.Unsafe.ReadCommandArray = m
return m
