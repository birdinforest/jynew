---@class Unity.IO.LowLevel.Unsafe.FileHandle : System.ValueType
---@field public Status Unity.IO.LowLevel.Unsafe.FileStatus
---@field public JobHandle Unity.Jobs.JobHandle
local m = {}

---@return boolean
function m:IsValid() end

---@overload fun():
---@param dependency Unity.Jobs.JobHandle
---@return Unity.Jobs.JobHandle
function m:Close(dependency) end

Unity.IO.LowLevel.Unsafe.FileHandle = m
return m
