---@class Mono.ValueTuple_2_T1_T2_ : System.ValueType
---@field public Item1 any
---@field public Item2 any
local m = {}

Mono.ValueTuple_2_T1_T2_ = m
return m
