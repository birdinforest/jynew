---@class InteropErrorExtensions : System.Object
local m = {}

---@static
---@param error Interop.Error
---@return Interop.ErrorInfo
function m.Info(error) end

InteropErrorExtensions = m
return m
