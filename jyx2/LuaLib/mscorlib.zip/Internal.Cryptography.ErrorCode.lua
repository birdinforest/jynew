---@class Internal.Cryptography.ErrorCode : System.Object
---@field public CERT_E_CHAINING number @static
---@field public CERT_E_CRITICAL number @static
---@field public CERT_E_EXPIRED number @static
---@field public CERT_E_INVALID_NAME number @static
---@field public CERT_E_INVALID_POLICY number @static
---@field public CERT_E_UNTRUSTEDROOT number @static
---@field public CERT_E_VALIDITYPERIODNESTING number @static
---@field public CERT_E_WRONG_USAGE number @static
---@field public CERTSRV_E_WEAK_SIGNATURE_OR_KEY number @static
---@field public CRYPT_E_NO_REVOCATION_CHECK number @static
---@field public CRYPT_E_NOT_FOUND number @static
---@field public CRYPT_E_REVOCATION_OFFLINE number @static
---@field public CRYPT_E_REVOKED number @static
---@field public CRYPT_E_SIGNER_NOT_FOUND number @static
---@field public E_POINTER number @static
---@field public ERROR_INVALID_PARAMETER number @static
---@field public HRESULT_INVALID_HANDLE number @static
---@field public NTE_BAD_PUBLIC_KEY number @static
---@field public TRUST_E_BASIC_CONSTRAINTS number @static
---@field public TRUST_E_CERT_SIGNATURE number @static
---@field public TRUST_E_EXPLICIT_DISTRUST number @static
local m = {}

Internal.Cryptography.ErrorCode = m
return m
