---@class Microsoft.Win32.SafeHandles.SafeDirectoryHandle : System.Runtime.InteropServices.SafeHandle
---@field public IsInvalid boolean
local m = {}

Microsoft.Win32.SafeHandles.SafeDirectoryHandle = m
return m
