---@class Mono.ISystemCertificateProvider : table
local m = {}

---@overload fun(data:string): @abstract
---@overload fun(data:string, password:Microsoft.Win32.SafeHandles.SafePasswordHandle, keyStorageFlags:System.Security.Cryptography.X509Certificates.X509KeyStorageFlags, importFlags:Mono.CertificateImportFlags): @abstract
---@overload fun(data:string, password:Microsoft.Win32.SafeHandles.SafePasswordHandle, keyStorageFlags:System.Security.Cryptography.X509Certificates.X509KeyStorageFlags): @abstract
---@overload fun(cert:System.Security.Cryptography.X509Certificates.X509Certificate, importFlags:Mono.CertificateImportFlags): @abstract
---@overload fun(cert:System.Security.Cryptography.X509Certificates.X509Certificate): @abstract
---@abstract
---@param data string
---@param importFlags Mono.CertificateImportFlags
---@return System.Security.Cryptography.X509Certificates.X509CertificateImpl
function m:Import(data, importFlags) end

Mono.ISystemCertificateProvider = m
return m
