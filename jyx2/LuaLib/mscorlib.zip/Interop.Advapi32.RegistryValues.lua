---@class Interop.Advapi32.RegistryValues : System.Object
local m = {}

Interop.Advapi32.RegistryValues = m
return m
