---@class System.TimeZoneInfo.CachedData : System.Object
---@field public _systemTimeZones System.Collections.Generic.Dictionary_2_System_String_System_TimeZoneInfo_
---@field public _readOnlySystemTimeZones System.TimeZoneInfo[]
---@field public _allSystemTimeZonesRead boolean
---@field public Local System.TimeZoneInfo
local m = {}

---@param timeZone System.TimeZoneInfo
---@return System.DateTimeKind
function m:GetCorrespondingKind(timeZone) end

System.TimeZoneInfo.CachedData = m
return m
