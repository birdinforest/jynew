---@class System.TimeZoneInfo.TZifType : System.ValueType
---@field public Length number @static
---@field public UtcOffset System.TimeSpan
---@field public IsDst boolean
---@field public AbbreviationIndex number
local m = {}

System.TimeZoneInfo.TZifType = m
return m
