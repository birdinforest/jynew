---@class Mono.Globalization.Unicode.TailoringInfo : System.Object
---@field public LCID number
---@field public TailoringIndex number
---@field public TailoringCount number
---@field public FrenchSort boolean
local m = {}

Mono.Globalization.Unicode.TailoringInfo = m
return m
