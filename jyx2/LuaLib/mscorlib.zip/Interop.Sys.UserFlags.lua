---@class Interop.Sys.UserFlags : System.Enum
---@field public UF_HIDDEN Interop.Sys.UserFlags @static
---@field public value__ number
local m = {}

Interop.Sys.UserFlags = m
return m
