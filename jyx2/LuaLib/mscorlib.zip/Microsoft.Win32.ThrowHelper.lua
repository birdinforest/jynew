---@class Microsoft.Win32.ThrowHelper : System.Object
local m = {}

Microsoft.Win32.ThrowHelper = m
return m
