---@class System.FlagsAttribute : System.Attribute
local m = {}

System.FlagsAttribute = m
return m
