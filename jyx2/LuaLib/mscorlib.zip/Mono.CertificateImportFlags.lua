---@class Mono.CertificateImportFlags : System.Enum
---@field public None Mono.CertificateImportFlags @static
---@field public DisableNativeBackend Mono.CertificateImportFlags @static
---@field public DisableAutomaticFallback Mono.CertificateImportFlags @static
---@field public value__ number
local m = {}

Mono.CertificateImportFlags = m
return m
