---@class System.MutableDecimal : System.ValueType
---@field public Flags number
---@field public High number
---@field public Low number
---@field public Mid number
---@field public IsNegative boolean
---@field public Scale number
local m = {}

System.MutableDecimal = m
return m
