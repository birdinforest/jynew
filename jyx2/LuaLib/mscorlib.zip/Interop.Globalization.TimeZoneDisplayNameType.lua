---@class Interop.Globalization.TimeZoneDisplayNameType : System.Enum
---@field public Generic Interop.Globalization.TimeZoneDisplayNameType @static
---@field public Standard Interop.Globalization.TimeZoneDisplayNameType @static
---@field public DaylightSavings Interop.Globalization.TimeZoneDisplayNameType @static
---@field public value__ number
local m = {}

Interop.Globalization.TimeZoneDisplayNameType = m
return m
