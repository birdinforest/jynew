---@class System.String.ProbabilisticMap : System.ValueType
local m = {}

System.String.ProbabilisticMap = m
return m
