---@class System.HResults : System.Object
local m = {}

System.HResults = m
return m
