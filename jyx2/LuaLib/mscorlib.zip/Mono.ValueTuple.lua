---@class Mono.ValueTuple : System.ValueType
local m = {}

Mono.ValueTuple = m
return m
