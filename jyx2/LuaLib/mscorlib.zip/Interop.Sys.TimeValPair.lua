---@class Interop.Sys.TimeValPair : System.ValueType
local m = {}

Interop.Sys.TimeValPair = m
return m
