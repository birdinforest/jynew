---@class Internal.Runtime.Augments.RuntimeThread : System.Object
---@field public IsBackground boolean
local m = {}

function m:ResetThreadPoolThread() end

---@static
---@return Internal.Runtime.Augments.RuntimeThread
function m.InitializeThreadPoolThread() end

---@static
---@param start fun(obj:any)
---@param maxStackSize number
---@return Internal.Runtime.Augments.RuntimeThread
function m.Create(start, maxStackSize) end

---@overload fun(state:any)
function m:Start() end

---@static
---@param millisecondsTimeout number
function m.Sleep(millisecondsTimeout) end

---@static
---@return boolean
function m.Yield() end

---@static
---@param iterations number
---@return boolean
function m.SpinWait(iterations) end

---@static
---@return number
function m.GetCurrentProcessorId() end

Internal.Runtime.Augments.RuntimeThread = m
return m
