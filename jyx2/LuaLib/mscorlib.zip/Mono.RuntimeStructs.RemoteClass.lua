---@class Mono.RuntimeStructs.RemoteClass : System.ValueType
local m = {}

Mono.RuntimeStructs.RemoteClass = m
return m
