---@class System.Guid.GuidParseThrowStyle : System.Enum
---@field public None System.Guid.GuidParseThrowStyle @static
---@field public All System.Guid.GuidParseThrowStyle @static
---@field public AllButOverflow System.Guid.GuidParseThrowStyle @static
---@field public value__ number
local m = {}

System.Guid.GuidParseThrowStyle = m
return m
