---@class System.ThrowHelper : System.Object
local m = {}

---@static
---@return boolean, System.Int32
function m.TryFormatThrowFormatException() end

---@static
---@return boolean, any, System.Int32
function m.TryParseThrowFormatException() end

---@overload fun(array:System.Array, start:number) @static
---@static
---@param startSegment any
---@param startIndex number
---@param endSegment any
function m.ThrowArgumentValidationException(startSegment, startIndex, endSegment) end

---@static
---@param start number
function m.ThrowStartOrEndArgumentValidationException(start) end

System.ThrowHelper = m
return m
