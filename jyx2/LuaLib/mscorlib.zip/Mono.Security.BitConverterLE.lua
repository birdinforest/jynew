---@class Mono.Security.BitConverterLE : System.Object
local m = {}

Mono.Security.BitConverterLE = m
return m
