---@class System.NotImplemented : System.Object
local m = {}

System.NotImplemented = m
return m
