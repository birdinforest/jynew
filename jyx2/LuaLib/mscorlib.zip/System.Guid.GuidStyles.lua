---@class System.Guid.GuidStyles : System.Enum
---@field public None System.Guid.GuidStyles @static
---@field public AllowParenthesis System.Guid.GuidStyles @static
---@field public AllowBraces System.Guid.GuidStyles @static
---@field public AllowDashes System.Guid.GuidStyles @static
---@field public AllowHexPrefix System.Guid.GuidStyles @static
---@field public RequireParenthesis System.Guid.GuidStyles @static
---@field public RequireBraces System.Guid.GuidStyles @static
---@field public RequireDashes System.Guid.GuidStyles @static
---@field public RequireHexPrefix System.Guid.GuidStyles @static
---@field public HexFormat System.Guid.GuidStyles @static
---@field public NumberFormat System.Guid.GuidStyles @static
---@field public DigitFormat System.Guid.GuidStyles @static
---@field public BraceFormat System.Guid.GuidStyles @static
---@field public ParenthesisFormat System.Guid.GuidStyles @static
---@field public Any System.Guid.GuidStyles @static
---@field public value__ number
local m = {}

System.Guid.GuidStyles = m
return m
