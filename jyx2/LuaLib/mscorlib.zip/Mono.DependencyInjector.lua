---@class Mono.DependencyInjector : System.Object
local m = {}

Mono.DependencyInjector = m
return m
