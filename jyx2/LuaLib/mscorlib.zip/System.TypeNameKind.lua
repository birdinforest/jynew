---@class System.TypeNameKind : System.Enum
---@field public Name System.TypeNameKind @static
---@field public ToString System.TypeNameKind @static
---@field public SerializationName System.TypeNameKind @static
---@field public FullName System.TypeNameKind @static
---@field public value__ number
local m = {}

System.TypeNameKind = m
return m
