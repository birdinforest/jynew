---@class System.Type : System.Reflection.MemberInfo
---@field public Delimiter number @static
---@field public EmptyTypes System.Type[] @static
---@field public Missing any @static
---@field public FilterAttribute fun(m:System.Reflection.MemberInfo, filterCriteria:any): @static
---@field public FilterName fun(m:System.Reflection.MemberInfo, filterCriteria:any): @static
---@field public FilterNameIgnoreCase fun(m:System.Reflection.MemberInfo, filterCriteria:any): @static
---@field public DefaultBinder System.Reflection.Binder @static
---@field public IsSerializable boolean
---@field public ContainsGenericParameters boolean
---@field public IsVisible boolean
---@field public MemberType System.Reflection.MemberTypes
---@field public Namespace string
---@field public AssemblyQualifiedName string
---@field public FullName string
---@field public Assembly System.Reflection.Assembly
---@field public Module System.Reflection.Module
---@field public IsNested boolean
---@field public DeclaringType System.Type
---@field public DeclaringMethod System.Reflection.MethodBase
---@field public ReflectedType System.Type
---@field public UnderlyingSystemType System.Type
---@field public IsTypeDefinition boolean
---@field public IsArray boolean
---@field public IsByRef boolean
---@field public IsPointer boolean
---@field public IsConstructedGenericType boolean
---@field public IsGenericParameter boolean
---@field public IsGenericTypeParameter boolean
---@field public IsGenericMethodParameter boolean
---@field public IsGenericType boolean
---@field public IsGenericTypeDefinition boolean
---@field public IsSZArray boolean
---@field public IsVariableBoundArray boolean
---@field public IsByRefLike boolean
---@field public HasElementType boolean
---@field public GenericTypeArguments System.Type[]
---@field public GenericParameterPosition number
---@field public GenericParameterAttributes System.Reflection.GenericParameterAttributes
---@field public Attributes System.Reflection.TypeAttributes
---@field public IsAbstract boolean
---@field public IsImport boolean
---@field public IsSealed boolean
---@field public IsSpecialName boolean
---@field public IsClass boolean
---@field public IsNestedAssembly boolean
---@field public IsNestedFamANDAssem boolean
---@field public IsNestedFamily boolean
---@field public IsNestedFamORAssem boolean
---@field public IsNestedPrivate boolean
---@field public IsNestedPublic boolean
---@field public IsNotPublic boolean
---@field public IsPublic boolean
---@field public IsAutoLayout boolean
---@field public IsExplicitLayout boolean
---@field public IsLayoutSequential boolean
---@field public IsAnsiClass boolean
---@field public IsAutoClass boolean
---@field public IsUnicodeClass boolean
---@field public IsCOMObject boolean
---@field public IsContextful boolean
---@field public IsCollectible boolean
---@field public IsEnum boolean
---@field public IsMarshalByRef boolean
---@field public IsPrimitive boolean
---@field public IsValueType boolean
---@field public IsSignatureType boolean
---@field public IsSecurityCritical boolean
---@field public IsSecuritySafeCritical boolean
---@field public IsSecurityTransparent boolean
---@field public StructLayoutAttribute System.Runtime.InteropServices.StructLayoutAttribute
---@field public TypeInitializer System.Reflection.ConstructorInfo
---@field public TypeHandle System.RuntimeTypeHandle
---@field public GUID System.Guid
---@field public BaseType System.Type
---@field public IsInterface boolean
local m = {}

---@virtual
---@param value any
---@return boolean
function m:IsEnumDefined(value) end

---@virtual
---@param value any
---@return string
function m:GetEnumName(value) end

---@virtual
---@return string[]
function m:GetEnumNames() end

---@virtual
---@param filter fun(m:System.Type, filterCriteria:any):
---@param filterCriteria any
---@return System.Type[]
function m:FindInterfaces(filter, filterCriteria) end

---@virtual
---@param memberType System.Reflection.MemberTypes
---@param bindingAttr System.Reflection.BindingFlags
---@param filter fun(m:System.Reflection.MemberInfo, filterCriteria:any):
---@param filterCriteria any
---@return System.Reflection.MemberInfo[]
function m:FindMembers(memberType, bindingAttr, filter, filterCriteria) end

---@virtual
---@param c System.Type
---@return boolean
function m:IsSubclassOf(c) end

---@virtual
---@param c System.Type
---@return boolean
function m:IsAssignableFrom(c) end

---@overload fun(typeName:string, throwOnError:boolean, ignoreCase:boolean): @static
---@overload fun(typeName:string, throwOnError:boolean): @static
---@overload fun(typeName:string): @static
---@overload fun(typeName:string, assemblyResolver:fun(arg:System.Reflection.AssemblyName):, typeResolver:fun(arg1:System.Reflection.Assembly, arg2:string, arg3:boolean):): @static
---@overload fun(typeName:string, assemblyResolver:fun(arg:System.Reflection.AssemblyName):, typeResolver:fun(arg1:System.Reflection.Assembly, arg2:string, arg3:boolean):, throwOnError:boolean): @static
---@overload fun(typeName:string, assemblyResolver:fun(arg:System.Reflection.AssemblyName):, typeResolver:fun(arg1:System.Reflection.Assembly, arg2:string, arg3:boolean):, throwOnError:boolean, ignoreCase:boolean): @static
---@virtual
---@return System.Type
function m:GetType() end

---@abstract
---@return System.Type
function m:GetElementType() end

---@virtual
---@return number
function m:GetArrayRank() end

---@virtual
---@return System.Type
function m:GetGenericTypeDefinition() end

---@virtual
---@return System.Type[]
function m:GetGenericArguments() end

---@virtual
---@return System.Type[]
function m:GetGenericParameterConstraints() end

---@overload fun(bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]): @virtual
---@overload fun(bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, callConvention:System.Reflection.CallingConventions, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]): @virtual
---@virtual
---@param types System.Type[]
---@return System.Reflection.ConstructorInfo
function m:GetConstructor(types) end

---@overload fun(bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@return System.Reflection.ConstructorInfo[]
function m:GetConstructors() end

---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@param name string
---@return System.Reflection.EventInfo
function m:GetEvent(name) end

---@overload fun(bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@return System.Reflection.EventInfo[]
function m:GetEvents() end

---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@param name string
---@return System.Reflection.FieldInfo
function m:GetField(name) end

---@overload fun(bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@return System.Reflection.FieldInfo[]
function m:GetFields() end

---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags): @virtual
---@overload fun(name:string, type:System.Reflection.MemberTypes, bindingAttr:System.Reflection.BindingFlags): @virtual
---@virtual
---@param name string
---@return System.Reflection.MemberInfo[]
function m:GetMember(name) end

---@overload fun(bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@return System.Reflection.MemberInfo[]
function m:GetMembers() end

---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags): @virtual
---@overload fun(name:string, types:System.Type[]): @virtual
---@overload fun(name:string, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]): @virtual
---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]): @virtual
---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, callConvention:System.Reflection.CallingConventions, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]): @virtual
---@overload fun(name:string, genericParameterCount:number, types:System.Type[]):
---@overload fun(name:string, genericParameterCount:number, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]):
---@overload fun(name:string, genericParameterCount:number, bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]):
---@overload fun(name:string, genericParameterCount:number, bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, callConvention:System.Reflection.CallingConventions, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]):
---@virtual
---@param name string
---@return System.Reflection.MethodInfo
function m:GetMethod(name) end

---@overload fun(bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@return System.Reflection.MethodInfo[]
function m:GetMethods() end

---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@param name string
---@return System.Type
function m:GetNestedType(name) end

---@overload fun(bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@return System.Type[]
function m:GetNestedTypes() end

---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags): @virtual
---@overload fun(name:string, returnType:System.Type): @virtual
---@overload fun(name:string, types:System.Type[]): @virtual
---@overload fun(name:string, returnType:System.Type, types:System.Type[]): @virtual
---@overload fun(name:string, returnType:System.Type, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]): @virtual
---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, returnType:System.Type, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]): @virtual
---@virtual
---@param name string
---@return System.Reflection.PropertyInfo
function m:GetProperty(name) end

---@overload fun(bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@return System.Reflection.PropertyInfo[]
function m:GetProperties() end

---@virtual
---@return System.Reflection.MemberInfo[]
function m:GetDefaultMembers() end

---@static
---@param o any
---@return System.RuntimeTypeHandle
function m.GetTypeHandle(o) end

---@static
---@param args any[]
---@return System.Type[]
function m.GetTypeArray(args) end

---@static
---@param type System.Type
---@return System.TypeCode
function m.GetTypeCode(type) end

---@overload fun(clsid:System.Guid, throwOnError:boolean): @static
---@overload fun(clsid:System.Guid, server:string): @static
---@overload fun(clsid:System.Guid, server:string, throwOnError:boolean): @static
---@static
---@param clsid System.Guid
---@return System.Type
function m.GetTypeFromCLSID(clsid) end

---@overload fun(progID:string, throwOnError:boolean): @static
---@overload fun(progID:string, server:string): @static
---@overload fun(progID:string, server:string, throwOnError:boolean): @static
---@static
---@param progID string
---@return System.Type
function m.GetTypeFromProgID(progID) end

---@overload fun(name:string, invokeAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, target:any, args:any[], culture:System.Globalization.CultureInfo): @virtual
---@overload fun(name:string, invokeAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, target:any, args:any[], modifiers:System.Reflection.ParameterModifier[], culture:System.Globalization.CultureInfo, namedParameters:string[]): @abstract
---@virtual
---@param name string
---@param invokeAttr System.Reflection.BindingFlags
---@param binder System.Reflection.Binder
---@param target any
---@param args any[]
---@return any
function m:InvokeMember(name, invokeAttr, binder, target, args) end

---@overload fun(name:string, ignoreCase:boolean): @abstract
---@virtual
---@param name string
---@return System.Type
function m:GetInterface(name) end

---@abstract
---@return System.Type[]
function m:GetInterfaces() end

---@virtual
---@param interfaceType System.Type
---@return System.Reflection.InterfaceMapping
function m:GetInterfaceMap(interfaceType) end

---@virtual
---@param o any
---@return boolean
function m:IsInstanceOfType(o) end

---@virtual
---@param other System.Type
---@return boolean
function m:IsEquivalentTo(other) end

---@virtual
---@return System.Type
function m:GetEnumUnderlyingType() end

---@virtual
---@return System.Array
function m:GetEnumValues() end

---@overload fun(rank:number): @virtual
---@virtual
---@return System.Type
function m:MakeArrayType() end

---@virtual
---@return System.Type
function m:MakeByRefType() end

---@overload fun(): @virtual
---@virtual
---@param ... System.Type|System.Type[]
---@return System.Type
function m:MakeGenericType(...) end

---@virtual
---@return System.Type
function m:MakePointerType() end

---@overload fun(genericTypeDefinition:System.Type): @static
---@static
---@param genericTypeDefinition System.Type
---@param ... System.Type|System.Type[]
---@return System.Type
function m.MakeGenericSignatureType(genericTypeDefinition, ...) end

---@static
---@param position number
---@return System.Type
function m.MakeGenericMethodParameter(position) end

---@virtual
---@return string
function m:ToString() end

---@overload fun(o:System.Type): @virtual
---@virtual
---@param o any
---@return boolean
function m:Equals(o) end

---@virtual
---@return number
function m:GetHashCode() end

---@static
---@param handle System.RuntimeTypeHandle
---@return System.Type
function m.GetTypeFromHandle(handle) end

---@static
---@param left System.Type
---@param right System.Type
---@return boolean
function m.op_Equality(left, right) end

---@static
---@param left System.Type
---@param right System.Type
---@return boolean
function m.op_Inequality(left, right) end

---@static
---@param typeName string
---@param throwIfNotFound boolean
---@param ignoreCase boolean
---@return System.Type
function m.ReflectionOnlyGetType(typeName, throwIfNotFound, ignoreCase) end

---@extension
---@return System.Reflection.TypeInfo
function m.GetTypeInfo() end

---@extension
---@param parameter System.Reflection.ParameterInfo
---@return boolean
function m.MatchesParameterTypeExactly(parameter) end

---@extension
---@return System.Collections.Generic.IEnumerable_1_System_Reflection_FieldInfo_
function m.GetRuntimeFields() end

---@extension
---@return System.Collections.Generic.IEnumerable_1_System_Reflection_MethodInfo_
function m.GetRuntimeMethods() end

---@extension
---@return System.Collections.Generic.IEnumerable_1_System_Reflection_PropertyInfo_
function m.GetRuntimeProperties() end

---@extension
---@return System.Collections.Generic.IEnumerable_1_System_Reflection_EventInfo_
function m.GetRuntimeEvents() end

---@extension
---@param name string
---@return System.Reflection.FieldInfo
function m.GetRuntimeField(name) end

---@extension
---@param name string
---@param parameters System.Type[]
---@return System.Reflection.MethodInfo
function m.GetRuntimeMethod(name, parameters) end

---@extension
---@param name string
---@return System.Reflection.PropertyInfo
function m.GetRuntimeProperty(name) end

---@extension
---@param name string
---@return System.Reflection.EventInfo
function m.GetRuntimeEvent(name) end

---@extension
---@return boolean
function m.IsValueType() end

---@extension
---@return boolean
function m.IsEnum() end

---@extension
---@return boolean
function m.IsPrimitive() end

---@extension
---@return boolean
function m.IsAbstract() end

---@extension
---@return boolean
function m.IsSealed() end

---@extension
---@return boolean
function m.IsInterface() end

---@extension
---@return boolean
function m.IsClass() end

---@extension
---@return System.Type
function m.BaseType() end

---@extension
---@return boolean
function m.IsGenericType() end

---@extension
---@return boolean
function m.IsGenericTypeDefinition() end

---@extension
---@return boolean
function m.IsNestedPublic() end

---@extension
---@return boolean
function m.IsPublic() end

---@extension
---@return string
function m.GetFriendlyName() end

System.Type = m
return m
