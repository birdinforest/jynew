---@class System.UnhandledExceptionEventArgs : System.EventArgs
---@field public ExceptionObject any
---@field public IsTerminating boolean
local m = {}

System.UnhandledExceptionEventArgs = m
return m
