---@class Microsoft.CodeAnalysis.EmbeddedAttribute : System.Attribute
local m = {}

Microsoft.CodeAnalysis.EmbeddedAttribute = m
return m
