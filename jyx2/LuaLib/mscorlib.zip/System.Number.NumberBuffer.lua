---@class System.Number.NumberBuffer : System.ValueType
---@field public precision number
---@field public scale number
---@field public sign boolean
---@field public digits System.Char*
local m = {}

System.Number.NumberBuffer = m
return m
