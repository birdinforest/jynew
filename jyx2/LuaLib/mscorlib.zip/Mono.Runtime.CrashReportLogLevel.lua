---@class Mono.Runtime.CrashReportLogLevel : System.Enum
---@field public MonoSummaryNone Mono.Runtime.CrashReportLogLevel @static
---@field public MonoSummarySetup Mono.Runtime.CrashReportLogLevel @static
---@field public MonoSummarySuspendHandshake Mono.Runtime.CrashReportLogLevel @static
---@field public MonoSummaryUnmanagedStacks Mono.Runtime.CrashReportLogLevel @static
---@field public MonoSummaryManagedStacks Mono.Runtime.CrashReportLogLevel @static
---@field public MonoSummaryStateWriter Mono.Runtime.CrashReportLogLevel @static
---@field public MonoSummaryStateWriterDone Mono.Runtime.CrashReportLogLevel @static
---@field public MonoSummaryMerpWriter Mono.Runtime.CrashReportLogLevel @static
---@field public MonoSummaryMerpInvoke Mono.Runtime.CrashReportLogLevel @static
---@field public MonoSummaryCleanup Mono.Runtime.CrashReportLogLevel @static
---@field public MonoSummaryDone Mono.Runtime.CrashReportLogLevel @static
---@field public MonoSummaryDoubleFault Mono.Runtime.CrashReportLogLevel @static
---@field public value__ number
local m = {}

Mono.Runtime.CrashReportLogLevel = m
return m
