---@class Internal.Runtime.Augments.CausalitySynchronousWork : System.Enum
---@field public CompletionNotification Internal.Runtime.Augments.CausalitySynchronousWork @static
---@field public ProgressNotification Internal.Runtime.Augments.CausalitySynchronousWork @static
---@field public Execution Internal.Runtime.Augments.CausalitySynchronousWork @static
---@field public value__ number
local m = {}

Internal.Runtime.Augments.CausalitySynchronousWork = m
return m
