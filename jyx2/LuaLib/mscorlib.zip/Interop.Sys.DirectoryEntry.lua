---@class Interop.Sys.DirectoryEntry : System.ValueType
local m = {}

Interop.Sys.DirectoryEntry = m
return m
