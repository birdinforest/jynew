---@class System.SequencePosition : System.ValueType
local m = {}

---@return any
function m:GetObject() end

---@return number
function m:GetInteger() end

---@overload fun(obj:any): @virtual
---@virtual
---@param other System.SequencePosition
---@return boolean
function m:Equals(other) end

---@virtual
---@return number
function m:GetHashCode() end

System.SequencePosition = m
return m
