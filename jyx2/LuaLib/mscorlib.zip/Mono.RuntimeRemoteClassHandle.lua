---@class Mono.RuntimeRemoteClassHandle : System.ValueType
local m = {}

Mono.RuntimeRemoteClassHandle = m
return m
