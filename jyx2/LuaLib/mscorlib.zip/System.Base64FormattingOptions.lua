---@class System.Base64FormattingOptions : System.Enum
---@field public None System.Base64FormattingOptions @static
---@field public InsertLineBreaks System.Base64FormattingOptions @static
---@field public value__ number
local m = {}

System.Base64FormattingOptions = m
return m
