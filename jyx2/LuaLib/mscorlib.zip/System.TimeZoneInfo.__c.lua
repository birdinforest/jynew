---@class System.TimeZoneInfo.__c : System.Object
---@field public <>9 System.TimeZoneInfo.__c @static
---@field public <>9__34_1 fun(arg:number): @static
---@field public <>9__34_0 fun(arg:number): @static
---@field public <>9__35_0 fun(arg:number): @static
---@field public <>9__37_0 fun(arg:number): @static
---@field public <>9__38_0 fun(arg:number): @static
---@field public <>9__113_0 fun(x:System.TimeZoneInfo, y:System.TimeZoneInfo): @static
---@field public <>9__161_0 fun(x:System.TimeZoneInfo.AdjustmentRule, y:System.TimeZoneInfo.AdjustmentRule): @static
local m = {}

System.TimeZoneInfo.__c = m
return m
