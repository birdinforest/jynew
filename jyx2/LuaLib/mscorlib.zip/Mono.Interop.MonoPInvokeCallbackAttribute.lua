---@class Mono.Interop.MonoPInvokeCallbackAttribute : System.Attribute
local m = {}

Mono.Interop.MonoPInvokeCallbackAttribute = m
return m
