---@class Mono.ValueTuple_3_T1_T2_T3_ : System.ValueType
---@field public Item1 any
---@field public Item2 any
---@field public Item3 any
local m = {}

Mono.ValueTuple_3_T1_T2_T3_ = m
return m
