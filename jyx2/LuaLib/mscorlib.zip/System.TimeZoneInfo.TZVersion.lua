---@class System.TimeZoneInfo.TZVersion : System.Enum
---@field public V1 System.TimeZoneInfo.TZVersion @static
---@field public V2 System.TimeZoneInfo.TZVersion @static
---@field public V3 System.TimeZoneInfo.TZVersion @static
---@field public value__ number
local m = {}

System.TimeZoneInfo.TZVersion = m
return m
