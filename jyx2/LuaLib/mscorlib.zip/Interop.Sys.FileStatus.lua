---@class Interop.Sys.FileStatus : System.ValueType
local m = {}

Interop.Sys.FileStatus = m
return m
