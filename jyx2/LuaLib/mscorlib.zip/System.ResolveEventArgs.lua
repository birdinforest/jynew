---@class System.ResolveEventArgs : System.EventArgs
---@field public Name string
---@field public RequestingAssembly System.Reflection.Assembly
local m = {}

System.ResolveEventArgs = m
return m
