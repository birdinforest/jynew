---@class System.DefaultBinder.Primitives : System.Enum
---@field public Boolean System.DefaultBinder.Primitives @static
---@field public Char System.DefaultBinder.Primitives @static
---@field public SByte System.DefaultBinder.Primitives @static
---@field public Byte System.DefaultBinder.Primitives @static
---@field public Int16 System.DefaultBinder.Primitives @static
---@field public UInt16 System.DefaultBinder.Primitives @static
---@field public Int32 System.DefaultBinder.Primitives @static
---@field public UInt32 System.DefaultBinder.Primitives @static
---@field public Int64 System.DefaultBinder.Primitives @static
---@field public UInt64 System.DefaultBinder.Primitives @static
---@field public Single System.DefaultBinder.Primitives @static
---@field public Double System.DefaultBinder.Primitives @static
---@field public Decimal System.DefaultBinder.Primitives @static
---@field public DateTime System.DefaultBinder.Primitives @static
---@field public String System.DefaultBinder.Primitives @static
---@field public value__ number
local m = {}

System.DefaultBinder.Primitives = m
return m
