---@class Interop.Advapi32.RegistryOptions : System.Object
local m = {}

Interop.Advapi32.RegistryOptions = m
return m
