---@class System.Marvin : System.Object
---@field public DefaultSeed number @static
local m = {}

---@overload fun(data:System.Byte, count:number, seed:number):(, System.Byte) @static
---@static
---@param data System.ReadOnlySpan_1_System_Byte_
---@param seed number
---@return number
function m.ComputeHash32(data, seed) end

System.Marvin = m
return m
