---@class System.TimeZoneInfo.TZifHead : System.ValueType
---@field public Length number @static
---@field public Magic number
---@field public Version System.TimeZoneInfo.TZVersion
---@field public IsGmtCount number
---@field public IsStdCount number
---@field public LeapCount number
---@field public TimeCount number
---@field public TypeCount number
---@field public CharCount number
local m = {}

System.TimeZoneInfo.TZifHead = m
return m
