---@class System.ByReference_1_T_ : System.ValueType
---@field public Value any
local m = {}

System.ByReference_1_T_ = m
return m
