---@class System.ParseFailureKind : System.Enum
---@field public None System.ParseFailureKind @static
---@field public ArgumentNull System.ParseFailureKind @static
---@field public Format System.ParseFailureKind @static
---@field public FormatWithParameter System.ParseFailureKind @static
---@field public FormatWithOriginalDateTime System.ParseFailureKind @static
---@field public FormatWithFormatSpecifier System.ParseFailureKind @static
---@field public FormatWithOriginalDateTimeAndParameter System.ParseFailureKind @static
---@field public FormatBadDateTimeCalendar System.ParseFailureKind @static
---@field public value__ number
local m = {}

System.ParseFailureKind = m
return m
