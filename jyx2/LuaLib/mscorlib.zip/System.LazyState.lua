---@class System.LazyState : System.Enum
---@field public NoneViaConstructor System.LazyState @static
---@field public NoneViaFactory System.LazyState @static
---@field public NoneException System.LazyState @static
---@field public PublicationOnlyViaConstructor System.LazyState @static
---@field public PublicationOnlyViaFactory System.LazyState @static
---@field public PublicationOnlyWait System.LazyState @static
---@field public PublicationOnlyException System.LazyState @static
---@field public ExecutionAndPublicationViaConstructor System.LazyState @static
---@field public ExecutionAndPublicationViaFactory System.LazyState @static
---@field public ExecutionAndPublicationException System.LazyState @static
---@field public value__ number
local m = {}

System.LazyState = m
return m
