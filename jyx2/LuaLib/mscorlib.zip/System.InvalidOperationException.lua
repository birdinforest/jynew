---@class System.InvalidOperationException : System.SystemException
local m = {}

System.InvalidOperationException = m
return m
