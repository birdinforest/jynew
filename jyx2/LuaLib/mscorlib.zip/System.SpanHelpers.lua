---@class System.SpanHelpers : System.Object
local m = {}

---@overload fun(spanStart:any, length:number, comparable:any):(, any) @static
---@static
---@param span System.ValueType
---@param comparable any
---@return number
function m.BinarySearch(span, comparable) end

---@overload fun(searchSpace:System.Byte, value:number, length:number):(, System.Byte) @static
---@overload fun(searchSpace:System.Char, value:number, length:number):(, System.Char) @static
---@overload fun(searchSpace:any, searchSpaceLength:number, value:any, valueLength:number):(, any, any) @static
---@overload fun(searchSpace:any, value:any, length:number):(, any) @static
---@static
---@param searchSpace System.Byte
---@param searchSpaceLength number
---@param value System.Byte
---@param valueLength number
---@return number, System.Byte, System.Byte
function m.IndexOf(searchSpace, searchSpaceLength, value, valueLength) end

---@overload fun(searchSpace:System.Byte, value0:number, value1:number, length:number):(, System.Byte) @static
---@overload fun(searchSpace:System.Byte, value0:number, value1:number, value2:number, length:number):(, System.Byte) @static
---@overload fun(searchSpace:any, value0:any, value1:any, length:number):(, any) @static
---@overload fun(searchSpace:any, value0:any, value1:any, value2:any, length:number):(, any) @static
---@overload fun(searchSpace:any, searchSpaceLength:number, value:any, valueLength:number):(, any, any) @static
---@static
---@param searchSpace System.Byte
---@param searchSpaceLength number
---@param value System.Byte
---@param valueLength number
---@return number, System.Byte, System.Byte
function m.IndexOfAny(searchSpace, searchSpaceLength, value, valueLength) end

---@overload fun(searchSpace:System.Byte, value0:number, value1:number, length:number):(, System.Byte) @static
---@overload fun(searchSpace:System.Byte, value0:number, value1:number, value2:number, length:number):(, System.Byte) @static
---@overload fun(searchSpace:any, value0:any, value1:any, length:number):(, any) @static
---@overload fun(searchSpace:any, value0:any, value1:any, value2:any, length:number):(, any) @static
---@overload fun(searchSpace:any, searchSpaceLength:number, value:any, valueLength:number):(, any, any) @static
---@static
---@param searchSpace System.Byte
---@param searchSpaceLength number
---@param value System.Byte
---@param valueLength number
---@return number, System.Byte, System.Byte
function m.LastIndexOfAny(searchSpace, searchSpaceLength, value, valueLength) end

---@overload fun(searchSpace:System.Byte, value:number, length:number):(, System.Byte) @static
---@overload fun(searchSpace:System.Char, value:number, length:number):(, System.Char) @static
---@overload fun(searchSpace:any, searchSpaceLength:number, value:any, valueLength:number):(, any, any) @static
---@overload fun(searchSpace:any, value:any, length:number):(, any) @static
---@static
---@param searchSpace System.Byte
---@param searchSpaceLength number
---@param value System.Byte
---@param valueLength number
---@return number, System.Byte, System.Byte
function m.LastIndexOf(searchSpace, searchSpaceLength, value, valueLength) end

---@overload fun(first:any, second:any, length:number):(, any, any) @static
---@static
---@param first System.Byte
---@param second System.Byte
---@param length number
---@return boolean, System.Byte, System.Byte
function m.SequenceEqual(first, second, length) end

---@overload fun(first:System.Char, firstLength:number, second:System.Char, secondLength:number):(, System.Char, System.Char) @static
---@overload fun(first:any, firstLength:number, second:any, secondLength:number):(, any, any) @static
---@static
---@param first System.Byte
---@param firstLength number
---@param second System.Byte
---@param secondLength number
---@return number, System.Byte, System.Byte
function m.SequenceCompareTo(first, firstLength, second, secondLength) end

---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@param value System.ReadOnlySpan_1_System_Char_
---@param compareInfo System.Globalization.CompareInfo
---@return number
function m.IndexOfCultureHelper(span, value, compareInfo) end

---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@param value System.ReadOnlySpan_1_System_Char_
---@param compareInfo System.Globalization.CompareInfo
---@return number
function m.IndexOfCultureIgnoreCaseHelper(span, value, compareInfo) end

---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@param value System.ReadOnlySpan_1_System_Char_
---@param ignoreCase boolean
---@return number
function m.IndexOfOrdinalHelper(span, value, ignoreCase) end

---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@param value System.ReadOnlySpan_1_System_Char_
---@param compareInfo System.Globalization.CompareInfo
---@return boolean
function m.StartsWithCultureHelper(span, value, compareInfo) end

---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@param value System.ReadOnlySpan_1_System_Char_
---@param compareInfo System.Globalization.CompareInfo
---@return boolean
function m.StartsWithCultureIgnoreCaseHelper(span, value, compareInfo) end

---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@param value System.ReadOnlySpan_1_System_Char_
---@return boolean
function m.StartsWithOrdinalIgnoreCaseHelper(span, value) end

---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@param value System.ReadOnlySpan_1_System_Char_
---@param compareInfo System.Globalization.CompareInfo
---@return boolean
function m.EndsWithCultureHelper(span, value, compareInfo) end

---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@param value System.ReadOnlySpan_1_System_Char_
---@param compareInfo System.Globalization.CompareInfo
---@return boolean
function m.EndsWithCultureIgnoreCaseHelper(span, value, compareInfo) end

---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@param value System.ReadOnlySpan_1_System_Char_
---@return boolean
function m.EndsWithOrdinalIgnoreCaseHelper(span, value) end

---@static
---@param b System.Byte
---@param byteLength number
---@return System.Byte
function m.ClearWithoutReferences(b, byteLength) end

---@static
---@param ip System.IntPtr
---@param pointerSizeLength number
---@return System.IntPtr
function m.ClearWithReferences(ip, pointerSizeLength) end

---@static
---@param dst any
---@param dstLength number
---@param src any
---@param srcLength number
---@return any, any
function m.CopyTo(dst, dstLength, src, srcLength) end

---@static
---@param start System.IntPtr
---@param index number
---@return System.IntPtr
function m.Add(start, index) end

---@static
---@return boolean
function m.IsReferenceOrContainsReferences() end

---@overload fun(b:System.Byte, byteLength:System.UIntPtr): @static
---@static
---@param ptr System.Byte*
---@param byteLength System.UIntPtr
function m.ClearLessThanPointerSized(ptr, byteLength) end

---@static
---@param b System.Byte
---@param byteLength System.UIntPtr
---@return System.Byte
function m.ClearPointerSizedWithoutReferences(b, byteLength) end

---@static
---@param ip System.IntPtr
---@param pointerSizeLength System.UIntPtr
---@return System.IntPtr
function m.ClearPointerSizedWithReferences(ip, pointerSizeLength) end

System.SpanHelpers = m
return m
