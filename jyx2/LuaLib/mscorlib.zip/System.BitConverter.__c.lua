---@class System.BitConverter.__c : System.Object
---@field public <>9 System.BitConverter.__c @static
---@field public <>9__38_0 fun(span:System.Span_1_System_Char_, arg:System.ValueTuple_3_System_Byte___System_Int32_System_Int32_) @static
local m = {}

System.BitConverter.__c = m
return m
