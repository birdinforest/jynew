---@class Internal.Runtime.Augments.RuntimeAugments : System.Object
local m = {}

---@static
---@param exception System.Exception
function m.ReportUnhandledException(exception) end

Internal.Runtime.Augments.RuntimeAugments = m
return m
