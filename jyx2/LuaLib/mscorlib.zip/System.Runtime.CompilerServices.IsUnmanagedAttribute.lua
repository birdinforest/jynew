---@class System.Runtime.CompilerServices.IsUnmanagedAttribute : System.Attribute
local m = {}

System.Runtime.CompilerServices.IsUnmanagedAttribute = m
return m
