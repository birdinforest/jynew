---@class Interop.Globalization : System.Object
local m = {}

Interop.Globalization = m
return m
