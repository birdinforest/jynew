---@class Microsoft.Win32.SafeHandles.SafePasswordHandle.__c : System.Object
---@field public <>9 Microsoft.Win32.SafeHandles.SafePasswordHandle.__c @static
---@field public <>9__10_0 fun(): @static
local m = {}

Microsoft.Win32.SafeHandles.SafePasswordHandle.__c = m
return m
