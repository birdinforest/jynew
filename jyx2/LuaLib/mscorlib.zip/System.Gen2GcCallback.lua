---@class System.Gen2GcCallback : System.Runtime.ConstrainedExecution.CriticalFinalizerObject
local m = {}

---@static
---@param callback fun(arg:any):
---@param targetObj any
function m.Register(callback, targetObj) end

System.Gen2GcCallback = m
return m
