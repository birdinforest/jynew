---@class System.LazyHelper : System.Object
local m = {}

System.LazyHelper = m
return m
