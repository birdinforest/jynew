---@class System.MonoInternalNoteAttribute : System.MonoTODOAttribute
local m = {}

System.MonoInternalNoteAttribute = m
return m
