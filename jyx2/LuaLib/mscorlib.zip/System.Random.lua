---@class System.Random : System.Object
local m = {}

---@overload fun(minValue:number, maxValue:number): @virtual
---@overload fun(maxValue:number): @virtual
---@virtual
---@return number
function m:Next() end

---@virtual
---@return number
function m:NextDouble() end

---@overload fun(buffer:System.Span_1_System_Byte_) @virtual
---@virtual
---@param buffer string
function m:NextBytes(buffer) end

System.Random = m
return m
