---@class Interop.Sys : System.Object
local m = {}

---@static
---@param path string
---@return string
function m.ReadLink(path) end

Interop.Sys = m
return m
