---@class Mono.RuntimeStructs.GenericParamInfo : System.ValueType
local m = {}

Mono.RuntimeStructs.GenericParamInfo = m
return m
