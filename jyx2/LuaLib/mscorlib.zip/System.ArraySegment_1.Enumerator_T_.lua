---@class System.ArraySegment_1.Enumerator_T_ : System.ValueType
---@field public Current any
local m = {}

---@virtual
---@return boolean
function m:MoveNext() end

---@virtual
function m:Dispose() end

System.ArraySegment_1.Enumerator_T_ = m
return m
