---@class System.Byte : System.ValueType
---@field public MaxValue number @static
---@field public MinValue number @static
local m = {}

---@overload fun(value:number): @virtual
---@virtual
---@param value any
---@return number
function m:CompareTo(value) end

---@overload fun(obj:number): @virtual
---@virtual
---@param obj any
---@return boolean
function m:Equals(obj) end

---@virtual
---@return number
function m:GetHashCode() end

---@overload fun(s:string, style:System.Globalization.NumberStyles): @static
---@overload fun(s:string, provider:System.IFormatProvider): @static
---@overload fun(s:string, style:System.Globalization.NumberStyles, provider:System.IFormatProvider): @static
---@overload fun(s:System.ReadOnlySpan_1_System_Char_, style:System.Globalization.NumberStyles, provider:System.IFormatProvider): @static
---@overload fun(s:System.ReadOnlySpan_1_System_Char_, style:System.Globalization.NumberStyles): @static
---@overload fun(s:System.ReadOnlySpan_1_System_Char_): @static
---@static
---@param s string
---@return number
function m.Parse(s) end

---@overload fun(s:System.ReadOnlySpan_1_System_Char_):(, System.Byte) @static
---@overload fun(s:string, style:System.Globalization.NumberStyles, provider:System.IFormatProvider):(, System.Byte) @static
---@overload fun(s:System.ReadOnlySpan_1_System_Char_, style:System.Globalization.NumberStyles, provider:System.IFormatProvider):(, System.Byte) @static
---@static
---@param s string
---@return boolean, System.Byte
function m.TryParse(s) end

---@overload fun(format:string):
---@overload fun(provider:System.IFormatProvider): @virtual
---@overload fun(format:string, provider:System.IFormatProvider): @virtual
---@virtual
---@return string
function m:ToString() end

---@overload fun(destination:System.Span_1_System_Char_, format:System.ReadOnlySpan_1_System_Char_):(, System.Int32) @virtual
---@overload fun(destination:System.Span_1_System_Char_):(, System.Int32) @virtual
---@virtual
---@param destination System.Span_1_System_Char_
---@param format System.ReadOnlySpan_1_System_Char_
---@param provider System.IFormatProvider
---@return boolean, System.Int32
function m:TryFormat(destination, format, provider) end

---@virtual
---@return System.TypeCode
function m:GetTypeCode() end

System.Byte = m
return m
