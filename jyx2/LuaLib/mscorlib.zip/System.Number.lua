---@class System.Number : System.Object
local m = {}

---@static
---@param value System.Decimal
---@param format System.ReadOnlySpan_1_System_Char_
---@param info System.Globalization.NumberFormatInfo
---@return string
function m.FormatDecimal(value, format, info) end

---@static
---@param value System.Decimal
---@param format System.ReadOnlySpan_1_System_Char_
---@param info System.Globalization.NumberFormatInfo
---@param destination System.Span_1_System_Char_
---@return boolean, System.Int32
function m.TryFormatDecimal(value, format, info, destination) end

---@static
---@param value number
---@param format string
---@param info System.Globalization.NumberFormatInfo
---@return string
function m.FormatDouble(value, format, info) end

---@static
---@param value number
---@param format System.ReadOnlySpan_1_System_Char_
---@param info System.Globalization.NumberFormatInfo
---@param destination System.Span_1_System_Char_
---@return boolean, System.Int32
function m.TryFormatDouble(value, format, info, destination) end

---@static
---@param value number
---@param format string
---@param info System.Globalization.NumberFormatInfo
---@return string
function m.FormatSingle(value, format, info) end

---@static
---@param value number
---@param format System.ReadOnlySpan_1_System_Char_
---@param info System.Globalization.NumberFormatInfo
---@param destination System.Span_1_System_Char_
---@return boolean, System.Int32
function m.TryFormatSingle(value, format, info, destination) end

---@static
---@param value number
---@param format System.ReadOnlySpan_1_System_Char_
---@param provider System.IFormatProvider
---@return string
function m.FormatInt32(value, format, provider) end

---@static
---@param value number
---@param format System.ReadOnlySpan_1_System_Char_
---@param provider System.IFormatProvider
---@param destination System.Span_1_System_Char_
---@return boolean, System.Int32
function m.TryFormatInt32(value, format, provider, destination) end

---@static
---@param value number
---@param format System.ReadOnlySpan_1_System_Char_
---@param provider System.IFormatProvider
---@return string
function m.FormatUInt32(value, format, provider) end

---@static
---@param value number
---@param format System.ReadOnlySpan_1_System_Char_
---@param provider System.IFormatProvider
---@param destination System.Span_1_System_Char_
---@return boolean, System.Int32
function m.TryFormatUInt32(value, format, provider, destination) end

---@static
---@param value number
---@param format System.ReadOnlySpan_1_System_Char_
---@param provider System.IFormatProvider
---@return string
function m.FormatInt64(value, format, provider) end

---@static
---@param value number
---@param format System.ReadOnlySpan_1_System_Char_
---@param provider System.IFormatProvider
---@param destination System.Span_1_System_Char_
---@return boolean, System.Int32
function m.TryFormatInt64(value, format, provider, destination) end

---@static
---@param value number
---@param format System.ReadOnlySpan_1_System_Char_
---@param provider System.IFormatProvider
---@return string
function m.FormatUInt64(value, format, provider) end

---@static
---@param value number
---@param format System.ReadOnlySpan_1_System_Char_
---@param provider System.IFormatProvider
---@param destination System.Span_1_System_Char_
---@return boolean, System.Int32
function m.TryFormatUInt64(value, format, provider, destination) end

System.Number = m
return m
