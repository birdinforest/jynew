---@class System.DateTimeResult : System.ValueType
local m = {}

System.DateTimeResult = m
return m
