---@class System.Index : System.ValueType
---@field public Start System.Index @static
---@field public End System.Index @static
---@field public Value number
---@field public IsFromEnd boolean
local m = {}

---@static
---@param value number
---@return System.Index
function m.FromStart(value) end

---@static
---@param value number
---@return System.Index
function m.FromEnd(value) end

---@param length number
---@return number
function m:GetOffset(length) end

---@overload fun(other:System.Index): @virtual
---@virtual
---@param value any
---@return boolean
function m:Equals(value) end

---@virtual
---@return number
function m:GetHashCode() end

---@static
---@param value number
---@return System.Index
function m.op_Implicit(value) end

---@virtual
---@return string
function m:ToString() end

System.Index = m
return m
