---@class Mono.ISystemDependencyProvider : table
---@field public CertificateProvider Mono.ISystemCertificateProvider
local m = {}

Mono.ISystemDependencyProvider = m
return m
