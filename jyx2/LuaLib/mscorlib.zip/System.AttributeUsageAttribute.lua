---@class System.AttributeUsageAttribute : System.Attribute
---@field public ValidOn System.AttributeTargets
---@field public AllowMultiple boolean
---@field public Inherited boolean
local m = {}

System.AttributeUsageAttribute = m
return m
