---@class System.String.TrimType : System.Enum
---@field public Head System.String.TrimType @static
---@field public Tail System.String.TrimType @static
---@field public Both System.String.TrimType @static
---@field public value__ number
local m = {}

System.String.TrimType = m
return m
