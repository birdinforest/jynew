---@class System.HashCode : System.ValueType
local m = {}

---@overload fun(value1:any, value2:any): @static
---@overload fun(value1:any, value2:any, value3:any): @static
---@overload fun(value1:any, value2:any, value3:any, value4:any): @static
---@overload fun(value1:any, value2:any, value3:any, value4:any, value5:any): @static
---@overload fun(value1:any, value2:any, value3:any, value4:any, value5:any, value6:any): @static
---@overload fun(value1:any, value2:any, value3:any, value4:any, value5:any, value6:any, value7:any): @static
---@overload fun(value1:any, value2:any, value3:any, value4:any, value5:any, value6:any, value7:any, value8:any): @static
---@static
---@param value1 any
---@return number
function m.Combine(value1) end

---@overload fun(value:any, comparer:any)
---@param value any
function m:Add(value) end

---@return number
function m:ToHashCode() end

---@virtual
---@return number
function m:GetHashCode() end

---@virtual
---@param obj any
---@return boolean
function m:Equals(obj) end

System.HashCode = m
return m
