---@class System.Range : System.ValueType
---@field public All System.Range @static
---@field public Start System.Index
---@field public End System.Index
local m = {}

---@overload fun(other:System.Range): @virtual
---@virtual
---@param value any
---@return boolean
function m:Equals(value) end

---@virtual
---@return number
function m:GetHashCode() end

---@virtual
---@return string
function m:ToString() end

---@static
---@param start System.Index
---@return System.Range
function m.StartAt(start) end

---@static
---@param _end System.Index
---@return System.Range
function m.EndAt(_end) end

---@param length number
---@return System.ValueTuple_2_System_Int32_System_Int32_
function m:GetOffsetAndLength(length) end

System.Range = m
return m
