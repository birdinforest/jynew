---@class Interop.Sys.FileStatusFlags : System.Enum
---@field public None Interop.Sys.FileStatusFlags @static
---@field public HasBirthTime Interop.Sys.FileStatusFlags @static
---@field public value__ number
local m = {}

Interop.Sys.FileStatusFlags = m
return m
