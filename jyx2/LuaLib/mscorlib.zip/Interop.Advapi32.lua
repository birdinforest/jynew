---@class Interop.Advapi32 : System.Object
local m = {}

Interop.Advapi32 = m
return m
