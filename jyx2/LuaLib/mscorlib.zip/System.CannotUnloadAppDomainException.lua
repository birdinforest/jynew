---@class System.CannotUnloadAppDomainException : System.SystemException
local m = {}

System.CannotUnloadAppDomainException = m
return m
