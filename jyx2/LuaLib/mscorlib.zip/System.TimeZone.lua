---@class System.TimeZone : System.Object
---@field public CurrentTimeZone System.TimeZone @static
---@field public StandardName string
---@field public DaylightName string
local m = {}

---@abstract
---@param time System.DateTime
---@return System.TimeSpan
function m:GetUtcOffset(time) end

---@virtual
---@param time System.DateTime
---@return System.DateTime
function m:ToUniversalTime(time) end

---@virtual
---@param time System.DateTime
---@return System.DateTime
function m:ToLocalTime(time) end

---@abstract
---@param year number
---@return System.Globalization.DaylightTime
function m:GetDaylightChanges(year) end

---@overload fun(time:System.DateTime, daylightTimes:System.Globalization.DaylightTime): @static
---@virtual
---@param time System.DateTime
---@return boolean
function m:IsDaylightSavingTime(time) end

System.TimeZone = m
return m
