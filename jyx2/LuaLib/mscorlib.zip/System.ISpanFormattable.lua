---@class System.ISpanFormattable : table
local m = {}

---@abstract
---@param destination System.Span_1_System_Char_
---@param format System.ReadOnlySpan_1_System_Char_
---@param provider System.IFormatProvider
---@return boolean, System.Int32
function m:TryFormat(destination, format, provider) end

System.ISpanFormattable = m
return m
