---@class Interop.Advapi32.RegistryView : System.Object
local m = {}

Interop.Advapi32.RegistryView = m
return m
