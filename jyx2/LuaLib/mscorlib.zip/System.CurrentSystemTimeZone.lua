---@class System.CurrentSystemTimeZone : System.TimeZone
---@field public StandardName string
---@field public DaylightName string
local m = {}

---@virtual
---@param time System.DateTime
---@return System.DateTime
function m:ToLocalTime(time) end

---@virtual
---@param year number
---@return System.Globalization.DaylightTime
function m:GetDaylightChanges(year) end

---@virtual
---@param time System.DateTime
---@return System.TimeSpan
function m:GetUtcOffset(time) end

---@static
---@param year number
---@return boolean, System.Int64__, System.String__, System.Boolean
function m.GetTimeZoneData(year) end

System.CurrentSystemTimeZone = m
return m
