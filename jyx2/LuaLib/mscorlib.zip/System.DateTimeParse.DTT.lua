---@class System.DateTimeParse.DTT : System.Enum
---@field public End System.DateTimeParse.DTT @static
---@field public NumEnd System.DateTimeParse.DTT @static
---@field public NumAmpm System.DateTimeParse.DTT @static
---@field public NumSpace System.DateTimeParse.DTT @static
---@field public NumDatesep System.DateTimeParse.DTT @static
---@field public NumTimesep System.DateTimeParse.DTT @static
---@field public MonthEnd System.DateTimeParse.DTT @static
---@field public MonthSpace System.DateTimeParse.DTT @static
---@field public MonthDatesep System.DateTimeParse.DTT @static
---@field public NumDatesuff System.DateTimeParse.DTT @static
---@field public NumTimesuff System.DateTimeParse.DTT @static
---@field public DayOfWeek System.DateTimeParse.DTT @static
---@field public YearSpace System.DateTimeParse.DTT @static
---@field public YearDateSep System.DateTimeParse.DTT @static
---@field public YearEnd System.DateTimeParse.DTT @static
---@field public TimeZone System.DateTimeParse.DTT @static
---@field public Era System.DateTimeParse.DTT @static
---@field public NumUTCTimeMark System.DateTimeParse.DTT @static
---@field public Unk System.DateTimeParse.DTT @static
---@field public NumLocalTimeMark System.DateTimeParse.DTT @static
---@field public Max System.DateTimeParse.DTT @static
---@field public value__ number
local m = {}

System.DateTimeParse.DTT = m
return m
