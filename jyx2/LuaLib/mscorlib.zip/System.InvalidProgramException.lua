---@class System.InvalidProgramException : System.SystemException
local m = {}

System.InvalidProgramException = m
return m
