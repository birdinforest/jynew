---@class System.MathF : System.Object
---@field public E number @static
---@field public PI number @static
local m = {}

---@static
---@param x number
---@return number
function m.Abs(x) end

---@static
---@param x number
---@param y number
---@return number
function m.IEEERemainder(x, y) end

---@overload fun(x:number): @static
---@static
---@param x number
---@param y number
---@return number
function m.Log(x, y) end

---@static
---@param x number
---@param y number
---@return number
function m.Max(x, y) end

---@static
---@param x number
---@param y number
---@return number
function m.Min(x, y) end

---@overload fun(x:number, digits:number): @static
---@overload fun(x:number, mode:System.MidpointRounding): @static
---@overload fun(x:number, digits:number, mode:System.MidpointRounding): @static
---@static
---@param x number
---@return number
function m.Round(x) end

---@static
---@param x number
---@return number
function m.Sign(x) end

---@static
---@param x number
---@return number
function m.Truncate(x) end

---@static
---@param x number
---@return number
function m.Acos(x) end

---@static
---@param x number
---@return number
function m.Acosh(x) end

---@static
---@param x number
---@return number
function m.Asin(x) end

---@static
---@param x number
---@return number
function m.Asinh(x) end

---@static
---@param x number
---@return number
function m.Atan(x) end

---@static
---@param y number
---@param x number
---@return number
function m.Atan2(y, x) end

---@static
---@param x number
---@return number
function m.Atanh(x) end

---@static
---@param x number
---@return number
function m.Cbrt(x) end

---@static
---@param x number
---@return number
function m.Ceiling(x) end

---@static
---@param x number
---@return number
function m.Cos(x) end

---@static
---@param x number
---@return number
function m.Cosh(x) end

---@static
---@param x number
---@return number
function m.Exp(x) end

---@static
---@param x number
---@return number
function m.Floor(x) end

---@static
---@param x number
---@return number
function m.Log10(x) end

---@static
---@param x number
---@param y number
---@return number
function m.Pow(x, y) end

---@static
---@param x number
---@return number
function m.Sin(x) end

---@static
---@param x number
---@return number
function m.Sinh(x) end

---@static
---@param x number
---@return number
function m.Sqrt(x) end

---@static
---@param x number
---@return number
function m.Tan(x) end

---@static
---@param x number
---@return number
function m.Tanh(x) end

System.MathF = m
return m
