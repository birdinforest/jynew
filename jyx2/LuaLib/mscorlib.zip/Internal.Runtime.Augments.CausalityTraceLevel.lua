---@class Internal.Runtime.Augments.CausalityTraceLevel : System.Enum
---@field public Required Internal.Runtime.Augments.CausalityTraceLevel @static
---@field public Important Internal.Runtime.Augments.CausalityTraceLevel @static
---@field public Verbose Internal.Runtime.Augments.CausalityTraceLevel @static
---@field public value__ number
local m = {}

Internal.Runtime.Augments.CausalityTraceLevel = m
return m
