---@class System.ArraySegment_1_T_ : System.ValueType
---@field public Empty any[] @static
---@field public Array any[]
---@field public Offset number
---@field public Count number
---@field public Item any
local m = {}

---@return System.ValueType
function m:GetEnumerator() end

---@virtual
---@return number
function m:GetHashCode() end

---@overload fun(destination:any[], destinationIndex:number) @virtual
---@overload fun(destination:any[])
---@param destination any[]
function m:CopyTo(destination) end

---@overload fun(obj:any[]):
---@virtual
---@param obj any
---@return boolean
function m:Equals(obj) end

---@overload fun(index:number, count:number):
---@param index number
---@return any[]
function m:Slice(index) end

---@return any[]
function m:ToArray() end

---@static
---@param a any[]
---@param b any[]
---@return boolean
function m.op_Equality(a, b) end

---@static
---@param a any[]
---@param b any[]
---@return boolean
function m.op_Inequality(a, b) end

---@static
---@param array any[]
---@return any[]
function m.op_Implicit(array) end

System.ArraySegment_1_T_ = m
return m
