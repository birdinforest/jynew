---@class Microsoft.Win32.RegistryValueKind : System.Enum
---@field public String Microsoft.Win32.RegistryValueKind @static
---@field public ExpandString Microsoft.Win32.RegistryValueKind @static
---@field public Binary Microsoft.Win32.RegistryValueKind @static
---@field public DWord Microsoft.Win32.RegistryValueKind @static
---@field public MultiString Microsoft.Win32.RegistryValueKind @static
---@field public QWord Microsoft.Win32.RegistryValueKind @static
---@field public Unknown Microsoft.Win32.RegistryValueKind @static
---@field public None Microsoft.Win32.RegistryValueKind @static
---@field public value__ number
local m = {}

Microsoft.Win32.RegistryValueKind = m
return m
