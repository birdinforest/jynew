---@class System.ReadOnlySpan_1.Enumerator_T_ : System.ValueType
---@field public Current any
local m = {}

---@return boolean
function m:MoveNext() end

System.ReadOnlySpan_1.Enumerator_T_ = m
return m
