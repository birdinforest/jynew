---@class System.TypeCode : System.Enum
---@field public Empty System.TypeCode @static
---@field public Object System.TypeCode @static
---@field public DBNull System.TypeCode @static
---@field public Boolean System.TypeCode @static
---@field public Char System.TypeCode @static
---@field public SByte System.TypeCode @static
---@field public Byte System.TypeCode @static
---@field public Int16 System.TypeCode @static
---@field public UInt16 System.TypeCode @static
---@field public Int32 System.TypeCode @static
---@field public UInt32 System.TypeCode @static
---@field public Int64 System.TypeCode @static
---@field public UInt64 System.TypeCode @static
---@field public Single System.TypeCode @static
---@field public Double System.TypeCode @static
---@field public Decimal System.TypeCode @static
---@field public DateTime System.TypeCode @static
---@field public String System.TypeCode @static
---@field public value__ number
local m = {}

System.TypeCode = m
return m
