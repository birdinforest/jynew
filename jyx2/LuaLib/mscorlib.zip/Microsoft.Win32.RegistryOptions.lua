---@class Microsoft.Win32.RegistryOptions : System.Enum
---@field public None Microsoft.Win32.RegistryOptions @static
---@field public Volatile Microsoft.Win32.RegistryOptions @static
---@field public value__ number
local m = {}

Microsoft.Win32.RegistryOptions = m
return m
