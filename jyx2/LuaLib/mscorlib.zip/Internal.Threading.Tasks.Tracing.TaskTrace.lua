---@class Internal.Threading.Tasks.Tracing.TaskTrace : System.Object
---@field public Enabled boolean @static
local m = {}

---@static
---@param callbacks Internal.Runtime.Augments.TaskTraceCallbacks
function m.Initialize(callbacks) end

---@static
---@param OriginatingTaskSchedulerID number
---@param OriginatingTaskID number
---@param TaskID number
function m.TaskWaitBegin_Asynchronous(OriginatingTaskSchedulerID, OriginatingTaskID, TaskID) end

---@static
---@param OriginatingTaskSchedulerID number
---@param OriginatingTaskID number
---@param TaskID number
function m.TaskWaitBegin_Synchronous(OriginatingTaskSchedulerID, OriginatingTaskID, TaskID) end

---@static
---@param OriginatingTaskSchedulerID number
---@param OriginatingTaskID number
---@param TaskID number
function m.TaskWaitEnd(OriginatingTaskSchedulerID, OriginatingTaskID, TaskID) end

---@static
---@param OriginatingTaskSchedulerID number
---@param OriginatingTaskID number
---@param TaskID number
---@param CreatingTaskID number
---@param TaskCreationOptions number
function m.TaskScheduled(OriginatingTaskSchedulerID, OriginatingTaskID, TaskID, CreatingTaskID, TaskCreationOptions) end

---@static
---@param OriginatingTaskSchedulerID number
---@param OriginatingTaskID number
---@param TaskID number
function m.TaskStarted(OriginatingTaskSchedulerID, OriginatingTaskID, TaskID) end

---@static
---@param OriginatingTaskSchedulerID number
---@param OriginatingTaskID number
---@param TaskID number
---@param IsExceptional boolean
function m.TaskCompleted(OriginatingTaskSchedulerID, OriginatingTaskID, TaskID, IsExceptional) end

Internal.Threading.Tasks.Tracing.TaskTrace = m
return m
