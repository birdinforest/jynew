---@class System.SpanHelpers.ComparerComparable_2_T_TComparer_ : System.ValueType
local m = {}

---@virtual
---@param other any
---@return number
function m:CompareTo(other) end

System.SpanHelpers.ComparerComparable_2_T_TComparer_ = m
return m
