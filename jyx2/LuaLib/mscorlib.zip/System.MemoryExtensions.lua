---@class System.MemoryExtensions : System.Object
local m = {}

---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@param value System.ReadOnlySpan_1_System_Char_
---@param comparisonType System.StringComparison
---@return boolean
function m.Contains(span, value, comparisonType) end

---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@param other System.ReadOnlySpan_1_System_Char_
---@param comparisonType System.StringComparison
---@return boolean
function m.Equals(span, other, comparisonType) end

---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@param other System.ReadOnlySpan_1_System_Char_
---@param comparisonType System.StringComparison
---@return number
function m.CompareTo(span, other, comparisonType) end

---@overload fun(span:System.ValueType, value:any): @static
---@overload fun(span:System.ValueType, value:System.ValueType): @static
---@overload fun(span:System.ValueType, value:any): @static
---@overload fun(span:System.ValueType, value:System.ValueType): @static
---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@param value System.ReadOnlySpan_1_System_Char_
---@param comparisonType System.StringComparison
---@return number
function m.IndexOf(span, value, comparisonType) end

---@static
---@param source System.ReadOnlySpan_1_System_Char_
---@param destination System.Span_1_System_Char_
---@param culture System.Globalization.CultureInfo
---@return number
function m.ToLower(source, destination, culture) end

---@static
---@param source System.ReadOnlySpan_1_System_Char_
---@param destination System.Span_1_System_Char_
---@return number
function m.ToLowerInvariant(source, destination) end

---@static
---@param source System.ReadOnlySpan_1_System_Char_
---@param destination System.Span_1_System_Char_
---@param culture System.Globalization.CultureInfo
---@return number
function m.ToUpper(source, destination, culture) end

---@static
---@param source System.ReadOnlySpan_1_System_Char_
---@param destination System.Span_1_System_Char_
---@return number
function m.ToUpperInvariant(source, destination) end

---@overload fun(span:System.ValueType, value:System.ValueType): @static
---@overload fun(span:System.ValueType, value:System.ValueType): @static
---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@param value System.ReadOnlySpan_1_System_Char_
---@param comparisonType System.StringComparison
---@return boolean
function m.EndsWith(span, value, comparisonType) end

---@overload fun(span:System.ValueType, value:System.ValueType): @static
---@overload fun(span:System.ValueType, value:System.ValueType): @static
---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@param value System.ReadOnlySpan_1_System_Char_
---@param comparisonType System.StringComparison
---@return boolean
function m.StartsWith(span, value, comparisonType) end

---@overload fun(array:any[], startIndex:System.Index): @static
---@overload fun(array:any[], range:System.Range): @static
---@overload fun(text:string): @static
---@overload fun(text:string, start:number): @static
---@overload fun(text:string, start:number, length:number): @static
---@overload fun(array:any[]): @static
---@overload fun(array:any[], start:number, length:number): @static
---@overload fun(segment:any[]): @static
---@overload fun(segment:any[], start:number): @static
---@overload fun(segment:any[], startIndex:System.Index): @static
---@overload fun(segment:any[], start:number, length:number): @static
---@overload fun(segment:any[], range:System.Range): @static
---@static
---@param array any[]
---@param start number
---@return System.ValueType
function m.AsSpan(array, start) end

---@overload fun(text:string, start:number): @static
---@overload fun(text:string, startIndex:System.Index): @static
---@overload fun(text:string, start:number, length:number): @static
---@overload fun(text:string, range:System.Range): @static
---@overload fun(array:any[]): @static
---@overload fun(array:any[], start:number): @static
---@overload fun(array:any[], startIndex:System.Index): @static
---@overload fun(array:any[], start:number, length:number): @static
---@overload fun(array:any[], range:System.Range): @static
---@overload fun(segment:any[]): @static
---@overload fun(segment:any[], start:number): @static
---@overload fun(segment:any[], start:number, length:number): @static
---@static
---@param text string
---@return System.ReadOnlyMemory_1_System_Char_
function m.AsMemory(text) end

---@overload fun(span:System.ReadOnlySpan_1_System_Char_, trimChar:number): @static
---@overload fun(span:System.ReadOnlySpan_1_System_Char_, trimChars:System.ReadOnlySpan_1_System_Char_): @static
---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@return System.ReadOnlySpan_1_System_Char_
function m.Trim(span) end

---@overload fun(span:System.ReadOnlySpan_1_System_Char_, trimChar:number): @static
---@overload fun(span:System.ReadOnlySpan_1_System_Char_, trimChars:System.ReadOnlySpan_1_System_Char_): @static
---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@return System.ReadOnlySpan_1_System_Char_
function m.TrimStart(span) end

---@overload fun(span:System.ReadOnlySpan_1_System_Char_, trimChar:number): @static
---@overload fun(span:System.ReadOnlySpan_1_System_Char_, trimChars:System.ReadOnlySpan_1_System_Char_): @static
---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@return System.ReadOnlySpan_1_System_Char_
function m.TrimEnd(span) end

---@static
---@param span System.ReadOnlySpan_1_System_Char_
---@return boolean
function m.IsWhiteSpace(span) end

---@overload fun(span:System.ValueType, value:System.ValueType): @static
---@overload fun(span:System.ValueType, value:any): @static
---@overload fun(span:System.ValueType, value:System.ValueType): @static
---@static
---@param span System.ValueType
---@param value any
---@return number
function m.LastIndexOf(span, value) end

---@overload fun(span:System.ValueType, other:System.ValueType): @static
---@static
---@param span System.ValueType
---@param other System.ValueType
---@return boolean
function m.SequenceEqual(span, other) end

---@overload fun(span:System.ValueType, other:System.ValueType): @static
---@static
---@param span System.ValueType
---@param other System.ValueType
---@return number
function m.SequenceCompareTo(span, other) end

---@overload fun(span:System.ValueType, value0:any, value1:any, value2:any): @static
---@overload fun(span:System.ValueType, values:System.ValueType): @static
---@overload fun(span:System.ValueType, value0:any, value1:any): @static
---@overload fun(span:System.ValueType, value0:any, value1:any, value2:any): @static
---@overload fun(span:System.ValueType, values:System.ValueType): @static
---@static
---@param span System.ValueType
---@param value0 any
---@param value1 any
---@return number
function m.IndexOfAny(span, value0, value1) end

---@overload fun(span:System.ValueType, value0:any, value1:any, value2:any): @static
---@overload fun(span:System.ValueType, values:System.ValueType): @static
---@overload fun(span:System.ValueType, value0:any, value1:any): @static
---@overload fun(span:System.ValueType, value0:any, value1:any, value2:any): @static
---@overload fun(span:System.ValueType, values:System.ValueType): @static
---@static
---@param span System.ValueType
---@param value0 any
---@param value1 any
---@return number
function m.LastIndexOfAny(span, value0, value1) end

---@static
---@param span System.ValueType
function m.Reverse(span) end

---@overload fun(source:any[], destination:System.ValueType) @static
---@static
---@param source any[]
---@param destination System.ValueType
function m.CopyTo(source, destination) end

---@overload fun(span:System.ValueType, other:System.ValueType):(, System.Int32) @static
---@overload fun(span:System.ValueType, other:System.ValueType): @static
---@overload fun(span:System.ValueType, other:System.ValueType):(, System.Int32) @static
---@static
---@param span System.ValueType
---@param other System.ValueType
---@return boolean
function m.Overlaps(span, other) end

---@overload fun(span:System.ValueType, comparable:any): @static
---@overload fun(span:System.ValueType, value:any, comparer:any): @static
---@overload fun(span:System.ValueType, comparable:any): @static
---@overload fun(span:System.ValueType, comparable:any): @static
---@overload fun(span:System.ValueType, value:any, comparer:any): @static
---@static
---@param span System.ValueType
---@param comparable any
---@return number
function m.BinarySearch(span, comparable) end

System.MemoryExtensions = m
return m
