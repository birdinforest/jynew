---@class Mono.ValueTuple_1_T1_ : System.ValueType
---@field public Item1 any
local m = {}

Mono.ValueTuple_1_T1_ = m
return m
