---@class Microsoft.Win32.SafeHandles.SafeHandleCache_1_T_ : System.Object
local m = {}

Microsoft.Win32.SafeHandles.SafeHandleCache_1_T_ = m
return m
