---@class System.DecimalDecCalc : System.Object
local m = {}

System.DecimalDecCalc = m
return m
