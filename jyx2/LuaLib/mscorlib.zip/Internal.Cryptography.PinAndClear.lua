---@class Internal.Cryptography.PinAndClear : System.ValueType
local m = {}

---@virtual
function m:Dispose() end

Internal.Cryptography.PinAndClear = m
return m
