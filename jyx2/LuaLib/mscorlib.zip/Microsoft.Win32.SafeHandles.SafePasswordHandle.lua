---@class Microsoft.Win32.SafeHandles.SafePasswordHandle : System.Runtime.InteropServices.SafeHandle
---@field public InvalidHandle Microsoft.Win32.SafeHandles.SafePasswordHandle @static
---@field public IsInvalid boolean
local m = {}

Microsoft.Win32.SafeHandles.SafePasswordHandle = m
return m
