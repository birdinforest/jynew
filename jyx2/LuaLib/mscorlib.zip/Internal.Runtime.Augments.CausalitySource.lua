---@class Internal.Runtime.Augments.CausalitySource : System.Enum
---@field public Application Internal.Runtime.Augments.CausalitySource @static
---@field public Library Internal.Runtime.Augments.CausalitySource @static
---@field public System Internal.Runtime.Augments.CausalitySource @static
---@field public value__ number
local m = {}

Internal.Runtime.Augments.CausalitySource = m
return m
