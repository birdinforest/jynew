---@class Interop.Sys.UTimBuf : System.ValueType
local m = {}

Interop.Sys.UTimBuf = m
return m
