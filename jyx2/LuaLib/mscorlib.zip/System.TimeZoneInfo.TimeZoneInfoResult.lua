---@class System.TimeZoneInfo.TimeZoneInfoResult : System.Enum
---@field public Success System.TimeZoneInfo.TimeZoneInfoResult @static
---@field public TimeZoneNotFoundException System.TimeZoneInfo.TimeZoneInfoResult @static
---@field public InvalidTimeZoneException System.TimeZoneInfo.TimeZoneInfoResult @static
---@field public SecurityException System.TimeZoneInfo.TimeZoneInfoResult @static
---@field public value__ number
local m = {}

System.TimeZoneInfo.TimeZoneInfoResult = m
return m
