---@class Interop.Sys.FileTypes : System.Object
local m = {}

Interop.Sys.FileTypes = m
return m
