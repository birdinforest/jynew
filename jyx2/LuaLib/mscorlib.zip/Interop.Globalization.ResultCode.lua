---@class Interop.Globalization.ResultCode : System.Enum
---@field public Success Interop.Globalization.ResultCode @static
---@field public UnknownError Interop.Globalization.ResultCode @static
---@field public InsufficentBuffer Interop.Globalization.ResultCode @static
---@field public OutOfMemory Interop.Globalization.ResultCode @static
---@field public value__ number
local m = {}

Interop.Globalization.ResultCode = m
return m
