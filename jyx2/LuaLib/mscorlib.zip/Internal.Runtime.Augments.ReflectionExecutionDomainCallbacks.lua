---@class Internal.Runtime.Augments.ReflectionExecutionDomainCallbacks : System.Object
local m = {}

Internal.Runtime.Augments.ReflectionExecutionDomainCallbacks = m
return m
