---@class XamMac.CoreFoundation.CFHelpers : System.Object
local m = {}

XamMac.CoreFoundation.CFHelpers = m
return m
