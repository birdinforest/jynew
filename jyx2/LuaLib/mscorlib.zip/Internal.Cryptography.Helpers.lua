---@class Internal.Cryptography.Helpers : System.Object
local m = {}

---@static
---@param src string
---@return string
function m.CloneByteArray(src) end

---@static
---@param src System.Security.Cryptography.KeySizes[]
---@return System.Security.Cryptography.KeySizes[]
function m.CloneKeySizesArray(src) end

---@static
---@param cipherMode System.Security.Cryptography.CipherMode
---@return boolean
function m.UsesIv(cipherMode) end

---@static
---@param cipherMode System.Security.Cryptography.CipherMode
---@param iv string
---@return string
function m.GetCipherIv(cipherMode, iv) end

---@static
---@param size number
---@param legalSizes System.Security.Cryptography.KeySizes[]
---@return boolean
function m.IsLegalSize(size, legalSizes) end

---@static
---@param count number
---@return string
function m.GenerateRandom(count) end

---@static
---@param i number
---@param arr string
---@param offset number
function m.WriteInt(i, arr, offset) end

---@static
---@param key string
---@return string
function m.FixupKeyParity(key) end

---@static
---@param bytes string
---@return number[]
function m.ToHexArrayUpper(bytes) end

---@static
---@param bytes string
---@return string
function m.ToHexStringUpper(bytes) end

---@static
---@param s string
---@return string
function m.DecodeHexString(s) end

---@static
---@param a1 string
---@param a2 string
---@return boolean
function m.ContentsEqual(a1, a2) end

---@static
---@param calendar System.Globalization.Calendar
---@param year number
---@param month number
---@param day number
---@param era number
---@return boolean
function m.IsValidDay(calendar, year, month, day, era) end

Internal.Cryptography.Helpers = m
return m
