---@class Internal.Runtime.Augments.CausalityRelation : System.Enum
---@field public AssignDelegate Internal.Runtime.Augments.CausalityRelation @static
---@field public Join Internal.Runtime.Augments.CausalityRelation @static
---@field public Choice Internal.Runtime.Augments.CausalityRelation @static
---@field public Cancel Internal.Runtime.Augments.CausalityRelation @static
---@field public Error Internal.Runtime.Augments.CausalityRelation @static
---@field public value__ number
local m = {}

Internal.Runtime.Augments.CausalityRelation = m
return m
