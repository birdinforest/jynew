---@class System.Void : System.ValueType
local m = {}

System.Void = m
return m
