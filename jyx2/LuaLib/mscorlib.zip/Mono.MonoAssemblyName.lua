---@class Mono.MonoAssemblyName : System.ValueType
local m = {}

Mono.MonoAssemblyName = m
return m
