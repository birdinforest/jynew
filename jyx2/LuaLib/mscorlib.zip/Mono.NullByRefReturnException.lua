---@class Mono.NullByRefReturnException : System.Exception
local m = {}

Mono.NullByRefReturnException = m
return m
