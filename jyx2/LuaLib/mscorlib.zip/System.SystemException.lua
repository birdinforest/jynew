---@class System.SystemException : System.Exception
local m = {}

System.SystemException = m
return m
