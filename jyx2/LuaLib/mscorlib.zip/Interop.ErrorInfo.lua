---@class Interop.ErrorInfo : System.ValueType
local m = {}

---@virtual
---@return string
function m:ToString() end

Interop.ErrorInfo = m
return m
