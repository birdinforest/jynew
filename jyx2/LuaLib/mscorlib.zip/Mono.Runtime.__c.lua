---@class Mono.Runtime.__c : System.Object
---@field public <>9 Mono.Runtime.__c @static
---@field public <>9__29_0 fun(obj:string) @static
local m = {}

Mono.Runtime.__c = m
return m
