---@class Interop.Sys.NodeType : System.Enum
---@field public DT_UNKNOWN Interop.Sys.NodeType @static
---@field public DT_FIFO Interop.Sys.NodeType @static
---@field public DT_CHR Interop.Sys.NodeType @static
---@field public DT_DIR Interop.Sys.NodeType @static
---@field public DT_BLK Interop.Sys.NodeType @static
---@field public DT_REG Interop.Sys.NodeType @static
---@field public DT_LNK Interop.Sys.NodeType @static
---@field public DT_SOCK Interop.Sys.NodeType @static
---@field public DT_WHT Interop.Sys.NodeType @static
---@field public value__ number
local m = {}

Interop.Sys.NodeType = m
return m
