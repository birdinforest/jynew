---@class Interop.Advapi32.RegistryOperations : System.Object
local m = {}

Interop.Advapi32.RegistryOperations = m
return m
