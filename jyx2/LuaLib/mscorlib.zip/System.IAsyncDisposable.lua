---@class System.IAsyncDisposable : table
local m = {}

---@abstract
---@return System.Threading.Tasks.ValueTask
function m:DisposeAsync() end

---@extension
---@param continueOnCapturedContext boolean
---@return System.Runtime.CompilerServices.ConfiguredAsyncDisposable
function m.ConfigureAwait(continueOnCapturedContext) end

System.IAsyncDisposable = m
return m
