---@class Internal.Runtime.Augments.TaskTraceCallbacks : System.Object
---@field public Enabled boolean
local m = {}

---@abstract
---@param OriginatingTaskSchedulerID number
---@param OriginatingTaskID number
---@param TaskID number
function m:TaskWaitBegin_Asynchronous(OriginatingTaskSchedulerID, OriginatingTaskID, TaskID) end

---@abstract
---@param OriginatingTaskSchedulerID number
---@param OriginatingTaskID number
---@param TaskID number
function m:TaskWaitBegin_Synchronous(OriginatingTaskSchedulerID, OriginatingTaskID, TaskID) end

---@abstract
---@param OriginatingTaskSchedulerID number
---@param OriginatingTaskID number
---@param TaskID number
function m:TaskWaitEnd(OriginatingTaskSchedulerID, OriginatingTaskID, TaskID) end

---@abstract
---@param OriginatingTaskSchedulerID number
---@param OriginatingTaskID number
---@param TaskID number
---@param CreatingTaskID number
---@param TaskCreationOptions number
function m:TaskScheduled(OriginatingTaskSchedulerID, OriginatingTaskID, TaskID, CreatingTaskID, TaskCreationOptions) end

---@abstract
---@param OriginatingTaskSchedulerID number
---@param OriginatingTaskID number
---@param TaskID number
function m:TaskStarted(OriginatingTaskSchedulerID, OriginatingTaskID, TaskID) end

---@abstract
---@param OriginatingTaskSchedulerID number
---@param OriginatingTaskID number
---@param TaskID number
---@param IsExceptional boolean
function m:TaskCompleted(OriginatingTaskSchedulerID, OriginatingTaskID, TaskID, IsExceptional) end

Internal.Runtime.Augments.TaskTraceCallbacks = m
return m
