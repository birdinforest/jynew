---@class System.ParseNumbers : System.Object
local m = {}

---@overload fun(s:System.ReadOnlySpan_1_System_Char_, radix:number, flags:number, currPos:System.Int32):(, System.Int32) @static
---@static
---@param s System.ReadOnlySpan_1_System_Char_
---@param radix number
---@param flags number
---@return number
function m.StringToLong(s, radix, flags) end

---@overload fun(s:System.ReadOnlySpan_1_System_Char_, radix:number, flags:number, currPos:System.Int32):(, System.Int32) @static
---@static
---@param s System.ReadOnlySpan_1_System_Char_
---@param radix number
---@param flags number
---@return number
function m.StringToInt(s, radix, flags) end

---@static
---@param n number
---@param radix number
---@param width number
---@param paddingChar number
---@param flags number
---@return string
function m.IntToString(n, radix, width, paddingChar, flags) end

---@static
---@param n number
---@param radix number
---@param width number
---@param paddingChar number
---@param flags number
---@return string
function m.LongToString(n, radix, width, paddingChar, flags) end

System.ParseNumbers = m
return m
