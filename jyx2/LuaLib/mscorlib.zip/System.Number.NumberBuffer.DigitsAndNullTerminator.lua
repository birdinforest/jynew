---@class System.Number.NumberBuffer.DigitsAndNullTerminator : System.ValueType
local m = {}

System.Number.NumberBuffer.DigitsAndNullTerminator = m
return m
