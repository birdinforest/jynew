---@class Internal.IO.File : System.Object
local m = {}

Internal.IO.File = m
return m
