---@class System.Array.SorterObjectArray : System.ValueType
local m = {}

System.Array.SorterObjectArray = m
return m
