---@class System.TimeZoneInfo.__c__DisplayClass16_0 : System.Object
---@field public localtimeFilePath string
---@field public posixrulesFilePath string
---@field public buffer string
---@field public rawData string
---@field public id string
---@field public timeZoneDirectory string
local m = {}

System.TimeZoneInfo.__c__DisplayClass16_0 = m
return m
