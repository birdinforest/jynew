---@class System.LazyDebugView_1_T_ : System.Object
---@field public IsValueCreated boolean
---@field public Value any
---@field public Mode System.Nullable_1_System_Threading_LazyThreadSafetyMode_
---@field public IsValueFaulted boolean
local m = {}

System.LazyDebugView_1_T_ = m
return m
