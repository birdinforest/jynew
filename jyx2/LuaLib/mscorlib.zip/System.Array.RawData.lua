---@class System.Array.RawData : System.Object
---@field public Bounds System.IntPtr
---@field public Count System.IntPtr
---@field public Data number
local m = {}

System.Array.RawData = m
return m
