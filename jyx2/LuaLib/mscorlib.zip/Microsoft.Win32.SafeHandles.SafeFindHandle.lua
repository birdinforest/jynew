---@class Microsoft.Win32.SafeHandles.SafeFindHandle : Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
local m = {}

Microsoft.Win32.SafeHandles.SafeFindHandle = m
return m
