---@class Interop.Sys.Permissions : System.Enum
---@field public Mask Interop.Sys.Permissions @static
---@field public S_IRWXU Interop.Sys.Permissions @static
---@field public S_IRUSR Interop.Sys.Permissions @static
---@field public S_IWUSR Interop.Sys.Permissions @static
---@field public S_IXUSR Interop.Sys.Permissions @static
---@field public S_IRWXG Interop.Sys.Permissions @static
---@field public S_IRGRP Interop.Sys.Permissions @static
---@field public S_IWGRP Interop.Sys.Permissions @static
---@field public S_IXGRP Interop.Sys.Permissions @static
---@field public S_IRWXO Interop.Sys.Permissions @static
---@field public S_IROTH Interop.Sys.Permissions @static
---@field public S_IWOTH Interop.Sys.Permissions @static
---@field public S_IXOTH Interop.Sys.Permissions @static
---@field public value__ number
local m = {}

Interop.Sys.Permissions = m
return m
