---@class System.DateTimeParse.__c : System.Object
---@field public <>9 System.DateTimeParse.__c @static
---@field public <>9__98_0 fun(): @static
local m = {}

System.DateTimeParse.__c = m
return m
