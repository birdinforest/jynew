---@class System.DTSubString : System.ValueType
local m = {}

System.DTSubString = m
return m
