---@class Internal.Runtime.Augments.AsyncStatus : System.Enum
---@field public Started Internal.Runtime.Augments.AsyncStatus @static
---@field public Completed Internal.Runtime.Augments.AsyncStatus @static
---@field public Canceled Internal.Runtime.Augments.AsyncStatus @static
---@field public Error Internal.Runtime.Augments.AsyncStatus @static
---@field public value__ number
local m = {}

Internal.Runtime.Augments.AsyncStatus = m
return m
