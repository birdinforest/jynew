---@class BattleBlockStatus : System.Enum
---@field public Hide BattleBlockStatus @static
---@field public AttackRange BattleBlockStatus @static
---@field public AttackDistance BattleBlockStatus @static
---@field public AttackTarget BattleBlockStatus @static
---@field public CurrentAttackRange BattleBlockStatus @static
---@field public MoveTarget BattleBlockStatus @static
---@field public MoveRange BattleBlockStatus @static
---@field public MoveRangeEnemy BattleBlockStatus @static
---@field public value__ number
local m = {}

BattleBlockStatus = m
return m
