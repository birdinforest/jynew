---@class LevelMasterBooster : UnityEngine.MonoBehaviour
---@field public m_MobileSimulate boolean
---@field public m_IsBattleMap boolean
local m = {}

---@param scene string
---@param path string
---@param replace string
function m:ReplaceSceneObject(scene, path, replace) end

---@param scene string
---@param npc string
---@param controllerPath string
function m:ReplaceNpcAnimatorController(scene, npc, controllerPath) end

---@return boolean
function m:IsBattle() end

---@return Cysharp.Threading.Tasks.UniTask
function m:RefreshSceneObjects() end

LevelMasterBooster = m
return m
