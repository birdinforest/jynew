---@class TileWorldCruncher : UnityEngine.MonoBehaviour
---@field public creator TileWorld.TileWorldCreator
---@field public radius number
---@field public crunchRate number
---@field public subtract boolean
---@field public heightDependent boolean
local m = {}

TileWorldCruncher = m
return m
