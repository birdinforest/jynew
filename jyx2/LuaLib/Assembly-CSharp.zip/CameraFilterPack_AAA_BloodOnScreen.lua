---@class CameraFilterPack_AAA_BloodOnScreen : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Blood_On_Screen number
---@field public Blood_Color UnityEngine.Color
---@field public Blood_Intensify number
---@field public Blood_Darkness number
---@field public Blood_Distortion_Speed number
---@field public Blood_Fade number
local m = {}

CameraFilterPack_AAA_BloodOnScreen = m
return m
