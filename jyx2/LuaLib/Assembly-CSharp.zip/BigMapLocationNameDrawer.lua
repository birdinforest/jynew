---@class BigMapLocationNameDrawer : UnityEngine.MonoBehaviour
---@field public m_NameTextPrefab UnityEngine.GameObject
---@field public m_PositionSize number
---@field public m_LocalScaleSize number
local m = {}

BigMapLocationNameDrawer = m
return m
