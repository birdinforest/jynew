---@class Jyx2.RangeLogic : System.Object
---@field public MOVEBLOCK_MAX_X number @static
---@field public MOVEBLOCK_MAX_Y number @static
---@field public nearblocksCache System.Collections.Generic.Dictionary_2_System_String_System_Collections_Generic_List_1_Jyx2_BattleBlockVector__
local m = {}

---@static
function m.InitNearBlocksCache() end

---@static
---@param tx number
---@param ty number
---@param sx number
---@param sy number
---@return Jyx2.MoveDirection
function m.GetDirection(tx, ty, sx, sy) end

---@overload fun(x:number, y:number, d1:Jyx2.MoveDirection, d2:Jyx2.MoveDirection):
---@param x number
---@param y number
---@param dir Jyx2.MoveDirection
---@return Jyx2.BattleBlockVector
function m:GetNearBlock(x, y, dir) end

---@overload fun(x:number, y:number, maxdistance:number):
---@param x number
---@param y number
---@return System.Collections.Generic.IEnumerable_1_Jyx2_BattleBlockVector_
function m:GetNearBlocks(x, y) end

---@overload fun(sx:number, sy:number, tx:number, ty:number):
---@param sx number
---@param sy number
---@param tx number
---@param ty number
---@param ignoreRole boolean
---@return Jyx2.MoveSearchHelper[]
function m:GetWay(sx, sy, tx, ty, ignoreRole) end

---@param x number
---@param y number
---@param mobility number
---@param ignoreRole boolean
---@return Jyx2.BattleBlockVector[]
function m:GetMoveRange(x, y, mobility, ignoreRole) end

---@param skillCast Jyx2.SkillCastInstance
---@param source Jyx2.RoleInstance
---@return number
function m:GetCastSize(skillCast, source) end

---@static
---@param skillCast Jyx2.SkillCastInstance
---@param source Jyx2.RoleInstance
---@return number
function m.PreCastSizeAdjust(skillCast, source) end

---@static
---@param castsize number
---@param source Jyx2.RoleInstance
---@return number
function m.PostRoleCastSizeAdjust(castsize, source) end

---@param x number
---@param y number
---@param skillCast Jyx2.SkillCastInstance
---@param source Jyx2.RoleInstance
---@return System.Collections.Generic.IEnumerable_1_Jyx2_BattleBlockVector_
function m:GetSkillCastBlocks(x, y, skillCast, source) end

---@param covertype Jyx2.SkillCoverType
---@param tx number
---@param ty number
---@param sx number
---@param sy number
---@param coversize number
---@return Jyx2.BattleBlockVector[]
function m:GetSkillCoverBlocks(covertype, tx, ty, sx, sy, coversize) end

Jyx2.RangeLogic = m
return m
