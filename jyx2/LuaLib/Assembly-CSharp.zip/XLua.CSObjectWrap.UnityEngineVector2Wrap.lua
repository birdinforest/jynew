---@class XLua.CSObjectWrap.UnityEngineVector2Wrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

---@static
---@param L System.IntPtr
---@return number
function m.__CSIndexer(L) end

---@static
---@param L System.IntPtr
---@return number
function m.__NewIndexer(L) end

XLua.CSObjectWrap.UnityEngineVector2Wrap = m
return m
