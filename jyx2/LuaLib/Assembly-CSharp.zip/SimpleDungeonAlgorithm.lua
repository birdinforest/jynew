---@class SimpleDungeonAlgorithm : TileWorld.TileWorldAlgorithms
local m = {}

---@virtual
---@param _config TileWorld.TileWorldConfiguration
---@return boolean[], UnityEngine.Vector3, UnityEngine.Vector3
function m:Generate(_config) end

SimpleDungeonAlgorithm = m
return m
