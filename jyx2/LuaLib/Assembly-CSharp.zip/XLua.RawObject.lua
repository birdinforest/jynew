---@class XLua.RawObject : table
---@field public Target any
local m = {}

XLua.RawObject = m
return m
