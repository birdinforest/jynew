---@class UIComponentFilter : UnityEngine.MonoBehaviour
---@field public m_exportComponentList UnityEngine.Component[]
---@field public m_componentNameDics System.Collections.Generic.Dictionary_2_System_String_System_Boolean_
local m = {}

---@return System.Collections.Generic.Dictionary_2_System_String_System_Boolean_
function m:GetComponentNames() end

---@param list string[]
function m:ChangeExportComponents(list) end

UIComponentFilter = m
return m
