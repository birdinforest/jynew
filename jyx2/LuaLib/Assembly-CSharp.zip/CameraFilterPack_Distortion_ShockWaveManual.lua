---@class CameraFilterPack_Distortion_ShockWaveManual : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public PosX number
---@field public PosY number
---@field public Value number
---@field public Size number
local m = {}

CameraFilterPack_Distortion_ShockWaveManual = m
return m
