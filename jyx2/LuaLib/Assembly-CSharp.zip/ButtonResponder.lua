---@class ButtonResponder : UnityEngine.MonoBehaviour
---@field public GameObjects UnityEngine.GameObject[]
local m = {}

function m:ButtonResponderClicked() end

function m:StandButtonClicked() end

function m:SitButtonClicked() end

function m:LayButtonClicked() end

function m:ConsumeButtonClicked() end

function m:AggressiveButtonClicked() end

function m:WalkButtonClicked() end

function m:ChangeMatButtonClicked() end

function m:ChangeBlendButtonClicked() end

ButtonResponder = m
return m
