---@class DeactiveWhenPlaying : UnityEngine.MonoBehaviour
local m = {}

DeactiveWhenPlaying = m
return m
