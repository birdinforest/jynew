---@class ETCInput : UnityEngine.MonoBehaviour
---@field public _instance ETCInput @static
---@field public instance ETCInput @static
local m = {}

---@param ctrl ETCBase
function m:RegisterControl(ctrl) end

---@param ctrl ETCBase
function m:UnRegisterControl(ctrl) end

function m:Create() end

---@static
---@param ctrl ETCBase
function m.Register(ctrl) end

---@static
---@param ctrl ETCBase
function m.UnRegister(ctrl) end

---@static
---@param ctrlName string
---@param value boolean
function m.SetControlVisible(ctrlName, value) end

---@static
---@param ctrlName string
---@return boolean
function m.GetControlVisible(ctrlName) end

---@static
---@param ctrlName string
---@param value boolean
function m.SetControlActivated(ctrlName, value) end

---@static
---@param ctrlName string
---@return boolean
function m.GetControlActivated(ctrlName) end

---@static
---@param ctrlName string
---@param value boolean
function m.SetControlSwipeIn(ctrlName, value) end

---@static
---@param ctrlName string
---@return boolean
function m.GetControlSwipeIn(ctrlName) end

---@static
---@param ctrlName string
---@param value boolean
function m.SetControlSwipeOut(ctrlName, value) end

---@static
---@param ctrlName string
---@param value boolean
---@return boolean
function m.GetControlSwipeOut(ctrlName, value) end

---@static
---@param ctrlName string
---@param value ETCBase.DPadAxis
function m.SetDPadAxesCount(ctrlName, value) end

---@static
---@param ctrlName string
---@return ETCBase.DPadAxis
function m.GetDPadAxesCount(ctrlName) end

---@static
---@param ctrlName string
---@return ETCJoystick
function m.GetControlJoystick(ctrlName) end

---@static
---@param ctrlName string
---@return ETCDPad
function m.GetControlDPad(ctrlName) end

---@static
---@param ctrlName string
---@return ETCTouchPad
function m.GetControlTouchPad(ctrlName) end

---@static
---@param ctrlName string
---@return ETCButton
function m.GetControlButton(ctrlName) end

---@overload fun(ctrlName:string, spr:UnityEngine.Sprite) @static
---@static
---@param ctrlName string
---@param spr UnityEngine.Sprite
---@param color UnityEngine.Color
function m.SetControlSprite(ctrlName, spr, color) end

---@overload fun(ctrlName:string, spr:UnityEngine.Sprite) @static
---@static
---@param ctrlName string
---@param spr UnityEngine.Sprite
---@param color UnityEngine.Color
function m.SetJoystickThumbSprite(ctrlName, spr, color) end

---@overload fun(ctrlName:string, sprNormal:UnityEngine.Sprite, sprPress:UnityEngine.Sprite) @static
---@static
---@param ctrlName string
---@param sprNormal UnityEngine.Sprite
---@param sprPress UnityEngine.Sprite
---@param color UnityEngine.Color
function m.SetButtonSprite(ctrlName, sprNormal, sprPress, color) end

---@static
---@param axisName string
---@param speed number
function m.SetAxisSpeed(axisName, speed) end

---@static
---@param axisName string
---@param gravity number
function m.SetAxisGravity(axisName, gravity) end

---@static
---@param ctrlName string
---@param speed number
function m.SetTurnMoveSpeed(ctrlName, speed) end

---@static
---@param axisName string
function m.ResetAxis(axisName) end

---@static
---@param axisName string
---@param value boolean
function m.SetAxisEnabled(axisName, value) end

---@static
---@param axisName string
---@return boolean
function m.GetAxisEnabled(axisName) end

---@static
---@param axisName string
---@param value boolean
function m.SetAxisInverted(axisName, value) end

---@static
---@param axisName string
---@return boolean
function m.GetAxisInverted(axisName) end

---@static
---@param axisName string
---@param value number
function m.SetAxisDeadValue(axisName, value) end

---@static
---@param axisName string
---@return number
function m.GetAxisDeadValue(axisName) end

---@static
---@param axisName string
---@param value number
function m.SetAxisSensitivity(axisName, value) end

---@static
---@param axisName string
---@return number
function m.GetAxisSensitivity(axisName) end

---@static
---@param axisName string
---@param value number
function m.SetAxisThreshold(axisName, value) end

---@static
---@param axisName string
---@return number
function m.GetAxisThreshold(axisName) end

---@static
---@param axisName string
---@param value boolean
function m.SetAxisInertia(axisName, value) end

---@static
---@param axisName string
---@return boolean
function m.GetAxisInertia(axisName) end

---@static
---@param axisName string
---@param value number
function m.SetAxisInertiaSpeed(axisName, value) end

---@static
---@param axisName string
---@return number
function m.GetAxisInertiaSpeed(axisName) end

---@static
---@param axisName string
---@param value number
function m.SetAxisInertiaThreshold(axisName, value) end

---@static
---@param axisName string
---@return number
function m.GetAxisInertiaThreshold(axisName) end

---@static
---@param axisName string
---@param value boolean
function m.SetAxisAutoStabilization(axisName, value) end

---@static
---@param axisName string
---@return boolean
function m.GetAxisAutoStabilization(axisName) end

---@static
---@param axisName string
---@param value number
function m.SetAxisAutoStabilizationSpeed(axisName, value) end

---@static
---@param axisName string
---@return number
function m.GetAxisAutoStabilizationSpeed(axisName) end

---@static
---@param axisName string
---@param value number
function m.SetAxisAutoStabilizationThreshold(axisName, value) end

---@static
---@param axisName string
---@return number
function m.GetAxisAutoStabilizationThreshold(axisName) end

---@static
---@param axisName string
---@param value boolean
function m.SetAxisClampRotation(axisName, value) end

---@static
---@param axisName string
---@return boolean
function m.GetAxisClampRotation(axisName) end

---@static
---@param axisName string
---@param min number
---@param max number
function m.SetAxisClampRotationValue(axisName, min, max) end

---@static
---@param axisName string
---@param value number
function m.SetAxisClampRotationMinValue(axisName, value) end

---@static
---@param axisName string
---@param value number
function m.SetAxisClampRotationMaxValue(axisName, value) end

---@static
---@param axisName string
---@return number
function m.GetAxisClampRotationMinValue(axisName) end

---@static
---@param axisName string
---@return number
function m.GetAxisClampRotationMaxValue(axisName) end

---@static
---@param axisName string
---@param value UnityEngine.Transform
function m.SetAxisDirecTransform(axisName, value) end

---@static
---@param axisName string
---@return UnityEngine.Transform
function m.GetAxisDirectTransform(axisName) end

---@static
---@param axisName string
---@param value ETCAxis.DirectAction
function m.SetAxisDirectAction(axisName, value) end

---@static
---@param axisName string
---@return ETCAxis.DirectAction
function m.GetAxisDirectAction(axisName) end

---@static
---@param axisName string
---@param value ETCAxis.AxisInfluenced
function m.SetAxisAffectedAxis(axisName, value) end

---@static
---@param axisName string
---@return ETCAxis.AxisInfluenced
function m.GetAxisAffectedAxis(axisName) end

---@static
---@param axisName string
---@param value boolean
function m.SetAxisOverTime(axisName, value) end

---@static
---@param axisName string
---@return boolean
function m.GetAxisOverTime(axisName) end

---@static
---@param axisName string
---@param value number
function m.SetAxisOverTimeStep(axisName, value) end

---@static
---@param axisName string
---@return number
function m.GetAxisOverTimeStep(axisName) end

---@static
---@param axisName string
---@param value number
function m.SetAxisOverTimeMaxValue(axisName, value) end

---@static
---@param axisName string
---@return number
function m.GetAxisOverTimeMaxValue(axisName) end

---@static
---@param axisName string
---@return number
function m.GetAxis(axisName) end

---@static
---@param axisName string
---@return number
function m.GetAxisSpeed(axisName) end

---@static
---@param axisName string
---@return boolean
function m.GetAxisDownUp(axisName) end

---@static
---@param axisName string
---@return boolean
function m.GetAxisDownDown(axisName) end

---@static
---@param axisName string
---@return boolean
function m.GetAxisDownRight(axisName) end

---@static
---@param axisName string
---@return boolean
function m.GetAxisDownLeft(axisName) end

---@static
---@param axisName string
---@return boolean
function m.GetAxisPressedUp(axisName) end

---@static
---@param axisName string
---@return boolean
function m.GetAxisPressedDown(axisName) end

---@static
---@param axisName string
---@return boolean
function m.GetAxisPressedRight(axisName) end

---@static
---@param axisName string
---@return boolean
function m.GetAxisPressedLeft(axisName) end

---@static
---@param buttonName string
---@return boolean
function m.GetButtonDown(buttonName) end

---@static
---@param buttonName string
---@return boolean
function m.GetButton(buttonName) end

---@static
---@param buttonName string
---@return boolean
function m.GetButtonUp(buttonName) end

---@static
---@param buttonName string
---@return number
function m.GetButtonValue(buttonName) end

ETCInput = m
return m
