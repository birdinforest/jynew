---@class XiakeUIPanel : Jyx2_UIBase
---@field public Layer UILayer
---@field public CurItemIdx number
---@field public IsSelectOnOpertaionBtn boolean
local m = {}

function m:InitTrans() end

function m:TryFocusOnRightButton() end

function m:OnBackClick() end

function m:TabLeft() end

function m:TabRight() end

---@param idx number
function m:SelectRoleItem(idx) end

XiakeUIPanel = m
return m
