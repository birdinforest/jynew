---@class CameraFilterPack_AAA_WaterDropPro : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Distortion number
---@field public SizeX number
---@field public SizeY number
---@field public Speed number
local m = {}

CameraFilterPack_AAA_WaterDropPro = m
return m
