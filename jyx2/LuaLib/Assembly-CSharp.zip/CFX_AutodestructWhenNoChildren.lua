---@class CFX_AutodestructWhenNoChildren : UnityEngine.MonoBehaviour
local m = {}

CFX_AutodestructWhenNoChildren = m
return m
