---@class CameraFilterPack_3D_Snow : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public _Visualize boolean
---@field public _FixDistance number
---@field public Snow_Near number
---@field public Snow_Far number
---@field public Fade number
---@field public Intensity number
---@field public Size number
---@field public Speed number
---@field public SnowWithoutObject number
local m = {}

CameraFilterPack_3D_Snow = m
return m
