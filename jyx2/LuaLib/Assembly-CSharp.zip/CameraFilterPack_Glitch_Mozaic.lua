---@class CameraFilterPack_Glitch_Mozaic : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Intensity number
local m = {}

CameraFilterPack_Glitch_Mozaic = m
return m
