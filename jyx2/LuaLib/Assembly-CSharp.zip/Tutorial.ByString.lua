---@class Tutorial.ByString : UnityEngine.MonoBehaviour
local m = {}

Tutorial.ByString = m
return m
