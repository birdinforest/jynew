---@class ConStr : System.Object
---@field public BattleBlockDatasetPath string @static
---@field public BattleboxDatasetPath string @static
---@field public LevelMaster string @static
---@field public Player string @static
---@field public PlayerPointLight string @static
---@field public DefaultSword string @static
---@field public DefaultKnife string @static
---@field public DefaultSpear string @static
local m = {}

ConStr = m
return m
