---@class XLuaTest.MyStruct : System.ValueType
---@field public a number
---@field public b number
---@field public c System.Decimal
---@field public e XLuaTest.Pedding
local m = {}

XLuaTest.MyStruct = m
return m
