---@class ScreenLoggerHotkeyManager : UnityEngine.MonoBehaviour
---@field public screenLogger AClockworkBerry.ScreenLogger
---@field public isloggerOn boolean
local m = {}

ScreenLoggerHotkeyManager = m
return m
