---@class LuaTestStarter : UnityEngine.ScriptableObject
---@field public luaFiles UnityEngine.TextAsset[]
local m = {}

function m:luaTest() end

LuaTestStarter = m
return m
