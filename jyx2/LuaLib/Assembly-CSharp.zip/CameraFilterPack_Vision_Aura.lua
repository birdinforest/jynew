---@class CameraFilterPack_Vision_Aura : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Twist number
---@field public Speed number
---@field public Color UnityEngine.Color
---@field public PosX number
---@field public PosY number
local m = {}

CameraFilterPack_Vision_Aura = m
return m
