---@class CameraFilterPack_Blur_Radial : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Intensity number
---@field public MovX number
---@field public MovY number
local m = {}

CameraFilterPack_Blur_Radial = m
return m
