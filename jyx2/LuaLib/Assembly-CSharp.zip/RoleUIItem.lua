---@class RoleUIItem : UnityEngine.UI.Selectable
---@field public IsSelected boolean
local m = {}

---@param value fun(arg1:RoleUIItem, arg2:boolean)
function m:add_OnSelectStateChange(value) end

---@param value fun(arg1:RoleUIItem, arg2:boolean)
function m:remove_OnSelectStateChange(value) end

---@virtual
---@param data Jyx2.RoleInstance
function m:SetData(data) end

---@overload fun(_isSelected:boolean)
---@param _isSelected boolean
---@param notifyEvent boolean
function m:SetState(_isSelected, notifyEvent) end

---@return Jyx2.RoleInstance
function m:GetShowRole() end

---@overload fun(up:Jyx2.UINavigation.INavigable, down:Jyx2.UINavigation.INavigable, left:Jyx2.UINavigation.INavigable) @virtual
---@overload fun(up:Jyx2.UINavigation.INavigable, down:Jyx2.UINavigation.INavigable) @virtual
---@overload fun(up:Jyx2.UINavigation.INavigable) @virtual
---@overload fun() @virtual
---@virtual
---@param up Jyx2.UINavigation.INavigable
---@param down Jyx2.UINavigation.INavigable
---@param left Jyx2.UINavigation.INavigable
---@param right Jyx2.UINavigation.INavigable
function m:Connect(up, down, left, right) end

---@virtual
---@return UnityEngine.UI.Selectable
function m:GetSelectable() end

---@virtual
---@param notifyEvent boolean
function m:Select(notifyEvent) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerClick(eventData) end

RoleUIItem = m
return m
