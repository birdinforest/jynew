---@class Jyx2.BattleResult : System.Enum
---@field public Win Jyx2.BattleResult @static
---@field public Lose Jyx2.BattleResult @static
---@field public InProgress Jyx2.BattleResult @static
---@field public Surrender Jyx2.BattleResult @static
---@field public value__ number
local m = {}

Jyx2.BattleResult = m
return m
