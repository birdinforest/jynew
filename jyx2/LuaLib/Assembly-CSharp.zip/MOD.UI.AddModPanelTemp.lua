---@class MOD.UI.AddModPanelTemp : UnityEngine.MonoBehaviour
local m = {}

function m:Show() end

function m:Hide() end

function m:RequestUserPermission() end

MOD.UI.AddModPanelTemp = m
return m
