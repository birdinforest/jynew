---@class CameraFilterPack_Drawing_Paper3 : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Pencil_Color UnityEngine.Color
---@field public Pencil_Size number
---@field public Pencil_Correction number
---@field public Intensity number
---@field public Speed_Animation number
---@field public Corner_Lose number
---@field public Fade_Paper_to_BackColor number
---@field public Fade_With_Original number
---@field public Back_Color UnityEngine.Color
local m = {}

CameraFilterPack_Drawing_Paper3 = m
return m
