---@class Jyx2Boat : UnityEngine.MonoBehaviour
local m = {}

function m:GetInBoat() end

function m:GetOutBoat() end

Jyx2Boat = m
return m
