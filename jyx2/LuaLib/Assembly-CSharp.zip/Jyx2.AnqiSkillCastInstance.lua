---@class Jyx2.AnqiSkillCastInstance : Jyx2.SkillCastInstance
local m = {}

---@virtual
---@return boolean
function m:IsAttack() end

---@virtual
---@return Jyx2.SkillCoverType
function m:GetCoverType() end

---@virtual
---@return number
function m:GetCoverSize() end

---@virtual
---@return number
function m:GetCastSize() end

Jyx2.AnqiSkillCastInstance = m
return m
