---@class DemoShooting : UnityEngine.MonoBehaviour
---@field public FirePoint UnityEngine.GameObject
---@field public Cam UnityEngine.Camera
---@field public MaxLength number
---@field public Prefabs UnityEngine.GameObject[]
---@field public camAnim UnityEngine.Animation
local m = {}

DemoShooting = m
return m
