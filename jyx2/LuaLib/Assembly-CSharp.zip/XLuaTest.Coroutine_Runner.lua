---@class XLuaTest.Coroutine_Runner : UnityEngine.MonoBehaviour
local m = {}

XLuaTest.Coroutine_Runner = m
return m
