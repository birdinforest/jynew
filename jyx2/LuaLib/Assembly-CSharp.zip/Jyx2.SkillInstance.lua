---@class Jyx2.SkillInstance : System.Object
---@field public Key number
---@field public Level number
---@field public Data Jyx2.LSkillConfig
---@field public LevelInfo Jyx2.LSkillLevel[]
---@field public Name string
---@field public CoverType Jyx2.SkillCoverType
---@field public CastSize number
---@field public CoverSize number
local m = {}

function m:ResetSkill() end

---@return number
function m:GetLevel() end

---@overload fun():
---@param level number
---@return Jyx2.LSkillLevel
function m:GetSkillLevelInfo(level) end

---@overload fun():
---@param _anqi Jyx2.LItemConfig
---@return Jyx2.LSkillConfig
function m:GetSkill(_anqi) end

---@return Jyx2.LSkillLevel[]
function m:GetLevelInfo() end

---@return Jyx2SkillDisplayAsset
function m:GetDisplay() end

---@return number
function m:GetCoolDown() end

Jyx2.SkillInstance = m
return m
