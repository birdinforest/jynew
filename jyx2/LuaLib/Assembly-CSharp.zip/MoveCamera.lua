---@class MoveCamera : UnityEngine.MonoBehaviour
---@field public turnSpeed number
---@field public panSpeed number
---@field public zoomSpeed number
local m = {}

MoveCamera = m
return m
