---@class HUDItem : UnityEngine.MonoBehaviour
local m = {}

function m:Init() end

---@param role Jyx2.RoleInstance
function m:BindRole(role) end

HUDItem = m
return m
