---@class XLuaTest.BaseTestBase_1_T_ : XLuaTest.BaseTestHelper
local m = {}

---@virtual
---@param p number
function m:Foo(p) end

XLuaTest.BaseTestBase_1_T_ = m
return m
