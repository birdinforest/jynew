---@class XLuaTest.Foo2Parent : System.Object
local m = {}

XLuaTest.Foo2Parent = m
return m
