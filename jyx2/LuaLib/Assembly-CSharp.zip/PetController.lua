---@class PetController : UnityEngine.MonoBehaviour
---@field public player UnityEngine.GameObject
---@field public stopDistance number
---@field public lostDistance number
---@field public rotationSpeed number
local m = {}

PetController = m
return m
