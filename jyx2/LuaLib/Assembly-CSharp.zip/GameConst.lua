---@class GameConst : System.Object
---@field public DEFAULT_GAME_MOD_NAME string @static
---@field public DefaultMainMenuScene string @static
---@field public MapAngularSpeed number @static
---@field public MapAcceleration number @static
---@field public SEMI_REAL boolean @static
---@field public ACTION_SP number @static
---@field public MAX_EXP number @static
---@field public MAX_SKILL_LEVEL number @static
---@field public MAX_BATTLE_TEAMMATE_COUNT number @static
---@field public MAX_CHAT_CHART_NUM number @static
---@field public MAX_BATTLE_RESULT_LINE_NUM number @static
---@field public WORLD_MAP_ID number @static
---@field public UI_PREFAB_PATH string @static
---@field public ProItemDic System.Collections.Generic.Dictionary_2_System_String_PropertyItem_ @static
---@field public PLAYER_PREF_VOLUME string @static
---@field public PLAYER_PREF_SOUND_EFFECT string @static
---@field public PLAYER_PREF_RESOLUTION string @static
---@field public PLAYER_PREF_FULLSCREEN string @static
---@field public PLAYER_PREF_VIEWPORT_TYPE string @static
---@field public PLAYER_PREF_Difficulty string @static
---@field public PLAYER_PREF_LANGUAGE string @static
---@field public PLAYER_PREF_DEBUGMODE string @static
---@field public PLAYER_MOBILE_MOVE_MODE string @static
---@field public MAX_ROLE_LEVEL number @static
---@field public MAX_ROLE_TILI number @static
---@field public MAX_POISON number @static
---@field public MAX_USE_POISON number @static
---@field public MAX_HEAL number @static
---@field public MAX_DEPOISON number @static
---@field public MAX_ANTIPOISON number @static
---@field public MAX_HURT number @static
---@field public CAM_SMOOTHING number @static
---@field public GAME_START_MUSIC_ID number @static
---@field public MAX_ROLE_WEAPON_ATTR number @static
---@field public MAX_ROLE_HP number @static
---@field public MAX_ROLE_MP number @static
---@field public MAX_ROLE_ATTACK number @static
---@field public MAX_ROLE_DEFENCE number @static
---@field public MAX_ROLE_QINGGONG number @static
---@field public MAX_ROLE_ATK_POISON number @static
---@field public MAX_ROLE_SHENGWANG number @static
---@field public MAX_ROLE_PINDE number @static
---@field public MAX_ROLE_ZIZHI number @static
---@field public MAX_WUGONG_LEVEL number @static
---@field public MONEY_ID number @static
---@field public MAX_TEAMCOUNT number @static
---@field public MAX_SKILL_COUNT number @static
---@field public MAX_ROLE_ATTRIBUTE number @static
---@field public _levelUpExpList number[] @static
---@field public SAVE_COUNT number @static
local m = {}

---@static
---@param index number
---@return string
function m.GetUPNumber(index) end

GameConst = m
return m
