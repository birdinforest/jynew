---@class XLuaTest.CoroutineConfig : System.Object
---@field public LuaCallCSharp System.Type[] @static
local m = {}

XLuaTest.CoroutineConfig = m
return m
