---@class ParticleCollisionInstance : UnityEngine.MonoBehaviour
---@field public EffectsOnCollision UnityEngine.GameObject[]
---@field public DestroyTimeDelay number
---@field public UseWorldSpacePosition boolean
---@field public Offset number
---@field public rotationOffset UnityEngine.Vector3
---@field public useOnlyRotationOffset boolean
---@field public UseFirePointRotation boolean
---@field public DestoyMainEffect boolean
local m = {}

ParticleCollisionInstance = m
return m
