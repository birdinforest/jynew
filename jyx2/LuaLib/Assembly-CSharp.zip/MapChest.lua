---@class MapChest : UnityEngine.MonoBehaviour
---@field public ID string
---@field public displayType MapChest.MapChestOpenDisplayType
---@field public isLock boolean
local m = {}

function m:Init() end

---@return Cysharp.Threading.Tasks.UniTask
function m:MarkAsOpened() end

---@param status boolean
function m:ChangeLockStatus(status) end

MapChest = m
return m
