---@class Jyx2.BattleBlockType : System.Enum
---@field public MoveZone Jyx2.BattleBlockType @static
---@field public AttackZone Jyx2.BattleBlockType @static
---@field public value__ number
local m = {}

Jyx2.BattleBlockType = m
return m
