---@class CameraFilterPack_Blur_Radial_Fast : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Intensity number
---@field public MovX number
---@field public MovY number
local m = {}

CameraFilterPack_Blur_Radial_Fast = m
return m
