---@class InteractUIPanel : Jyx2_UIBase
---@field public Layer UILayer
local m = {}

---@param buttonIndex number
function m:OnBtnClick(buttonIndex) end

---@param buttonIndex number
---@return boolean
function m:IsButtonAvailable(buttonIndex) end

function m:InitTrans() end

InteractUIPanel = m
return m
