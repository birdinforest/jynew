---@class Jyx2RoleHeadUI : UnityEngine.MonoBehaviour
---@field public ForceChecked boolean
---@field public headImage UnityEngine.UI.Image
---@field public checkImage UnityEngine.UI.Image
---@field public btn UnityEngine.UI.Button
---@field public IsChecked boolean
local m = {}

---@static
---@param role Jyx2.RoleInstance
---@param forceChecked boolean
---@param clickCallback fun()
---@return Jyx2RoleHeadUI
function m.Create(role, forceChecked, clickCallback) end

---@param role Jyx2.RoleInstance
---@param forceChecked boolean
---@param clickCallback fun()
function m:Show(role, forceChecked, clickCallback) end

function m:OnClick() end

---@return Jyx2.RoleInstance
function m:GetRole() end

Jyx2RoleHeadUI = m
return m
