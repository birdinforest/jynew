---@class XLua.BlackListAttribute : System.Attribute
local m = {}

XLua.BlackListAttribute = m
return m
