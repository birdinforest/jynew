---@class Tutorial.ByFile : UnityEngine.MonoBehaviour
local m = {}

Tutorial.ByFile = m
return m
