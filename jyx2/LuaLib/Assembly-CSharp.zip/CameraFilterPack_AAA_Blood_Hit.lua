---@class CameraFilterPack_AAA_Blood_Hit : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Hit_Left number
---@field public Hit_Up number
---@field public Hit_Right number
---@field public Hit_Down number
---@field public Blood_Hit_Left number
---@field public Blood_Hit_Up number
---@field public Blood_Hit_Right number
---@field public Blood_Hit_Down number
---@field public Hit_Full number
---@field public Blood_Hit_Full_1 number
---@field public Blood_Hit_Full_2 number
---@field public Blood_Hit_Full_3 number
---@field public LightReflect number
local m = {}

CameraFilterPack_AAA_Blood_Hit = m
return m
