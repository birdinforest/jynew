---@class Jyx2.BattleFieldModel : System.Object
---@field public Roles Jyx2.RoleInstance[]
---@field public Dead Jyx2.RoleInstance[]
---@field public Callback fun(obj:Jyx2.BattleResult)
---@field public AliveRoles Jyx2.RoleInstance[]
---@field public Teammates Jyx2.RoleInstance[]
---@field public Enemys Jyx2.RoleInstance[]
local m = {}

function m:InitBattleModel() end

---@param role Jyx2.RoleInstance
---@param pos Jyx2.BattleBlockVector
---@param team number
---@param isAI boolean
function m:AddBattleRole(role, pos, team, isAI) end

---@param x number
---@param y number
---@return boolean
function m:BlockHasRole(x, y) end

---@param x number
---@param y number
---@return number
function m:BlockRoleTeam(x, y) end

---@param vec Jyx2.BattleBlockVector
---@return Jyx2.RoleInstance
function m:GetAliveRole(vec) end

---@return Jyx2.BattleResult
function m:GetBattleResult() end

---@param _isSurrendered boolean
function m:SetIsSurrendered(_isSurrendered) end

---@param role Jyx2.RoleInstance
function m:OnActioned(role) end

---@param role Jyx2.RoleInstance
function m:ActWait(role) end

---@return Jyx2.RoleInstance
function m:GetNextActiveRole() end

---@param role Jyx2.RoleInstance
---@return boolean
function m:IsLastRole(role) end

---@param team number
---@return number
function m:GetTotalWuXueChangShi(team) end

Jyx2.BattleFieldModel = m
return m
