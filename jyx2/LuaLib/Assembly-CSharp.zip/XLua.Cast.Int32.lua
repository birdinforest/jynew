---@class XLua.Cast.Int32 : XLua.Cast.Any_1_System_Int32_
local m = {}

XLua.Cast.Int32 = m
return m
