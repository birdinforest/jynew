---@class Jyx2.BattleManager : UnityEngine.MonoBehaviour
---@field public Whosyourdad boolean @static
---@field public Instance Jyx2.BattleManager @static
---@field public IsInBattle boolean
local m = {}

---@return Jyx2.BattleFieldModel
function m:GetModel() end

---@return Jyx2.RangeLogic
function m:GetRangeLogic() end

---@param customParams Jyx2.BattleStartParams
---@return Cysharp.Threading.Tasks.UniTask
function m:StartBattle(customParams) end

---@param result Jyx2.BattleResult
function m:OnBattleEnd(result) end

function m:EndBattle() end

---@param role Jyx2.RoleInstance
function m:AddBattleRole(role) end

---@param skill Jyx2.SkillCastInstance
---@param targetPos Jyx2.BattleBlockVector
---@param selfPos Jyx2.BattleBlockVector
---@return System.Collections.Generic.IEnumerable_1_Jyx2_BattleBlockVector_
function m:GetSkillCoverBlocks(skill, targetPos, selfPos) end

---@param role Jyx2.RoleInstance
---@param block Jyx2.BattleBlockVector
---@return UnityEngine.Vector3[]
function m:FindMovePath(role, block) end

---@param role Jyx2.RoleInstance
---@param movedStep number
---@return Jyx2.BattleBlockVector[]
function m:GetMoveRange(role, movedStep) end

---@param role Jyx2.RoleInstance
---@param skillCast Jyx2.SkillCastInstance
---@return Jyx2.BattleBlockVector[]
function m:GetSkillUseRange(role, skillCast) end

---@param skill Jyx2.SkillCastInstance
---@param range System.Collections.Generic.IEnumerable_1_Jyx2_BattleBlockVector_
---@param team number
---@return Jyx2.RoleInstance[]
function m:GetRoleInSkillRange(skill, range, team) end

Jyx2.BattleManager = m
return m
