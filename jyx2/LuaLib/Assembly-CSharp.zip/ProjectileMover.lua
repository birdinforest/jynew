---@class ProjectileMover : UnityEngine.MonoBehaviour
---@field public speed number
---@field public hitOffset number
---@field public UseFirePointRotation boolean
---@field public rotationOffset UnityEngine.Vector3
---@field public hit UnityEngine.GameObject
---@field public flash UnityEngine.GameObject
---@field public Detached UnityEngine.GameObject[]
local m = {}

ProjectileMover = m
return m
