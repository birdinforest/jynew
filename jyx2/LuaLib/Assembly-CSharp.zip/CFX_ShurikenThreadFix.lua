---@class CFX_ShurikenThreadFix : UnityEngine.MonoBehaviour
local m = {}

CFX_ShurikenThreadFix = m
return m
