---@class XLua.CSObjectWrap.Jyx2LRoleConfigBridge : XLua.LuaBase
local m = {}

---@static
---@param reference number
---@param luaenv XLua.LuaEnv
---@return XLua.LuaBase
function m.__Create(reference, luaenv) end

XLua.CSObjectWrap.Jyx2LRoleConfigBridge = m
return m
