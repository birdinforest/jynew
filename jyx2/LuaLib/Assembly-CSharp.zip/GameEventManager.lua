---@class GameEventManager : UnityEngine.MonoBehaviour
local m = {}

---@param newEvent GameEvent
---@return boolean
function m:OnTriggerEvent(newEvent) end

---@param evt GameEvent
function m:OnExitEvent(evt) end

function m:OnExitAllEvents() end

---@overload fun(eventName:string)
---@param eventName string
---@param context Jyx2.JYX2EventContext
function m:ExecuteJyx2Event(eventName, context) end

---@param evt GameEvent
function m:SetCurrentGameEvent(evt) end

---@static
---@return GameEvent
function m.GetCurrentGameEvent() end

---@static
---@param id string
---@return GameEvent
function m.GetGameEventByID(id) end

GameEventManager = m
return m
