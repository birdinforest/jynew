---@class MOD.UI.AddModPanel : UnityEngine.MonoBehaviour
local m = {}

MOD.UI.AddModPanel = m
return m
