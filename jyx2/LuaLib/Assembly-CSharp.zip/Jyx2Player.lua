---@class Jyx2Player : UnityEngine.MonoBehaviour
---@field public m_Animator UnityEngine.Animator
---@field public IsOnBoat boolean
---@field public IsInTimeline boolean
---@field public CanControlPlayer boolean
local m = {}

---@static
---@return Jyx2Player
function m.GetPlayer() end

---@return Cysharp.Threading.Tasks.UniTask
function m:OnSceneLoad() end

---@param boat Jyx2Boat
function m:GetInBoat(boat) end

---@return boolean
function m:GetOutBoat() end

function m:GetInSecret() end

function m:GetOutSecret() end

function m:Init() end

function m:RecordWorldInfo() end

function m:LoadWorldInfo() end

function m:LoadBoat() end

---@return UnityEngine.Vector3
function m:GetBoatPosition() end

function m:StopPlayerMovement() end

Jyx2Player = m
return m
