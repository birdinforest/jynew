---@class MODRootConfig : UnityEngine.ScriptableObject
---@field public ModId string
---@field public IsNativeMod boolean
---@field public Desc string
---@field public Version string
---@field public ModName string
---@field public ModRootDir string
---@field public Author string
---@field public LuaFilePatten string
---@field public ModArchiveVersion number
---@field public PlayerName string
---@field public PreloadedLua string[]
---@field public EnableSaveBigMapOnly boolean
---@field public EnableKickTeammateBigMapOnly boolean
---@field public AutoBattleOnly boolean
---@field public BattleTimeScale number
---@field public ShowSkillNameInBattle boolean
---@field public IsConsoleEnable boolean
---@field public ConsoleDisableDifficulty Jyx2_GameDifficulty[]
---@field public IsPlayUseItemAnimation boolean
---@field public StoryIdNameFixes StoryIdNameFix[]
---@field public CameraOffsetNear UnityEngine.Vector3
---@field public CameraOffsetFar UnityEngine.Vector3
local m = {}

function m:GenerateConfigs() end

---@return Jyx2.MOD.ModV2.GameModInfo
function m:CreateModInfo() end

MODRootConfig = m
return m
