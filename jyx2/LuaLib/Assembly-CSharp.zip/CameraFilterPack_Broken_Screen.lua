---@class CameraFilterPack_Broken_Screen : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Fade number
---@field public Shadow number
local m = {}

CameraFilterPack_Broken_Screen = m
return m
