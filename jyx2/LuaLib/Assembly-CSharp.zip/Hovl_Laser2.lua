---@class Hovl_Laser2 : UnityEngine.MonoBehaviour
---@field public laserScale number
---@field public laserColor UnityEngine.Color
---@field public HitEffect UnityEngine.GameObject
---@field public FlashEffect UnityEngine.GameObject
---@field public HitOffset number
---@field public MaxLength number
local m = {}

function m:DisablePrepare() end

Hovl_Laser2 = m
return m
