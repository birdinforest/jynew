---@class bl_UHTUtils : System.Object
---@field public GetHUDText bl_HUDText @static
local m = {}

bl_UHTUtils = m
return m
