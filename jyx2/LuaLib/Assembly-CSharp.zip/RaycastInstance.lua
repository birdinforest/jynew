---@class RaycastInstance : UnityEngine.MonoBehaviour
---@field public Cam UnityEngine.Camera
---@field public Prefabs UnityEngine.GameObject[]
local m = {}

RaycastInstance = m
return m
