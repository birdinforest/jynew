---@class Security.XXTEA : System.Object
local m = {}

---@overload fun(data:string, key:string): @static
---@overload fun(data:string, key:string): @static
---@overload fun(data:string, key:string): @static
---@static
---@param data string
---@param key string
---@return string
function m.Encrypt(data, key) end

---@overload fun(data:string, key:string): @static
---@overload fun(data:string, key:string): @static
---@overload fun(data:string, key:string): @static
---@static
---@param data string
---@param key string
---@return string
function m.EncryptToBase64String(data, key) end

---@overload fun(data:string, key:string): @static
---@static
---@param data string
---@param key string
---@return string
function m.Decrypt(data, key) end

---@overload fun(data:string, key:string): @static
---@static
---@param data string
---@param key string
---@return string
function m.DecryptBase64String(data, key) end

---@overload fun(data:string, key:string): @static
---@static
---@param data string
---@param key string
---@return string
function m.DecryptToString(data, key) end

---@overload fun(data:string, key:string): @static
---@static
---@param data string
---@param key string
---@return string
function m.DecryptBase64StringToString(data, key) end

Security.XXTEA = m
return m
