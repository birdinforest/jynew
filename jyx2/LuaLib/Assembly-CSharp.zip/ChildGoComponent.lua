---@class ChildGoComponent : UnityEngine.MonoBehaviour
local m = {}

---@overload fun(trans:UnityEngine.Transform)
---@param trans UnityEngine.Transform
---@param onCreate fun(obj:UnityEngine.Transform)
function m:Init(trans, onCreate) end

---@param count number
function m:RefreshChildCount(count) end

---@return UnityEngine.Transform[]
function m:GetUsingTransList() end

ChildGoComponent = m
return m
