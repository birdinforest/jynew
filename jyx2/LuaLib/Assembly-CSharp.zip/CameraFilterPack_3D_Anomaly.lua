---@class CameraFilterPack_3D_Anomaly : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public _Visualize boolean
---@field public _FixDistance number
---@field public Anomaly_Near number
---@field public Anomaly_Far number
---@field public Intensity number
---@field public AnomalyWithoutObject number
---@field public Anomaly_Distortion number
---@field public Anomaly_Distortion_Size number
---@field public Anomaly_Intensity number
local m = {}

CameraFilterPack_3D_Anomaly = m
return m
