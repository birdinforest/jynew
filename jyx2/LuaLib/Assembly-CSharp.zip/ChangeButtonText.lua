---@class ChangeButtonText : UnityEngine.MonoBehaviour
---@field public ValuetoGet number
---@field public AnimationNames string[]
---@field public AnimationSelected string
local m = {}

function m:ChangeText() end

ChangeButtonText = m
return m
