---@class MessageBox : Jyx2_UIBase
---@field public Layer UILayer
local m = {}

---@overload fun(msg:string, onConfirm:fun()) @static
---@overload fun(msg:string) @static
---@static
---@param msg string
---@param onConfirm fun()
---@param uiLayer UILayer
function m.ShowMessage(msg, onConfirm, uiLayer) end

---@overload fun(msg:string, onConfirm:fun(), onCancel:fun()) @static
---@overload fun(msg:string, onConfirm:fun()) @static
---@overload fun(msg:string) @static
---@static
---@param msg string
---@param onConfirm fun()
---@param onCancel fun()
---@param uiLayer UILayer
function m.ConfirmOrCancel(msg, onConfirm, onCancel, uiLayer) end

MessageBox = m
return m
