---@class Jyx2_UIManager : UnityEngine.MonoBehaviour
---@field public Instance Jyx2_UIManager @static
local m = {}

---@static
function m.Clear() end

---@param ui Jyx2_UIBase
---@return boolean
function m:IsTopVisibleUI(ui) end

---@return Cysharp.Threading.Tasks.UniTask
function m:GameStart() end

---@param layer UILayer
---@return UnityEngine.Transform
function m:GetUIParent(layer) end

---@overload fun(uiName:string):
---@overload fun(...:any|any[]):
---@overload fun():
---@param uiName string
---@param ... any|any[]
---@return Cysharp.Threading.Tasks.UniTask
function m:ShowUIAsync(uiName, ...) end

---@overload fun():
---@param ... any|any[]
---@return Jyx2_UIBase
function m:ShowUI(...) end

---@return Cysharp.Threading.Tasks.UniTask
function m:ShowMainUI() end

---@overload fun()
---@param uiName string
function m:HideUI(uiName) end

function m:HideAllUI() end

function m:CloseAllUI() end

---@return UnityEngine.Camera
function m:GetUICamera() end

---@return Jyx2_UIBase
function m:GetUI() end

---@param uiName string
---@return boolean
function m:IsUIOpen(uiName) end

Jyx2_UIManager = m
return m
