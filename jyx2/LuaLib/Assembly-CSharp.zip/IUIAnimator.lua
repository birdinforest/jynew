---@class IUIAnimator : table
local m = {}

---@abstract
function m:DoShowAnimator() end

---@abstract
function m:DoHideAnimator() end

IUIAnimator = m
return m
