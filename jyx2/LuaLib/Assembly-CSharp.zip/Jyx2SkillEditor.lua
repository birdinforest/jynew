---@class Jyx2SkillEditor : UnityEngine.MonoBehaviour
---@field public player Jyx2SkillEditorEnemy
---@field public enemys Jyx2SkillEditorEnemy[]
---@field public faceTrans UnityEngine.Transform[]
---@field public lineTrans UnityEngine.Transform[]
---@field public crossTrans UnityEngine.Transform[]
---@field public coverType Jyx2.SkillCoverType
local m = {}

---@param skill Jyx2SkillDisplayAsset
function m:PreviewSkill(skill) end

Jyx2SkillEditor = m
return m
