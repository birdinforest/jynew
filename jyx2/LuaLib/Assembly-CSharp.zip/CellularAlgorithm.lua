---@class CellularAlgorithm : TileWorld.TileWorldAlgorithms
---@field public islands CellularAlgorithm.Island[]
---@field public waterIslands CellularAlgorithm.Island[]
---@field public bigIslandIndex number
local m = {}

---@virtual
---@param _config TileWorld.TileWorldConfiguration
---@return boolean[], UnityEngine.Vector3, UnityEngine.Vector3
function m:Generate(_config) end

CellularAlgorithm = m
return m
