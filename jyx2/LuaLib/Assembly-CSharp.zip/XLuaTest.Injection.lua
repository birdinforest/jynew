---@class XLuaTest.Injection : System.Object
---@field public name string
---@field public value UnityEngine.GameObject
local m = {}

XLuaTest.Injection = m
return m
