---@class Jyx2ResourceHelper : System.Object
local m = {}

---@static
---@return Cysharp.Threading.Tasks.UniTask
function m.Init() end

---@static
---@param path string
---@return UnityEngine.GameObject
function m.GetCachedPrefab(path) end

---@static
---@param path string
---@return UnityEngine.GameObject
function m.CreatePrefabInstance(path) end

---@static
---@param obj UnityEngine.GameObject
function m.ReleasePrefabInstance(obj) end

---@static
---@param id string
---@return Cysharp.Threading.Tasks.UniTask_1_Jyx2_EventsGraph_Jyx2NodeGraph_
function m.LoadEventGraph(id) end

Jyx2ResourceHelper = m
return m
