---@class Jyx2Console : System.Object
local m = {}

---@static
---@param cmd string
function m.RunConsoleCommand(cmd) end

---@static
function m.TransportWei() end

Jyx2Console = m
return m
