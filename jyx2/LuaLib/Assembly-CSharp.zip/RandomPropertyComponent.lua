---@class RandomPropertyComponent : UnityEngine.MonoBehaviour
---@field public m_titleText UnityEngine.UI.Text
---@field public m_propertyRoot UnityEngine.Transform
---@field public m_proItem UnityEngine.Transform
local m = {}

function m:ShowComponent() end

function m:RefreshProperty() end

RandomPropertyComponent = m
return m
