---@class CameraFilterPack_Atmosphere_Rain_Pro_3D : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public _Visualize boolean
---@field public _FixDistance number
---@field public Fade number
---@field public Intensity number
---@field public DirectionFollowCameraZ boolean
---@field public DirectionX number
---@field public Size number
---@field public Speed number
---@field public Distortion number
---@field public StormFlashOnOff number
---@field public DropOnOff number
---@field public Drop_Near number
---@field public Drop_Far number
---@field public Drop_With_Obj number
---@field public Myst number
---@field public Drop_Floor_Fluid number
---@field public Myst_Color UnityEngine.Color
local m = {}

CameraFilterPack_Atmosphere_Rain_Pro_3D = m
return m
