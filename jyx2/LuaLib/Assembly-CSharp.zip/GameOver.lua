---@class GameOver : Jyx2_UIBase
local m = {}

function m:BackToMainMenu() end

GameOver = m
return m
