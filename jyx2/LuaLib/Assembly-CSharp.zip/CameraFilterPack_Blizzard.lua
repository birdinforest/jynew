---@class CameraFilterPack_Blizzard : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public _Speed number
---@field public _Size number
---@field public _Fade number
local m = {}

CameraFilterPack_Blizzard = m
return m
