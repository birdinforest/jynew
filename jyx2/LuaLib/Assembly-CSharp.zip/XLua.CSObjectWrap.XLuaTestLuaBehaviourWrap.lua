---@class XLua.CSObjectWrap.XLuaTestLuaBehaviourWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.XLuaTestLuaBehaviourWrap = m
return m
