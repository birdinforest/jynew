---@class CameraFilterPack_Distortion_Heat : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Distortion number
local m = {}

CameraFilterPack_Distortion_Heat = m
return m
