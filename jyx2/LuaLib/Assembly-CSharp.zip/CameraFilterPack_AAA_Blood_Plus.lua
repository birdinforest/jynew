---@class CameraFilterPack_AAA_Blood_Plus : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Blood_1 number
---@field public Blood_2 number
---@field public Blood_3 number
---@field public Blood_4 number
---@field public Blood_5 number
---@field public Blood_6 number
---@field public Blood_7 number
---@field public Blood_8 number
---@field public Blood_9 number
---@field public Blood_10 number
---@field public Blood_11 number
---@field public Blood_12 number
---@field public LightReflect number
local m = {}

CameraFilterPack_AAA_Blood_Plus = m
return m
