---@class HPBar : UnityEngine.MonoBehaviour
---@field public fillImage UnityEngine.UI.Image
local m = {}

function m:Init() end

---@param v number
function m:SetValue(v) end

HPBar = m
return m
