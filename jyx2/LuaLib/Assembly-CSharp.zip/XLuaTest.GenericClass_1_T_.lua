---@class XLuaTest.GenericClass_1_T_ : System.Object
local m = {}

function m:Func1() end

---@return any
function m:Func2() end

XLuaTest.GenericClass_1_T_ = m
return m
