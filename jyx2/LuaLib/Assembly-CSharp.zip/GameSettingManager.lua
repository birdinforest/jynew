---@class GameSettingManager : System.Object
---@field public MobileMoveMode GameSettingManager.MobileMoveModeType @static
---@field public settings table<GameSettingManager.Catalog, any> @static
local m = {}

---@static
---@param value fun(obj:Jyx2_GameDifficulty)
function m.add_OnDifficultyChange(value) end

---@static
---@param value fun(obj:Jyx2_GameDifficulty)
function m.remove_OnDifficultyChange(value) end

---@static
function m.Init() end

---@static
---@param setting GameSettingManager.Catalog
---@param action fun(arg0:any)
---@param enforceImmediately boolean
function m.SubscribeEnforceEvent(setting, action, enforceImmediately) end

---@static
---@param setting GameSettingManager.Catalog
---@param action fun(arg0:any)
function m.UnsubscribeEnforceEvent(setting, action) end

---@static
---@param setting GameSettingManager.Catalog
---@param value any
function m.UpdateSetting(setting, value) end

---@static
---@return number
function m.GetVolume() end

---@static
---@param difficulty number
function m.SetGameDifficulty(difficulty) end

---@static
---@return number
function m.GetDifficulty() end

GameSettingManager = m
return m
