---@class MouseOrbitImprovedMod : UnityEngine.MonoBehaviour
---@field public target UnityEngine.Transform
---@field public distance number
---@field public xSpeed number
---@field public ySpeed number
---@field public Yoffset number
---@field public yMinLimit number
---@field public yMaxLimit number
---@field public distanceMin number
---@field public distanceMax number
local m = {}

---@static
---@param angle number
---@param min number
---@param max number
---@return number
function m.ClampAngle(angle, min, max) end

MouseOrbitImprovedMod = m
return m
