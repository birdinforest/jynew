---@class CFX2_AutoRotate : UnityEngine.MonoBehaviour
---@field public speed UnityEngine.Vector3
local m = {}

CFX2_AutoRotate = m
return m
