---@class CameraFilterPack_AAA_Blood : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Blood1 number
---@field public Blood2 number
---@field public Blood3 number
---@field public Blood4 number
---@field public LightReflect number
local m = {}

CameraFilterPack_AAA_Blood = m
return m
