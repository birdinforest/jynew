---@class pg_SceneMeshRender : UnityEngine.MonoBehaviour
---@field public mesh UnityEngine.Mesh
---@field public material UnityEngine.Material
local m = {}

pg_SceneMeshRender = m
return m
