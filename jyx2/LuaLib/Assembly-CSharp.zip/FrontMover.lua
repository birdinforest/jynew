---@class FrontMover : UnityEngine.MonoBehaviour
---@field public pivot UnityEngine.Transform
---@field public effect UnityEngine.ParticleSystem
---@field public speed number
---@field public drug number
---@field public repeatingTime number
local m = {}

FrontMover = m
return m
