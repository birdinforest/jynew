---@class ETCBase : UnityEngine.MonoBehaviour
---@field public isUnregisterAtDisable boolean
---@field public enableCamera boolean
---@field public cameraMode ETCBase.CameraMode
---@field public camTargetTag string
---@field public autoLinkTagCam boolean
---@field public autoCamTag string
---@field public cameraTransform UnityEngine.Transform
---@field public cameraTargetMode ETCBase.CameraTargetMode
---@field public enableWallDetection boolean
---@field public wallLayer UnityEngine.LayerMask
---@field public cameraLookAt UnityEngine.Transform
---@field public followOffset UnityEngine.Vector3
---@field public followDistance number
---@field public followHeight number
---@field public followRotationDamping number
---@field public followHeightDamping number
---@field public pointId number
---@field public enableKeySimulation boolean
---@field public allowSimulationStandalone boolean
---@field public visibleOnStandalone boolean
---@field public dPadAxisCount ETCBase.DPadAxis
---@field public useFixedUpdate boolean
---@field public isOnDrag boolean
---@field public isSwipeIn boolean
---@field public isSwipeOut boolean
---@field public showPSInspector boolean
---@field public showSpriteInspector boolean
---@field public showEventInspector boolean
---@field public showBehaviourInspector boolean
---@field public showAxesInspector boolean
---@field public showTouchEventInspector boolean
---@field public showDownEventInspector boolean
---@field public showPressEventInspector boolean
---@field public showCameraInspector boolean
---@field public anchor ETCBase.RectAnchor
---@field public anchorOffet UnityEngine.Vector2
---@field public visible boolean
---@field public activated boolean
local m = {}

---@virtual
function m:Start() end

---@virtual
function m:OnEnable() end

---@virtual
function m:Update() end

---@virtual
function m:FixedUpdate() end

---@virtual
function m:LateUpdate() end

function m:SetAnchorPosition() end

ETCBase = m
return m
