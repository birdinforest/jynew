---@class CameraFilterPack_3D_Shield : UnityEngine.MonoBehaviour
---@field public ChangeColorRGB UnityEngine.Color @static
---@field public SCShader UnityEngine.Shader
---@field public _Visualize boolean
---@field public _FixDistance number
---@field public _Distance number
---@field public _Size number
---@field public _FadeShield number
---@field public LightIntensity number
---@field public AutoAnimatedNear boolean
---@field public AutoAnimatedNearSpeed number
---@field public Speed number
---@field public Speed_X number
---@field public Speed_Y number
---@field public Intensity number
local m = {}

CameraFilterPack_3D_Shield = m
return m
