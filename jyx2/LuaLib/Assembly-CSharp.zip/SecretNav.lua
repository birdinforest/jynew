---@class SecretNav : UnityEngine.MonoBehaviour
---@field public IsEnterSecret boolean
local m = {}

SecretNav = m
return m
