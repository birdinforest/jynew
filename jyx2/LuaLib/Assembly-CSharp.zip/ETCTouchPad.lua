---@class ETCTouchPad : ETCBase
---@field public onMoveStart ETCTouchPad.OnMoveStartHandler
---@field public onMove ETCTouchPad.OnMoveHandler
---@field public onMoveSpeed ETCTouchPad.OnMoveSpeedHandler
---@field public onMoveEnd ETCTouchPad.OnMoveEndHandler
---@field public onTouchStart ETCTouchPad.OnTouchStartHandler
---@field public onTouchUp ETCTouchPad.OnTouchUPHandler
---@field public OnDownUp ETCTouchPad.OnDownUpHandler
---@field public OnDownDown ETCTouchPad.OnDownDownHandler
---@field public OnDownLeft ETCTouchPad.OnDownLeftHandler
---@field public OnDownRight ETCTouchPad.OnDownRightHandler
---@field public OnPressUp ETCTouchPad.OnDownUpHandler
---@field public OnPressDown ETCTouchPad.OnDownDownHandler
---@field public OnPressLeft ETCTouchPad.OnDownLeftHandler
---@field public OnPressRight ETCTouchPad.OnDownRightHandler
---@field public axisX ETCAxis
---@field public axisY ETCAxis
---@field public isDPI boolean
local m = {}

---@virtual
function m:OnEnable() end

---@virtual
function m:Start() end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerEnter(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnBeginDrag(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnDrag(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerDown(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerUp(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerExit(eventData) end

ETCTouchPad = m
return m
