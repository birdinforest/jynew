---@class XLua.Cast.Any_1_System_Int64_ : System.Object
---@field public Target any
local m = {}

XLua.Cast.Any_1_System_Int64_ = m
return m
