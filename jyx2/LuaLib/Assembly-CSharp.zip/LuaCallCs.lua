---@class LuaCallCs : UnityEngine.MonoBehaviour
local m = {}

LuaCallCs = m
return m
