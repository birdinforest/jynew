---@class HTExplosion : UnityEngine.MonoBehaviour
---@field public spriteSheetMaterial UnityEngine.Material
---@field public spriteCount number
---@field public uvAnimationTileX number
---@field public uvAnimationTileY number
---@field public framesPerSecond number
---@field public size UnityEngine.Vector3
---@field public speedGrowing number
---@field public randomRotation boolean
---@field public isOneShot boolean
---@field public billboarding HTExplosion.CameraFacingMode
---@field public addLightEffect boolean
---@field public lightRange number
---@field public lightColor UnityEngine.Color
---@field public lightFadeSpeed number
local m = {}

HTExplosion = m
return m
