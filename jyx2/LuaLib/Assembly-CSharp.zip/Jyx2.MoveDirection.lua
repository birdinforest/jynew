---@class Jyx2.MoveDirection : System.Enum
---@field public UP_RIGHT Jyx2.MoveDirection @static
---@field public RIGHT Jyx2.MoveDirection @static
---@field public DOWN_RIGHT Jyx2.MoveDirection @static
---@field public DOWN_LEFT Jyx2.MoveDirection @static
---@field public LEFT Jyx2.MoveDirection @static
---@field public UP_LEFT Jyx2.MoveDirection @static
---@field public UP Jyx2.MoveDirection @static
---@field public DOWN Jyx2.MoveDirection @static
---@field public ERROR Jyx2.MoveDirection @static
---@field public value__ number
local m = {}

Jyx2.MoveDirection = m
return m
