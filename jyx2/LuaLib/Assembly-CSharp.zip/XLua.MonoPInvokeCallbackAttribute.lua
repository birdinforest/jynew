---@class XLua.MonoPInvokeCallbackAttribute : System.Attribute
local m = {}

XLua.MonoPInvokeCallbackAttribute = m
return m
