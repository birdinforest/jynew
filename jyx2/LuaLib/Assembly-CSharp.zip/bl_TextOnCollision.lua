---@class bl_TextOnCollision : UnityEngine.MonoBehaviour
---@field public m_HudText bl_HUDText
local m = {}

bl_TextOnCollision = m
return m
