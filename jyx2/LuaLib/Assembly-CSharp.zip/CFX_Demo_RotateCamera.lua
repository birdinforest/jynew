---@class CFX_Demo_RotateCamera : UnityEngine.MonoBehaviour
---@field public rotating boolean @static
---@field public speed number
---@field public rotationCenter UnityEngine.Transform
local m = {}

CFX_Demo_RotateCamera = m
return m
