---@class CompassModel : System.Object
---@field public isVisible boolean
local m = {}

---@param value fun(sender:any, e:System.EventArgs)
function m:add_OnValueChanged(value) end

---@param value fun(sender:any, e:System.EventArgs)
function m:remove_OnValueChanged(value) end

CompassModel = m
return m
