---@class Tutorial.CustomLoader : UnityEngine.MonoBehaviour
local m = {}

Tutorial.CustomLoader = m
return m
