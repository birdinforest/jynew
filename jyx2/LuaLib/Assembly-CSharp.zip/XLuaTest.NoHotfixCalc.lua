---@class XLuaTest.NoHotfixCalc : System.Object
local m = {}

---@param a number
---@param b number
---@return number
function m:Add(a, b) end

XLuaTest.NoHotfixCalc = m
return m
