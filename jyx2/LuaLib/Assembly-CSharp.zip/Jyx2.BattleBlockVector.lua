---@class Jyx2.BattleBlockVector : System.Object
---@field public X number
---@field public Y number
---@field public Inaccessible boolean
local m = {}

---@overload fun(x1:number, y1:number, x2:number, y2:number): @static
---@param pos Jyx2.BattleBlockVector
---@return number
function m:GetDistance(pos) end

---@overload fun():
---@static
---@param x number
---@param y number
---@return number
function m.ToInt(x, y) end

---@overload fun(hashs:System.Collections.Generic.HashSet_1_System_Int32_): @static
---@static
---@param hash number
---@return Jyx2.BattleBlockVector
function m.FromInt(hash) end

---@virtual
---@param obj any
---@return boolean
function m:Equals(obj) end

---@virtual
---@return number
function m:GetHashCode() end

Jyx2.BattleBlockVector = m
return m
