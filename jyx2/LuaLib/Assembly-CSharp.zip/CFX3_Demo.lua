---@class CFX3_Demo : UnityEngine.MonoBehaviour
---@field public orderedSpawns boolean
---@field public step number
---@field public range number
---@field public groundRenderer UnityEngine.Renderer
---@field public groundCollider UnityEngine.Collider
local m = {}

CFX3_Demo = m
return m
