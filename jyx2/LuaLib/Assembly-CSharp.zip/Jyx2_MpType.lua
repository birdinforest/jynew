---@class Jyx2_MpType : System.Enum
---@field public Yin Jyx2_MpType @static
---@field public Yang Jyx2_MpType @static
---@field public Neutral Jyx2_MpType @static
---@field public value__ number
local m = {}

Jyx2_MpType = m
return m
