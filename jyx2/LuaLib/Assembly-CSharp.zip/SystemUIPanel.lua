---@class SystemUIPanel : Jyx2_UIBase
---@field public Layer UILayer
local m = {}

function m:InitTrans() end

SystemUIPanel = m
return m
