---@class UnityEngine.UI.Extensions.UIPolygon : UnityEngine.UI.UIPrimitiveBase
---@field public fill boolean
---@field public thickness number
---@field public sides number
---@field public rotation number
---@field public VerticesDistances number[]
local m = {}

---@overload fun(_sides:number, _VerticesDistances:number[])
---@overload fun(_sides:number, _VerticesDistances:number[], _rotation:number)
---@param _sides number
function m:DrawPolygon(_sides) end

UnityEngine.UI.Extensions.UIPolygon = m
return m
