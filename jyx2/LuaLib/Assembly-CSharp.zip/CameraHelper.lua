---@class CameraHelper : UnityEngine.MonoBehaviour
---@field public Instance CameraHelper @static
---@field public m_StateDrivenCam Cinemachine.CinemachineStateDrivenCamera
---@field public m_BattleCam UnityEngine.Transform
---@field public m_RrotateSpeed number
---@field public smoothing number
---@field public zoomMin number
---@field public zoomMax number
local m = {}

function m:BattleFieldLockRole() end

---@param follow UnityEngine.Transform
function m:ChangeFollow(follow) end

---@param duration number
---@param amplitude number
---@param frequency number
function m:ShakeCamera(duration, amplitude, frequency) end

---@param finalFov number
---@param duration number
function m:ChangeFOV(finalFov, duration) end

---@param finalFov number
---@param duration number
function m:ChangeBattleCameraFOV(finalFov, duration) end

---@param duration number
function m:ResetFOV(duration) end

---@param finalHeight number
---@param duration number
function m:ChangeFreeLookHeight(finalHeight, duration) end

---@param duration number
function m:ResetFreeLookHeight(duration) end

---@param finalRadius number
---@param duration number
function m:ChangeFreeLookRadius(finalRadius, duration) end

---@param duration number
function m:ResetFreeLookRadius(duration) end

CameraHelper = m
return m
