---@class XLuaTest.MyEnum : System.Enum
---@field public E1 XLuaTest.MyEnum @static
---@field public E2 XLuaTest.MyEnum @static
---@field public value__ number
local m = {}

XLuaTest.MyEnum = m
return m
