---@class GameEvent : UnityEngine.MonoBehaviour
---@field public InteractText string @static
---@field public UseItemText string @static
---@field public m_EventTargets UnityEngine.GameObject[]
---@field public m_InteractiveEventId string
---@field public m_UseItemEventId string
---@field public m_EnterEventId string
---@field public IsTriggerEnterEvent boolean
---@field public IsUseItemEvent boolean
---@field public IsInteractiveEvent boolean
---@field public IsInteractiveOrUseItemEvent boolean
---@field public IsEmptyEvent boolean
---@field public PriorityOrder number
---@field public HasEventTargets boolean
local m = {}

---@static
---@return GameEvent
function m.GetCurrentGameEvent() end

function m:Init() end

---@return Cysharp.Threading.Tasks.UniTask
function m:MarkChest() end

---@static
---@param id string
---@return GameEvent
function m.GetCurrentSceneEvent(id) end

GameEvent = m
return m
