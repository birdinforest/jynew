---@class Jyx2.SkillCoverType : System.Enum
---@field public POINT Jyx2.SkillCoverType @static
---@field public LINE Jyx2.SkillCoverType @static
---@field public CROSS Jyx2.SkillCoverType @static
---@field public RECT Jyx2.SkillCoverType @static
---@field public RHOMBUS Jyx2.SkillCoverType @static
---@field public INVALID Jyx2.SkillCoverType @static
---@field public value__ number
local m = {}

Jyx2.SkillCoverType = m
return m
