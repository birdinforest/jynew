---@class StoryEngine : UnityEngine.MonoBehaviour
---@field public Instance StoryEngine @static
---@field public BlockPlayerControl boolean @static
---@field public HUDRoot bl_HUDText
local m = {}

---@overload fun(msg:string) @static
---@static
---@param msg string
---@param duration number
function m.DisplayPopInfo(msg, duration) end

---@static
---@param index number
---@return boolean
function m.DoLoadGame(index) end

StoryEngine = m
return m
