---@class ChangeBlendShape : UnityEngine.MonoBehaviour
---@field public blendSpeed number
local m = {}

function m:ChangeBlend() end

ChangeBlendShape = m
return m
