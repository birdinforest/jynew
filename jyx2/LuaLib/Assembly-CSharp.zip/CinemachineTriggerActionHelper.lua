---@class CinemachineTriggerActionHelper : UnityEngine.EventSystems.UIBehaviour
---@field public CallEnter boolean
---@field public CallStay boolean
---@field public CallLeavel boolean
---@field public enterLockDirection boolean
---@field public exitLockDirection boolean
---@field public m_UnlockTarget boolean
---@field public vcam Cinemachine.CinemachineVirtualCamera
---@field public m_AcceptColliderNames string[]
local m = {}

function m:LockDirection() end

CinemachineTriggerActionHelper = m
return m
