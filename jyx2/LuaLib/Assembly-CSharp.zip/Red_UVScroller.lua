---@class Red_UVScroller : UnityEngine.MonoBehaviour
---@field public targetMaterialSlot number
---@field public speedY number
---@field public speedX number
---@field public m_MeshRenderer UnityEngine.Renderer
local m = {}

Red_UVScroller = m
return m
