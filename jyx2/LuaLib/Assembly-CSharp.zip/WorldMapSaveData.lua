---@class WorldMapSaveData : System.Object
---@field public WorldPosition UnityEngine.Vector3
---@field public WorldRotation UnityEngine.Quaternion
---@field public BoatWorldPos UnityEngine.Vector3
---@field public BoatRotate UnityEngine.Quaternion
---@field public OnBoat number
---@field public areaMask number
local m = {}

WorldMapSaveData = m
return m
