---@class XLuaTest.InvokeLua : UnityEngine.MonoBehaviour
local m = {}

XLuaTest.InvokeLua = m
return m
