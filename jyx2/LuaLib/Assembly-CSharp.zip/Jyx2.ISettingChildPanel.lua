---@class Jyx2.ISettingChildPanel : table
local m = {}

---@abstract
function m:ApplySetting() end

---@abstract
---@param isVisible boolean
function m:SetVisibility(isVisible) end

Jyx2.ISettingChildPanel = m
return m
