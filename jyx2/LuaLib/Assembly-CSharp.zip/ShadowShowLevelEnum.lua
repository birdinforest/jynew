---@class ShadowShowLevelEnum : System.Enum
---@field public Team ShadowShowLevelEnum @static
---@field public All ShadowShowLevelEnum @static
---@field public value__ number
local m = {}

ShadowShowLevelEnum = m
return m
