---@class BouncingBall : UnityEngine.MonoBehaviour
---@field public Acceleration number
---@field public HorizVelocity number
---@field public Wall number
---@field public Radius number
---@field public RotationSpeed number
local m = {}

BouncingBall = m
return m
