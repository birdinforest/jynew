---@class Jyx2.AIResult : System.Object
---@field public MoveX number
---@field public MoveY number
---@field public SkillCast Jyx2.SkillCastInstance
---@field public AttackX number
---@field public AttackY number
---@field public IsRest boolean
---@field public Item Jyx2.LItemConfig
---@field public skillCastPK string
local m = {}

---@param other Jyx2.AIResult
---@return boolean
function m:Equals(other) end

Jyx2.AIResult = m
return m
