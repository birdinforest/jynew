---@class XLua.CSObjectWrap.XLuaTestBaseTestWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.XLuaTestBaseTestWrap = m
return m
