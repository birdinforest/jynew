---@class XLuaTest.MessageBoxConfig : System.Object
---@field public CSharpCallLua System.Type[] @static
local m = {}

XLuaTest.MessageBoxConfig = m
return m
