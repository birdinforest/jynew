---@class Jyx2.BattleBlockVectorTools : System.Object
local m = {}

---@static
---@param blocks System.Collections.Generic.IEnumerable_1_Jyx2_BattleBlockVector_
---@return System.Collections.Generic.IEnumerable_1_UnityEngine_Transform_
function m.ToTransforms(blocks) end

Jyx2.BattleBlockVectorTools = m
return m
