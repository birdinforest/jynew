---@class XLuaTest.HotfixTest2 : UnityEngine.MonoBehaviour
local m = {}

XLuaTest.HotfixTest2 = m
return m
