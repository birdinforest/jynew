---@class BattleLoader : UnityEngine.MonoBehaviour
---@field public m_BattleId number
---@field public Callback fun(obj:Jyx2.BattleResult)
---@field public IsTestCase boolean
---@field public m_Roles BattleLoader.BattlePosRole[]
---@field public CurrentBattleConfig Jyx2.LBattleConfig
local m = {}

BattleLoader = m
return m
