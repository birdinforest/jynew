---@class FaceToCamera : UnityEngine.MonoBehaviour
local m = {}

FaceToCamera = m
return m
