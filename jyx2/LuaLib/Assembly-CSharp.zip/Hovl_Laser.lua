---@class Hovl_Laser : UnityEngine.MonoBehaviour
---@field public HitEffect UnityEngine.GameObject
---@field public HitOffset number
---@field public useLaserRotation boolean
---@field public MaxLength number
---@field public MainTextureLength number
---@field public NoiseTextureLength number
local m = {}

function m:DisablePrepare() end

Hovl_Laser = m
return m
