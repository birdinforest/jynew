---@class XLuaTest.BaseTest : XLuaTest.BaseTestBase_1_XLuaTest_InnerTypeTest_
local m = {}

---@virtual
---@param p number
function m:Foo(p) end

---@param p number
function m:Proxy(p) end

---@virtual
---@return string
function m:ToString() end

XLuaTest.BaseTest = m
return m
