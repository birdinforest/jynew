---@class MaxFpsEnum : System.Enum
---@field public Fps30 MaxFpsEnum @static
---@field public Fps60 MaxFpsEnum @static
---@field public Fps120 MaxFpsEnum @static
---@field public Fps200 MaxFpsEnum @static
---@field public value__ number
local m = {}

MaxFpsEnum = m
return m
