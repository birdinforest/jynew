---@class Jyx2SkillEditorEnemy : Jyx2.Jyx2AnimationBattleRole
local m = {}

---@virtual
---@return UnityEngine.Animator
function m:GetAnimator() end

Jyx2SkillEditorEnemy = m
return m
