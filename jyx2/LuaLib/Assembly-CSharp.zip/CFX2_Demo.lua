---@class CFX2_Demo : UnityEngine.MonoBehaviour
---@field public orderedSpawns boolean
---@field public step number
---@field public range number
---@field public groundMat UnityEngine.Material
---@field public waterMat UnityEngine.Material
---@field public ParticleExamples UnityEngine.GameObject[]
local m = {}

CFX2_Demo = m
return m
