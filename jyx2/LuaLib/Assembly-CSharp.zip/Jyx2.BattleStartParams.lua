---@class Jyx2.BattleStartParams : System.Object
---@field public callback fun(obj:Jyx2.BattleResult)
---@field public roles Jyx2.RoleInstance[]
---@field public battleData Jyx2.LBattleConfig
---@field public backToBigMap boolean
---@field public playerJoin boolean
local m = {}

Jyx2.BattleStartParams = m
return m
