---@class UnityEngine.UI.ISelectButton : table
---@field public onClick UnityEngine.UI.ButtonClickEvent
local m = {}

---@abstract
function m:OnClickSelect() end

---@abstract
function m:OnClickDeselect() end

UnityEngine.UI.ISelectButton = m
return m
