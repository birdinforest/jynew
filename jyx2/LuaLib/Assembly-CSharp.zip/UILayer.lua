---@class UILayer : System.Enum
---@field public MainUI UILayer @static
---@field public NormalUI UILayer @static
---@field public PopupUI UILayer @static
---@field public Top UILayer @static
---@field public value__ number
local m = {}

UILayer = m
return m
