---@class ObjectInstance : UnityEngine.MonoBehaviour
---@field public prefab UnityEngine.GameObject
---@field public Repeating boolean
---@field public RepeatTime number
---@field public StartTime number
---@field public DestroyTimeDelay number
local m = {}

ObjectInstance = m
return m
