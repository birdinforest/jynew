---@class XLua.Cast.Any_1_System_Byte_ : System.Object
---@field public Target any
local m = {}

XLua.Cast.Any_1_System_Byte_ = m
return m
