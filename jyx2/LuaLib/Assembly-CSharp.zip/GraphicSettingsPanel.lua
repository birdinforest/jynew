---@class GraphicSettingsPanel : Jyx2_UIBase
---@field public m_FogToggle UnityEngine.UI.Toggle
---@field public m_PostToggle UnityEngine.UI.Toggle
---@field public m_WaterNormalToggle UnityEngine.UI.Toggle
---@field public m_AntiAliasingToggle UnityEngine.UI.Toggle
---@field public m_Vsynctoggle UnityEngine.UI.Toggle
---@field public m_maxFpsDropdown UnityEngine.UI.Dropdown
---@field public m_QualityLevelDropdown UnityEngine.UI.Dropdown
---@field public m_ShaderLodLevelropdown UnityEngine.UI.Dropdown
---@field public m_ShadowQualityDropdown UnityEngine.UI.Dropdown
---@field public m_ShadowShowLevelDropdown UnityEngine.UI.Dropdown
local m = {}

---@virtual
function m:ApplySetting() end

---@virtual
---@param isVisible boolean
function m:SetVisibility(isVisible) end

function m:InitUI() end

---@param index number
function m:DropdownMaxFps(index) end

---@param index number
function m:DropdownShadowShowLevel(index) end

---@param index number
function m:DropdownShadowQuality(index) end

---@param index number
function m:DropdownQualityLevel(index) end

---@param index number
function m:DropdownShaderLodLevel(index) end

---@param value boolean
function m:SetFog(value) end

---@param value boolean
function m:SetPostProcess(value) end

---@param value boolean
function m:SetWaterNormal(value) end

---@param value boolean
function m:SetAntiAliasing(value) end

---@param value boolean
function m:SetVSync(value) end

GraphicSettingsPanel = m
return m
