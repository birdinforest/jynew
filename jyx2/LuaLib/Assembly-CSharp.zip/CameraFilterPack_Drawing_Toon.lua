---@class CameraFilterPack_Drawing_Toon : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Threshold number
---@field public DotSize number
local m = {}

CameraFilterPack_Drawing_Toon = m
return m
