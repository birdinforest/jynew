---@class XLua.CSObjectWrap.TutorialDerivedClassExtensionsWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.TutorialDerivedClassExtensionsWrap = m
return m
