---@class Jyx2.Jyx2_PlayerPrefsData : System.Object
---@field public m_IntDic System.Collections.Generic.Dictionary_2_System_String_System_Int32_
---@field public m_BoolDic System.Collections.Generic.Dictionary_2_System_String_System_Boolean_
---@field public m_FloatDic System.Collections.Generic.Dictionary_2_System_String_System_Single_
---@field public m_StringDic System.Collections.Generic.Dictionary_2_System_String_System_String_
local m = {}

function m:Clear() end

---@param key string
---@return boolean
function m:HasKey(key) end

---@param key string
function m:DeleteKey(key) end

Jyx2.Jyx2_PlayerPrefsData = m
return m
