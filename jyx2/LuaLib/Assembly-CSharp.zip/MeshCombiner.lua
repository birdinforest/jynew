---@class MeshCombiner : UnityEngine.MonoBehaviour
local m = {}

MeshCombiner = m
return m
