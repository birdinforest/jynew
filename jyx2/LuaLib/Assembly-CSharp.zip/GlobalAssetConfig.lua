---@class GlobalAssetConfig : UnityEngine.ScriptableObject
---@field public Instance GlobalAssetConfig @static
---@field public startModId string
---@field public rootLuaFile UnityEngine.TextAsset
---@field public defaultTranslator i18n.Translator
---@field public defaultBeHitClip UnityEngine.AnimationClip
---@field public defaultMoveClip UnityEngine.AnimationClip
---@field public defaultIdleClip UnityEngine.AnimationClip
---@field public defaultStunClip UnityEngine.AnimationClip
---@field public anqiClip UnityEngine.AnimationClip
---@field public useItemClip UnityEngine.AnimationClip
---@field public defaultAnimatorController UnityEngine.RuntimeAnimatorController
---@field public defaultNPCAnimatorController UnityEngine.RuntimeAnimatorController
---@field public defaultDieClips UnityEngine.AnimationClip[]
---@field public bigMapIdleClips UnityEngine.AnimationClip[]
---@field public vcam3rdPrefab UnityEngine.GameObject
---@field public defaultVcamOffset UnityEngine.Vector3
---@field public vcamOffsetClose UnityEngine.Vector3
---@field public defaultHomeName string
---@field public CachedPrefabs UnityEngine.GameObject[]
---@field public CachePrefabDict System.Collections.Generic.Dictionary_2_System_String_UnityEngine_GameObject_
local m = {}

---@return Cysharp.Threading.Tasks.UniTask
function m:OnLoad() end

GlobalAssetConfig = m
return m
