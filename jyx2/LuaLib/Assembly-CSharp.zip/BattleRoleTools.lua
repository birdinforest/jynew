---@class BattleRoleTools : System.Object
local m = {}

---@static
---@param roles Jyx2.RoleInstance[]
---@return System.Collections.Generic.IEnumerable_1_BattleRole_
function m.ToMapRoles(roles) end

BattleRoleTools = m
return m
