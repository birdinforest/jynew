---@class XLuaTest.AsyncTest : UnityEngine.MonoBehaviour
local m = {}

XLuaTest.AsyncTest = m
return m
