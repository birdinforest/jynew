---@class CFX_LightIntensityFade : UnityEngine.MonoBehaviour
---@field public duration number
---@field public delay number
---@field public finalIntensity number
---@field public autodestruct boolean
local m = {}

CFX_LightIntensityFade = m
return m
