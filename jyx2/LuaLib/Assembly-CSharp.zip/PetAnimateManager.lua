---@class PetAnimateManager : UnityEngine.MonoBehaviour
---@field public CustomizedAnimatorNamePrefix string
---@field public StateChangeComplete boolean
local m = {}

function m:StandButtonClicked() end

function m:SitButtonClicked() end

function m:LayButtonClicked() end

function m:ConsumeButtonClicked() end

function m:AggressiveButtonClicked() end

function m:WalkButtonClicked() end

PetAnimateManager = m
return m
