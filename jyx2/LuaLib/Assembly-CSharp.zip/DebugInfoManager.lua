---@class DebugInfoManager : UnityEngine.MonoBehaviour
---@field public m_FpsText UnityEngine.UI.Text
---@field public fps_updateInterval number
local m = {}

---@static
function m.Init() end

DebugInfoManager = m
return m
