---@class CameraShaker : UnityEngine.MonoBehaviour
---@field public cameraObject UnityEngine.Transform
---@field public amplitude number
---@field public frequency number
---@field public duration number
---@field public timeRemaining number
local m = {}

---@param amp number
---@param freq number
---@param dur number
---@param wait number
---@return System.Collections.IEnumerator
function m:Shake(amp, freq, dur, wait) end

CameraShaker = m
return m
