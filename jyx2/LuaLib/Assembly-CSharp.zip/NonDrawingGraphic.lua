---@class NonDrawingGraphic : UnityEngine.UI.Graphic
local m = {}

NonDrawingGraphic = m
return m
