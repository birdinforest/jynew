---@class FrontAttack : UnityEngine.MonoBehaviour
---@field public pivot UnityEngine.Transform
---@field public startRotation UnityEngine.Vector3
---@field public speed number
---@field public drug number
---@field public craterPrefab UnityEngine.GameObject
---@field public ps UnityEngine.ParticleSystem
---@field public playPS boolean
---@field public spawnRate number
---@field public spawnDuration number
---@field public positionOffset number
---@field public changeScale boolean
---@field public effectWithAnimation boolean
---@field public anim UnityEngine.Animator[]
---@field public delay number
---@field public playMeshEffect boolean
local m = {}

---@param targetPoint UnityEngine.Vector3
function m:PrepeareAttack(targetPoint) end

---@return System.Collections.IEnumerator
function m:MeshEffect() end

---@return System.Collections.IEnumerator
function m:StartMove() end

FrontAttack = m
return m
