---@class TargetProjectile : UnityEngine.MonoBehaviour
---@field public speed number
---@field public hit UnityEngine.GameObject
---@field public flash UnityEngine.GameObject
---@field public Detached UnityEngine.GameObject[]
---@field public LocalRotation boolean
---@field public sideAngle number
---@field public upAngle number
local m = {}

---@param targetPosition UnityEngine.Transform
---@param Offset UnityEngine.Vector3
function m:UpdateTarget(targetPosition, Offset) end

TargetProjectile = m
return m
