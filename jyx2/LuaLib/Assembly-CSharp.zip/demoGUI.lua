---@class demoGUI : UnityEngine.MonoBehaviour
---@field public explosions UnityEngine.GameObject[]
local m = {}

demoGUI = m
return m
