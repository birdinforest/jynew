---@class ChangeShader : UnityEngine.MonoBehaviour
---@field public material UnityEngine.Material[]
local m = {}

function m:ChangeShaderButtonClicked() end

ChangeShader = m
return m
