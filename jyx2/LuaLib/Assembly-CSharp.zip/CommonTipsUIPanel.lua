---@class CommonTipsUIPanel : Jyx2_UIBase
---@field public Layer UILayer
local m = {}

---@overload fun(msg:string) @static
---@static
---@param msg string
---@param tipsType TipsType
function m.ShowPopInfo(msg, tipsType) end

function m:InitTrans() end

CommonTipsUIPanel = m
return m
