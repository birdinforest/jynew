---@class BattleMainUIPanel : Jyx2_UIBase
---@field public Layer UILayer
local m = {}

function m:SwitchAutoBattle() end

function m:InitTrans() end

BattleMainUIPanel = m
return m
