---@class CameraFilterPack_Drawing_Comics : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public DotSize number
local m = {}

CameraFilterPack_Drawing_Comics = m
return m
