---@class XLuaTest.HotfixTest : UnityEngine.MonoBehaviour
local m = {}

XLuaTest.HotfixTest = m
return m
