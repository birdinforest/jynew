---@class XLuaTest.Foo2Child : XLuaTest.Foo2Parent
local m = {}

XLuaTest.Foo2Child = m
return m
