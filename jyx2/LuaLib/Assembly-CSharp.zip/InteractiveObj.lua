---@class InteractiveObj : UnityEngine.MonoBehaviour
local m = {}

---@param callback fun(obj:InteractiveObj)
function m:SetMouseClickCallback(callback) end

InteractiveObj = m
return m
