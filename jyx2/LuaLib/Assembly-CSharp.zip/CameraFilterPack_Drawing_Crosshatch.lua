---@class CameraFilterPack_Drawing_Crosshatch : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Width number
local m = {}

CameraFilterPack_Drawing_Crosshatch = m
return m
