---@class Serialization_1_T_ : System.Object
local m = {}

---@return any[]
function m:ToList() end

Serialization_1_T_ = m
return m
