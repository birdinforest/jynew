---@class FrontSpawner : UnityEngine.MonoBehaviour
---@field public pivot UnityEngine.Transform
---@field public speed number
---@field public drug number
---@field public repeatingTime number
---@field public craterPrefab UnityEngine.GameObject
---@field public spawnRate number
---@field public spawnDuration number
---@field public positionOffset number
---@field public changeScale boolean
local m = {}

FrontSpawner = m
return m
