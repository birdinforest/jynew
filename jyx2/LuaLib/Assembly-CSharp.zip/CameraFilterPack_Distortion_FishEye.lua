---@class CameraFilterPack_Distortion_FishEye : UnityEngine.MonoBehaviour
---@field public SCShader UnityEngine.Shader
---@field public Distortion number
local m = {}

CameraFilterPack_Distortion_FishEye = m
return m
