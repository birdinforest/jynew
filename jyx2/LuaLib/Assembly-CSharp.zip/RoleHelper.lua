---@class RoleHelper : System.Object
local m = {}

---@static
---@return Jyx2Player
function m.FindPlayer() end

---@overload fun(role:Jyx2.RoleInstance): @static
---@static
---@param role Jyx2.RoleInstance
---@param tag string
---@return BattleRole
function m.CreateRoleView(role, tag) end

---@static
---@param roleView BattleRole
---@param roleKey number
function m.CreateRoleInstance(roleView, roleKey) end

---@static
---@param roleView BattleRole
---@param role Jyx2.RoleInstance
---@return Cysharp.Threading.Tasks.UniTask
function m.BindRoleInstance(roleView, role) end

RoleHelper = m
return m
