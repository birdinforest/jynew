---@class MOD.UI.ModModifiedInfo : System.ValueType
---@field public isSuccess boolean
---@field public ModifiedTime string
---@field public ETag string
---@field public ModFileSize number
local m = {}

---@virtual
---@return string
function m:ToString() end

MOD.UI.ModModifiedInfo = m
return m
