---@class TestPlayableAsset : UnityEngine.Playables.PlayableAsset
---@field public ShowNumberText UnityEngine.ExposedReference_1_UnityEngine_GameObject_
---@field public startNum number
---@field public e UnityEngine.Events.UnityEvent
local m = {}

---@virtual
---@param graph UnityEngine.Playables.PlayableGraph
---@param go UnityEngine.GameObject
---@return UnityEngine.Playables.Playable
function m:CreatePlayable(graph, go) end

TestPlayableAsset = m
return m
