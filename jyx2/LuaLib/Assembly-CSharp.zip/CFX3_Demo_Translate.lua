---@class CFX3_Demo_Translate : UnityEngine.MonoBehaviour
---@field public speed number
---@field public rotation UnityEngine.Vector3
---@field public axis UnityEngine.Vector3
---@field public gravity boolean
local m = {}

CFX3_Demo_Translate = m
return m
