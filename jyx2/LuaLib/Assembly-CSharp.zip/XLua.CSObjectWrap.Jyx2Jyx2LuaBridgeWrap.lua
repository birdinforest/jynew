---@class XLua.CSObjectWrap.Jyx2Jyx2LuaBridgeWrap : System.Object
local m = {}

---@static
---@param L System.IntPtr
function m.__Register(L) end

XLua.CSObjectWrap.Jyx2Jyx2LuaBridgeWrap = m
return m
