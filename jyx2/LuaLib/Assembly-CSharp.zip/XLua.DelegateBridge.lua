---@class XLua.DelegateBridge : XLua.DelegateBridgeBase
---@field public Gen_Flag boolean @static
local m = {}

---@param p0 number
function m:__Gen_Delegate_Imp0(p0) end

---@param p0 string
function m:__Gen_Delegate_Imp1(p0) end

---@param p0 number
function m:__Gen_Delegate_Imp2(p0) end

---@param p0 boolean
function m:__Gen_Delegate_Imp3(p0) end

---@param p0 number
function m:__Gen_Delegate_Imp4(p0) end

---@param p0 number
function m:__Gen_Delegate_Imp5(p0) end

---@param p0 number
function m:__Gen_Delegate_Imp6(p0) end

function m:__Gen_Delegate_Imp7() end

---@param p0 number
---@param p1 number
---@return number
function m:__Gen_Delegate_Imp8(p0, p1) end

---@param p0 number
function m:__Gen_Delegate_Imp9(p0) end

---@param p0 number
---@return number
function m:__Gen_Delegate_Imp10(p0) end

---@param p0 UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:__Gen_Delegate_Imp11(p0) end

---@param p0 XLuaTest.MyStruct
---@return XLuaTest.MyStruct
function m:__Gen_Delegate_Imp12(p0) end

---@param p0 XLuaTest.MyEnum
---@return XLuaTest.MyEnum
function m:__Gen_Delegate_Imp13(p0) end

---@param p0 System.Decimal
---@return System.Decimal
function m:__Gen_Delegate_Imp14(p0) end

---@param p0 System.Array
function m:__Gen_Delegate_Imp15(p0) end

---@param p0 number
---@param p1 string
---@return number, Tutorial.CSCallLua.DClass
function m:__Gen_Delegate_Imp16(p0, p1) end

---@return fun()
function m:__Gen_Delegate_Imp17() end

---@param p0 number
---@param p1 string[]
---@return XLuaTest.InvokeLua.ICalc
function m:__Gen_Delegate_Imp18(p0, p1) end

---@param p0 any
function m:__Gen_Delegate_Imp19(p0) end

---@param p0 any
---@param p1 number
---@param p2 number
---@return number
function m:__Gen_Delegate_Imp20(p0, p1, p2) end

---@param p0 any
---@param p1 UnityEngine.Vector3
---@param p2 UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:__Gen_Delegate_Imp21(p0, p1, p2) end

---@param p0 any
---@param p1 number
---@param p3 System.String
---@return number, System.Double, System.String
function m:__Gen_Delegate_Imp22(p0, p1, p3) end

---@param p0 any
---@param p1 number
---@param p3 System.String
---@param p4 any
---@return number, System.Double, System.String
function m:__Gen_Delegate_Imp23(p0, p1, p3, p4) end

---@param p0 any
---@param p1 number
function m:__Gen_Delegate_Imp24(p0, p1) end

---@param p0 any
---@return string
function m:__Gen_Delegate_Imp25(p0) end

---@param p0 XLuaTest.StructTest
---@param p1 number
---@param p2 any
---@return UnityEngine.GameObject
function m:__Gen_Delegate_Imp26(p0, p1, p2) end

---@param p0 XLuaTest.StructTest
---@return string
function m:__Gen_Delegate_Imp27(p0) end

---@param p0 XLuaTest.StructTest
---@param p1 any
function m:__Gen_Delegate_Imp28(p0, p1) end

---@param p0 any
---@return number
function m:__Gen_Delegate_Imp29(p0) end

---@param p0 any
---@param p1 any
function m:__Gen_Delegate_Imp30(p0, p1) end

---@param p0 any
---@param p1 any
---@return number
function m:__Gen_Delegate_Imp31(p0, p1) end

---@param p0 any
---@param p1 any
---@param p2 number
function m:__Gen_Delegate_Imp32(p0, p1, p2) end

---@param p0 number
---@param p1 number
function m:__Gen_Delegate_Imp33(p0, p1) end

---@param p0 any
---@param p1 number
---@param p2 number
function m:__Gen_Delegate_Imp34(p0, p1, p2) end

---@virtual
---@param type System.Type
---@return fun(...:any|any[]):
function m:GetDelegateByType(type) end

---@param L System.IntPtr
---@param nArgs number
---@param nResults number
---@param errFunc number
function m:PCall(L, nArgs, nResults, errFunc) end

---@overload fun(p1:any)
---@overload fun(p1:any, p2:any)
---@overload fun(p1:any, p2:any, p3:any)
---@overload fun(p1:any, p2:any, p3:any, p4:any)
function m:Action() end

---@overload fun(p1:any):
---@overload fun(p1:any, p2:any):
---@overload fun(p1:any, p2:any, p3:any):
---@overload fun(p1:any, p2:any, p3:any, p4:any):
---@return any
function m:Func() end

XLua.DelegateBridge = m
return m
