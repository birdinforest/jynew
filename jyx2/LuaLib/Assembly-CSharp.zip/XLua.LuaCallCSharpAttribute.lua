---@class XLua.LuaCallCSharpAttribute : System.Attribute
---@field public Flag XLua.GenFlag
local m = {}

XLua.LuaCallCSharpAttribute = m
return m
