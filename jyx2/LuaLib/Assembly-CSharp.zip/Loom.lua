---@class Loom : UnityEngine.MonoBehaviour
---@field public maxThreads number @static
---@field public Current Loom @static
local m = {}

---@static
function m.Initialize() end

---@overload fun(taction:fun(obj:any), tparam:any, time:number) @static
---@static
---@param taction fun(obj:any)
---@param tparam any
function m.QueueOnMainThread(taction, tparam) end

---@static
---@param a fun()
---@return System.Threading.Thread
function m.RunAsync(a) end

Loom = m
return m
