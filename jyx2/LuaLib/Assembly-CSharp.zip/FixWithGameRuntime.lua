---@class FixWithGameRuntime : UnityEngine.MonoBehaviour
---@field public FixType FixWithGameRuntime.FixTypeEnum
---@field public Flag string
---@field public MoveTo UnityEngine.Transform
local m = {}

function m:Reload() end

FixWithGameRuntime = m
return m
